package knn;
import java.io.File;
import java.io.FileNotFoundException;
import static java.lang.Math.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dturack
 */
public class DTuraKNN{

    /**
     * @param args the command line arguments
     */
    
    //static HashTable<String> tb = new HashTable<>();
    //static ItemHash ih;
    static Random rdn = new Random();
    static float knnkArr[];
    static String knnkResArr[];
    static float testArr[];
    static String testResArr[];
    static float trainArr[];
    static String trainResArr[];
    static float knnuArr[];
    public static void main(String[] args) {
        System.out.printf("Running Q.1: Inporting Data\n");
        try {
            File file = new File("src/knn/KNNknown.txt");
            Scanner scan = new Scanner(file);
            knnkArr = new float[160];
            knnkResArr = new String[80];
            int i = 0, k=0;
            byte t;
            while(scan.hasNextLine()){
                //System.out.printf("Test1");
                while(scan.hasNext()){
                    //System.out.printf("Test2");
                    if(scan.hasNextFloat()){
                        knnkArr[(i*2)+k] = (float)scan.nextFloat();
                        k ^= 1;
                    }
                    else if (scan.hasNext("T")|| scan.hasNext("F")){
                        knnkResArr[i] = scan.next();
                        i++;
                    }
                    else
                        t = scan.nextByte();
                }
                //if(scan.hasNextByte())
                //    t = scan.nextByte();
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DTuraKNN.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.printf("testing: %f %f %s\n\n", knnkArr[0*2], knnkArr[0*2+1], knnkResArr[0]);

        float [] accur = new float[4];
        float [] solut = new float[3];
        for(int i=0; i<4; i++){
            System.out.printf("\nRunning Q.4: Repeating Q.2 and Q.3\n");
            splitData();
            solut = testMetric();
            accur[i] = solut[0];
            int method = (int)solut[2];
            String metho;
            switch(method){
                case 0: 
                    metho = "Euclidean";
                    break;
                case 1:
                    metho = "Normalized Euclidean";
                    break;
                default:
                    metho = "Invalid";
                    break;
            }
            System.out.printf("Accuracy: %f, K-Value: %f, Metric Method: %s", solut[0], solut[1], metho);
        }
        System.out.printf("Accuracies are: %f, %f, %f, %f\n", accur[0], accur[1], accur[2], accur[3]);
    }
    
    static float [] testMetric(){
        System.out.printf("Running Q.3: Testing Metric distance measures and k values\n");
        float accur = 0;
        float [] solut = new float[3];
        float res = 0;
        for(int i=0; i<10; i++){
            res = testKNN(3+(2*i), 0);
            System.out.printf("testing k = %d result: %f", 3+(2*i), res);
            if(accur<res){
                solut[0] = res;
                solut[1] = 3+(2*i);
                solut[2] = 0;
                accur = res;
            }
            res = testKNN(3+(2*i), 1);
            if(accur<res){
                solut[0] = res;
                solut[1] = 3+(2*i);
                solut[2] = 1;
                accur = res;
            }    
        }
        return solut;
    }
    
    static void splitData(){
        System.out.printf("Running Q.2: Splitting Data\n");
        int train = 65, test = 15;
        
        testArr = new float[test*2];
        trainArr = new float[train*2];
        testResArr = new String[test];
        trainResArr = new String[train];
        int locs[] = new int[train];
        for(int i=0; i<train; i++){
            int tmp = 0;
            boolean found = true;
            while(found) {
                tmp = rdn.nextInt(test+train);
                int k=0;
                for(; k<i; k++){
                    if(locs[k]==tmp){
                        found = true;
                        break;
                    }
                }
                if(k==i)
                    found = false;
            }
            locs[i] = tmp;
        }
        int ts = 0;
        int tr = 0;
        for(int i=0; i<train+test; i++){
            boolean found = false;
            for(int k=0; k<train; k++){
                if(i==locs[k]){
                   trainArr[tr*2] = knnkArr[i*2];
                   trainArr[tr*2+1] = knnkArr[i*2+1];
                   trainResArr[tr] = knnkResArr[i];
                   tr++;
                   found = true;
                   break;
                }
            }
            if(!found){
                testArr[ts*2] = knnkArr[i*2];
                testArr[ts*2+1] = knnkArr[i*2+1];
                testResArr[ts] = knnkResArr[i];
                ts++;
            }
        }
        System.out.printf("Testing train arr %f %f %s\n", trainArr[10*2], trainArr[10*2+1], trainResArr[10]);
        System.out.printf("Testing test arr %f %f %s\n\n", testArr[1*2], testArr[1*2+1], testResArr[1]);

    }
    
    static float testKNN(int k, int mthd){
        float accur = 0;
        switch (mthd){
            case 0:
                accur = testEuc(k);
                System.out.printf("testing Euclidean: Accuracy: %f\n", accur);
                break;
            case 1:
                accur = testNEuc(k);
                System.out.printf("testing Normalized Euclidean: Accuracy:  %f\n", accur);
                break;
            default:
                System.out.printf("Invalid selection\n");
        }
        /*if(mthd == 0){
            accur = testEuc(k);
        }
        else if(mthd == 1)
            accur = testNEuc(k);*/
        return accur;
    }
    
    static float testEuc(int k){
        float correct = 0;

        String result = null;
        for(int i=0; i<testResArr.length; i++){
            float a = testArr[i*2];
            float b = testArr[i*2+1];
            int closestArr[] = new int[k];
            float closestVal[] = new float[k];
            float distanceArr[] = new float[trainResArr.length];
            for(int j=0; j<trainResArr.length; j++){
                double val = pow((a-trainArr[j*2]),2) + pow((b-trainArr[j*2+1]),2);
                distanceArr[j] = (float)sqrt(val);
            }
            System.out.printf("\n");

            closestVal[0] = distanceArr[0];
            closestArr[0] = 0;
            boolean found = false;
            for(int q=0; q<k; q++){
                for(int w=0; w<distanceArr.length; w++){
                    for(int e=0; e<q; e++){
                        if(distanceArr[w]==closestVal[e]){
                            w++;
                            break;
                        }
                    }
                    if(w<distanceArr.length && closestVal[q]>distanceArr[w]){
                        System.out.printf("%f New Closest: %f\n", closestVal[q], distanceArr[w]);
                        closestVal[q] = distanceArr[w];
                        closestArr[q] = w;
                    }
                }
            }
            int tCount = 0, fCount = 0;
            System.out.printf("Closest Values: ");
            for(int j=0; j<k; j++){
                System.out.printf("%f, ", closestVal[j]);
                if(trainResArr[closestArr[j]]=="T")
                    tCount++;
                else
                    fCount++;
            }
            System.out.printf("\n Result: %s\n", result);
            if(tCount>fCount)
                result = "T";
            else
                result = "F";
            
            
            if(result.compareTo(testResArr[i])==0)
                correct = correct+1;
        }
        
        float total = correct/testResArr.length;
        return total;
    }
    
    static float testNEuc(int k){
        float accur = 0;
        return accur;
    }
}
        /*
        try {
            File file = new File("src/knn/KNNknown.txt");
            Scanner scan = new Scanner(file);
            knnkArr = new String[100];
            int k=0;
            while(scan.hasNextLine()){
                String line = scan.nextLine();//used to clear header lines
                String fullString = "";
                for(int i=0; i<17 && scan.hasNextLine(); i++){
                    line = scan.nextLine();
                    fullString = fullString+line;
                }
                knnkArr[k] = fullString;
                //if(k==10)
                //    System.out.printf(" testing: %s\n", fullString);
                if(scan.hasNextLine())
                    line = scan.nextLine(); //used to clear empty lines
                k++;
            }
            
            knnuArr = new String[10];
            File file2 = new File("src/knn/KNNunknown.txt");
            Scanner scan2 = new Scanner(file2);
            k = 0;
            while(scan2.hasNextLine()){
                String line = scan2.nextLine();
                String fullString = "";
                for(int i=0; i<17 && scan2.hasNextLine(); i++){
                    line = scan2.nextLine();
                    fullString = fullString+line;
                }
                caniArr[k] = fullString;
                if(scan2.hasNextLine())
                    line = scan2.nextLine();
                k++;
            }

            dataArr2 = new String[100];
            File file3 = new File("src/hashtable/data2.txt");
            Scanner scan3 = new Scanner(file3);
            k = 0;
            while(scan3.hasNextLine()){
                String line = scan3.nextLine();
                String fullString = "";
                for(int i=0; i<17 && scan3.hasNextLine(); i++){
                    line = scan3.nextLine();
                    fullString = fullString+line;
                }
                dataArr2[k] = fullString;
                if(scan3.hasNextLine())
                    line = scan3.nextLine();
                k++;
            }

            caniArr2 = new String[10];
            File file4 = new File("src/hashtable/candidate2.txt");
            Scanner scan4 = new Scanner(file4);
            k = 0;
            while(scan4.hasNextLine()){
                String line = scan4.nextLine();
                if(scan4.hasNextLine()){
                    line = scan4.nextLine();
                    caniArr2[k] = line;
                }
                if(scan4.hasNextLine())
                    line = scan4.nextLine();
                k++;
            }            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DTuraKNN.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.printf("Slow Search for Data1:\n");
        long startTime = System.currentTimeMillis();
        slowSearch();
        long endTime = System.currentTimeMillis();
        System.out.printf("Total time for long run is: %d milliseconds\n\n", endTime-startTime);
        
        
        System.out.printf("Hash Table Search for Data1:\n");
        startTime = System.currentTimeMillis();                   
        int capa = 125, loadFac = 80;
        tb = new HashTable<>(capa, loadFac);
        String mem;
        for(int k=0; k<100; k++){
            mem = dataArr[k];
            tb.put(mem);
            checkRehash();
        }
        System.out.printf("Hash Table created with capacity of: %d \n", capa);
        
        //displayTBContents();
        
        searchCani();
        
        endTime = System.currentTimeMillis();
        System.out.printf("Total time for hash run on data1 is: %d milliseconds\n\n", endTime-startTime);        
        
        
        System.out.printf("Slow Search for Data2:\n");
        startTime = System.currentTimeMillis();
        slowSearch2();
        endTime = System.currentTimeMillis();
        System.out.printf("Total time for long run Data 2 is: %d milliseconds\n\n", endTime-startTime);
        
        System.out.printf("Hash Table Search for Data2:\n");
        startTime = System.currentTimeMillis();
        int pos = -1;
        boolean found = false;
        int k = 0;
        for(int i=0; i<10; i++){
            for(; k<100; k++){
                ih = new ItemHash(caniArr2[i], dataArr2[k]);
                pos = ih.searchData();
                if(pos >=0){
                    System.out.printf("Canidate %d found in data %d \n\n", i, k, pos);
                    found = true;
                    pos = -1;
                }
            }
            if(!found)
                System.out.printf("Canidate %d not found\n", i);
            found = false;
            k = 0;
        }
        endTime = System.currentTimeMillis();
        System.out.printf("Total time for hash run on data2 is: %d milliseconds\n\n", endTime-startTime);        
        
        
        System.out.printf("\n\n Complete \n\n");
    }
        
    static void checkRehash() {
        if (tb.size() > (tb.capacity()/100)*tb.MLF){
            tb.rehash();
        }
    }
    
    static void displayTBContents () {
        System.out.printf("\tObject   \t\t\t\t\tCurrent    Home    Offset \n");
        for (int i=0; i<tb.capacity(); i++){
            display(i);
        }
    }
    
    static void searchCani() {
        int pos = 0;
        for(int i=0; i<10; i++){
            String v = caniArr[i];
            pos = tb.searchT(v);
            if (pos < 0)System.out.printf("ID %d not found\n", i);
            else {
                System.out.printf("ID %d found at pos: %d : \n %s\n ", i, pos, caniArr[i]);
                display(pos);
            }
        }        
    }
    
    static void slowSearch(){
        boolean found = false;
        for(int i=0; i<10; i++){
            for (int k=0; k<100; k++){
                if(dataArr[k].compareTo(caniArr[i]) == 0){
                    System.out.printf("ID %d found at %d : \n %s\n %s\n", i, k,caniArr[i], dataArr[k]);
                    found = true;
                }
            }
            if(!found)
                System.out.printf("ID %d not found\n", i);
            found = false;
        }
    }
    
    static void slowSearch2(){
        boolean found = false;
        for(int i=0; i<10; i++){
            for (int k=0; k<100; k++){
                String canidate = caniArr2[i];
                String data = dataArr2[k];
                String fullstrn;
                char[] strn = new char[canidate.length()];
                int t=0;
                while(t<data.length()-canidate.length()){
                    data.getChars(t, t+canidate.length(), strn, 0);
                    fullstrn = new String(strn);                
                    if(fullstrn.compareTo(canidate) == 0){
                        System.out.printf("Canidate %d found at %d : \n %s\n", i, k,caniArr2[i]);
                        found = true;
                    }
                    t++;
                }
            }
            if(!found)
                System.out.printf("ID %d not found\n", i);
            found = false;
        }
    }
    
    static void display(int pos){
        String v = tb.get(pos);
        int home = tb.home(v);
        int offset = tb.distance(home, pos);
        System.out.printf("%-46s %7d %7d %7d\n", v, pos, home,offset);
    }
    
}*/
