package knn;
/**
 *
 * @author dturack
 */
public interface DataConst {
    
	String menu = new StringBuilder(50).append("\t+===========================================================================================================================+\n" )
.append("|                                               Implementation of Hash Table                                                |\n" )
.append("|                                                       Assignment 2                                                        |\n" )
.append("+===========================================================================================================================+\n" )
.append("| Command  |                   Description                    | Command  |                   Description                    |\n" )
.append("+----------+--------------------------------------------------+----------+--------------------------------------------------\n" )
.append("|   g G    |  Prompt for two intergers, the capacity and the  |   t T    | Perform a successful search on each of object in |\n" )
.append("|          |  load factor of a hash table. Create a new hash  |show Time | the hash table, and 'capacity' many unsuccessful |\n" )
.append("|          |table, with 20% as increment percentage, generate |Complexity| searches, list the (1) avareage comparions from  |\n" )
.append("|          |(capacity * load factor) many mixed Member objects|of Bin. & |all successful searchs, the theoretic susccessful |\n" )
.append("|          |         and add them to the hash table.          |Hash. Srch|search complexity [(1 + 1/(1-a))/2], and the      |\n" )
.append("+----------+--------------------------------------------------+See exampl|theoretical un-successful search time complexity  |\n" )
.append("|   a A    | Instanciate a new member object, and the object  |e below.  |[(1+1/(1-a)**2)/2], where a is the loading factor.|\n" )
.append("|          |   into the hash table. Display the newly added   +----------+--------------------------------------------------+\n" )
.append("|          |  member, its home address and current address.   |   b B    |Display information on blocks formed by contiguous|\n" )
.append("+----------+--------------------------------------------------+          |data or empty cells inside table. For each block, |\n" )
.append("|   r R    | Ask for an ID or hash code of an object. Remove  |          |display the type of block (either data or empty), |\n" )
.append("|          |     the object whose ID matchs the given ID.     |          |the starting and ending addresses, size of block. |\n" )
.append("+----------+--------------------------------------------------+          |At the end of block listing, show the total number|\n" )
.append("|   f F    |   Ask for an ID or hash code, of a object,       |          |   of blocks, the maximum, the minimum and the    |\n" )
.append("|          | display the object, ID current address and home  |          |  average block sizes, for each type. Allow quit  |\n" )
.append("|          |                     address.                     |          | listing the total, maximum, minimum and average  |\n" )
.append("+----------+--------------------------------------------------+          |must show the correct data even if the listing of |\n" )
.append("|   c C    |Show contents of hash table in a tabular way. one |          |                   block ends.                    |\n" )
.append("|          | object per line and ten objects per screen. for  +----------+--------------------------------------------------+\n" )
.append("|          |   each line, the following columns have to be    |   p P    |List the table parameters. The parameters include.|\n" )
.append("|          | displayed: OBject, current address, home address |          |    the capacity, size, load factor, increment    |\n" )
.append("|          |  and the displacement from home address to its   |          |      percentage,and the actual load factor.      |\n" )
.append("|          |                 current address.                 +----------+--------------------------------------------------+\n" )
.append("+----------+--------------------------------------------------+   v V    |    Verify whether all non-null elements in table |\n" )
.append("|  i I x   |   Remove object at table index to test Verify    |          |         are rearchable or not.                   |\n" )
.append("+----------+--------------------------------------------------+----------+--------------------------------------------------+\n" )
.append("|  h H ?   |                 Show this menu.                  |   q Q    |                Exit the program.                 |\n" )
.append("+----------+--------------------------------------------------+----------+--------------------------------------------------+\n").toString();
}
