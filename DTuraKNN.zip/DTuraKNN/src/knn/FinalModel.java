/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package knn;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

/**
 *
 * @author student
 */
public class FinalModel {
    public static void calc(float [] input, float [] unknown, float [] known, String [] knownRes){
        int k = (int)input[1];
        int method = (int)input[2];
        switch(method){
            case 0:
                System.out.printf("Final Model: Euclidean with K= %d and an test accuracy of: %f\n", k, input[0]);
                EucMethod(k, unknown, known, knownRes);
                break;
            case 1:
                System.out.printf("Final Model: Normalized Euclidean with K= %d and an test accuracy of: %f\n", k, input[0]);
                NormEucMethod(k, unknown, known, knownRes);
                break;
            default:
                System.out.printf("Invalid imput\n");
                break;
        }
    }
    public static void EucMethod(int k, float[]ukn, float[]kn, String[]krs){
        float correct = 0;

        String result = null;
        for(int i=0; i<ukn.length/2; i++){
            float a = ukn[i*2];
            float b = ukn[i*2+1];
            System.out.printf("Values: %f   %f ",a,b);
            int closestArr[] = new int[k];
            float closestVal[] = new float[k];
            float distanceArr[] = new float[krs.length];
            for(int j=0; j<krs.length; j++){
                double val = pow((a-kn[j*2]),2) + pow((b-kn[j*2+1]),2);
                distanceArr[j] = (float)sqrt(val);
            }
            for(int q=0; q<k; q++){
                closestVal[q] = distanceArr[0];
                closestArr[q] = 0;
                for(int w=0; w<distanceArr.length; w++){
                    for(int e=0; e<q; e++){
                        if(distanceArr[w]==closestVal[e]){
                            w++;
                            break;
                        }
                    }
                    if(w<distanceArr.length && closestVal[q]>distanceArr[w]){
                        //System.out.printf("%f New Closest: %f\n", closestVal[q], distanceArr[w]);
                        closestVal[q] = distanceArr[w];
                        closestArr[q] = w;
                    }
                }
            }
            int tCount = 0, fCount = 0;
            //System.out.printf("Closest Values: ");
            for(int j=0; j<k; j++){
                //System.out.printf("%s, ", trainResArr[closestArr[j]]);
                if(krs[closestArr[j]].compareTo("F")==0)
                    fCount++;
                else
                    tCount++;
            }
            //System.out.printf("\n Result: %s\n", result);
            if(tCount>fCount)
                result = "T";
            else
                result = "F";
            
            
            System.out.printf("Result: %s \n", result);
        }
    }
    public static void NormEucMethod(int k, float[]ukn, float[]kn, String[]krs){
        float correct = 0;

        String result = null;
        for(int i=0; i<ukn.length/2; i++){
            int closestArr[] = new int[k];
            float closestVal[] = new float[k];
            float distanceArr[] = new float[krs.length];
            float [] normArr = new float[kn.length];
            float max1 = 0, min1 = 100, max2 = 0, min2 = 100;
            for(int r=0; r<krs.length; r++){
                max1 = max1 < kn[r*2] ? kn[r*2] : max1;
                max2 = max2 < kn[r*2+1] ? kn[r*2+1] : max2;
                min1 = min1 < kn[r*2] ? kn[r*2] : min1;
                min2 = min2 < kn[r*2+1] ? kn[r*2+1] : min2;
            }
            for(int p=0; p<krs.length; p++){
                normArr[p*2] = (kn[p*2]-min1)/(max1-min1);
                normArr[p*2+1] = (kn[p*2+1]-min2)/(max2-min2);
            }
            float a = (ukn[i*2]-min1)/(max1-min1);
            float b = (ukn[i*2+1]-min2)/(max2-min2);
            System.out.printf("Values: %f   %f ",a,b);
            for(int j=0; j<krs.length; j++){
                double val = pow((a-normArr[j*2]),2) + pow((b-normArr[j*2+1]),2);
                distanceArr[j] = (float)sqrt(val);
                //System.out.printf("%f, ", distanceArr[j]);
            }
            for(int q=0; q<k; q++){
                closestVal[q] = distanceArr[0];
                closestArr[q] = 0;
                for(int w=0; w<distanceArr.length; w++){
                    for(int e=0; e<q; e++){
                        if(distanceArr[w]==closestVal[e]){
                            w++;
                            break;
                        }
                    }
                    if(w<distanceArr.length && closestVal[q]>distanceArr[w]){
                        //System.out.printf("%f New Closest: %f\n", closestVal[q], distanceArr[w]);
                        closestVal[q] = distanceArr[w];
                        closestArr[q] = w;
                    }
                }
            }
            int tCount = 0, fCount = 0;
            //System.out.printf("Closest Values: ");
            for(int j=0; j<k; j++){
                //System.out.printf("%s, ", trainResArr[closestArr[j]]);
                if(krs[closestArr[j]].compareTo("F")==0)
                    fCount++;
                else
                    tCount++;
            }
            //System.out.printf("\n Result: %s\n", result);
            if(tCount>fCount)
                result = "T";
            else
                result = "F";
            
            
            System.out.printf("Result: %s \n", result);
        }
    }
}
