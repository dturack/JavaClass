
package hashtable;

import static java.lang.Math.abs;
import java.util.Arrays;

/**
 *
 * @author dturack
 * @param <T>
 */
public class HashTable<T extends Comparable> {
    int capacity = 125, MLF = 80, size = 0, increment=20;
    
    T table[] = null;
    
    @SuppressWarnings("unchecked")
    public HashTable() {
        table = (T[]) new String[capacity];
    }
    
    @SuppressWarnings("unchecked")
    public HashTable(int cap, int mlf){
        capacity = cap; MLF = mlf;
        table = (T[]) new String[capacity];        
    }
    
    protected int hash(T v) { 
        if (v == null)
            return 0;
        int hash = 17;
        hash = (hash * 31 + abs(v.hashCode()));
        return  hash % capacity;
    }
    
    public int home(T v){
        return hash(v);
    }
    public void rehash(){
        int capa = this.capacity;
        T[] oldHT = this.table;
        capacity = capacity + (int)(capacity*(increment/100.0f));
        T v;
        table = (T[]) new String[capacity];
        for(int i=0; i<capa; i++){
            size = 0;
            if(oldHT[i] != null){
                this.put(oldHT[i]);
            }
        }
    }
    
    public int size() {return size;}
    public int capacity() {return capacity;}
    public T get(int i){return i<0 || i>= capacity ? null : table[i];}
    public int distance(int from, int to){
        return to >= from ? to - from : (capacity - from) + to;
    }
    
    public T put(T v) {
        //if (size() > (capacity()/100)*MLF) rehash();
        int home = hash(v);
        while(table[home] != null) 
            home  = (home + 1) % capacity;
        table[home] = v;
        size++;
        return v;
    }
    
    public int searchT(T v){
        int home = hash(v);
        while(table[home]!= null && v.compareTo(table[home]) != 0)
            home = (home+1) % capacity;
        if (table[home]==null)
            return -1;
        return home;
    }
    
    public T remove(T v){
        int home = hash(v);
        while(table[home] != null && v.compareTo(table[home]) !=0)
            home = (home + 1) % capacity;
        if ( table[home] == null) return null;
        
        v = table[home];
        table[home] = null;
        size--;
        shift(home, (home+1)%capacity);
        return v;        
    }
    
    public T removeIndex(int idx){
        if (table[idx] == null) return null;
        
        T v = table[idx];
        table[idx] = null;
        size--;
        return v;
    }
    
    protected void shift(int blank, int nxt){
        if (table[nxt] == null) return;
        int home  = home(table[nxt]);
        int distCH = distance(home, nxt);
        int distBH = distance(home, blank);
        
        if ( distBH < distCH){
            table[blank] = table[nxt];
            table[nxt] = null;
            shift(nxt, (nxt+1)%capacity);
        }else shift(blank, (nxt+1)%capacity);
    }
}
