/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashtable;

/**
 *
 * @author student
 */
public class ItemHash <T extends Comparable>{
    String data;
    String canidate;
    static HashTable<String> tb2 = new HashTable();

    public ItemHash (String search, String text){
        data = text;
        canidate = search;
    }
    
    public int searchData(){
        String dArr[] = new String[data.length()-canidate.length()];
        int k=0;
        int pos = -1;
        String fullstrn;
        char[] strn = new char[canidate.length()];
        while(k<data.length()-canidate.length()){
            data.getChars(k, k+canidate.length(), strn, 0);
            fullstrn = new String(strn);
            dArr[k] = fullstrn;
            k++;
        }

        int capacity = (data.length()-canidate.length());
        int MLF = 80;
        tb2 = new HashTable<>(capacity, MLF);
        String mem;
        for(k=0; k<dArr.length; k++){
            mem = dArr[k];
            tb2.put(mem);
            checkRehash();
        }
        pos = tb2.searchT(canidate);
        
        if(pos>=0){
            System.out.printf("HashTable Location: %d \n%s\n%s\n", pos, canidate, tb2.get(pos));
        }
         
        return pos;
    }
    
    static void checkRehash() {
        if (tb2.size() > (tb2.capacity()/100)*tb2.MLF){
            tb2.rehash();
        }
    }
    
}
