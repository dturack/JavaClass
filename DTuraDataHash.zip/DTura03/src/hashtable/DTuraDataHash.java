package hashtable;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dturack
 */
public class DTuraDataHash{

    /**
     * @param args the command line arguments
     */
    
    static HashTable<String> tb = new HashTable<>();
    static Random rdn = new Random();
    static String dataArr[];
    static String caniArr[];
    public static void main(String[] args) {
        try {
            File file = new File("src/hashtable/data1.txt");
            Scanner scan = new Scanner(file);
            dataArr = new String[100];
            int k=0;
            while(scan.hasNextLine()){
                String line = scan.nextLine();
                String fullString = "";
                for(int i=0; i<17 && scan.hasNextLine(); i++){
                    line = scan.nextLine();
                    fullString = fullString+line;
                }
                dataArr[k] = fullString;
                if(k==10)
                    System.out.printf(" testing: %s\n", fullString);
                if(scan.hasNextLine())
                    line = scan.nextLine();
                k++;
            }
            
            caniArr = new String[10];
            File file2 = new File("src/hashtable/candidate1.txt");
            Scanner scan2 = new Scanner(file2);
            k = 0;
            while(scan2.hasNextLine()){
                String line = scan2.nextLine();
                String fullString = "";
                for(int i=0; i<17 && scan2.hasNextLine(); i++){
                    line = scan2.nextLine();
                    fullString = fullString+line;
                }
                caniArr[k] = fullString;
                if(scan2.hasNextLine())
                    line = scan2.nextLine();
                k++;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DTuraDataHash.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        slowSearch();
                           
        int capa = 125, loadFac = 80;
        tb = new HashTable<>(capa, loadFac);
        String mem;
        for(int k=0; k<100; k++){
            mem = dataArr[k];
            tb.put(mem);
            checkRehash();
        }
        System.out.printf("Hash Table created with capacity of: %d \n", capa);
        
        //displayTBContents();
        
        searchCani();
        
        System.out.printf("\n\n Complete \n\n");
    }
        
//}
    
    /*static public void tabVerify(){
        Data vt, vt2;
        int i=0;
        boolean suc = true;
        for(; i<tb.capacity(); i++){
            vt = tb.get(i); 
            if (vt==null)
                continue;
            int loc = tb.hash(vt);
            vt2 = tb.get(loc);
            if(vt2 == null )
                System.out.printf("Element error mismatch: \n at %d:  %s and \n%s at home location: %d\n", i, vt, vt2, loc); suc = false;
        }
        if(suc)
            System.out.printf("Table Verify Suceeded, Elements tested: %d\n", i);
        else
            System.out.printf("Table Verify Failed, Elements tested: %d\n", i);
    }
    
    static public void displayBlocks(){
        System.out.printf("+===================================================+\n");
        System.out.printf("|       Information on Data and Blank Blocks        |\n");
        System.out.printf("+===================================================+\n");
        System.out.printf("| Block Type |  Starting  |   Ending   |    Size    |\n");
        System.out.printf("|            |  Address   |  Address   |            |\n");
        System.out.printf("+===================================================+\n");
        int dTot=0, dMax=0, dMin=10, dAvg=0;
        int eTot=0, eMax=0, eMin=10, eAvg=0;
        int recNum = 0;
        for(int i=0; i<tb.capacity()-1; ){
            int tempi = i, nullcnt = 0;
            while(tb.table[i]==null&&i<tb.capacity()-1){
                nullcnt++;
                i++;
            }
            if(tempi!=i){
                System.out.printf("|    Empty   |     %-2d     |     %-2d     |     %-2d    |\n", tempi, i-1, nullcnt);
                eTot++; eAvg += nullcnt;
                if(nullcnt>eMax)
                    eMax = nullcnt;
                if(nullcnt<eMin)
                    eMin = nullcnt;
                recNum++;
                if(recNum%10==0){
                    System.out.printf("Enter q/Q to quit listing or c/C to continue: ");
                    String selc = scan.next();
                    if("q".equals(selc) || "Q".equals(selc))
                        break;
                }
            }
            int nnullcnt = 0;
            tempi = i;
            System.out.printf("+------------+------------+------------+-----------+\n");
            while(tb.table[i]!=null&&i<tb.capacity()-1){
                nnullcnt++;
                i++;
            }
            if(tempi!=i){
                System.out.printf("|    Data    |     %-2d     |     %-2d     |     %-2d    |\n", tempi, i-1, nnullcnt);
                dTot++; dAvg += nnullcnt;
                if(nnullcnt>dMax)
                    dMax = nnullcnt;
                if(nnullcnt<dMin)
                    dMin = nnullcnt;
                recNum++;
                if(recNum%10==0){
                    System.out.printf("Enter q/Q to quit listing or c/C to continue: ");
                    String selc = scan.next();
                    if("q".equals(selc) || "Q".equals(selc))
                        break;
                }
            }
            System.out.printf("+------------+------------+------------+-----------+\n");
        }
        System.out.printf("|  Block Type  Count   Maximum Minimum    Avg Size |\n");
        System.out.printf("|    Data        %-2d      %-2d      %-2d       %.4f   |\n", dTot, dMax, dMin, (float)dAvg/dTot);
        System.out.printf("|    Empty       %-2d      %-2d      %-2d       %.4f   |\n", eTot, eMax, eMin, (float)eAvg/eTot);
        System.out.printf("+--------------------------------------------------+\n");
        System.out.printf("\n");
    }
    
    static public void tabParam(HashTable tb){
        System.out.printf("+================================================================+\n");
        System.out.printf("|                  Parameters of The Hash Table                  |\n");
        System.out.printf("+================================================================+\n");
        System.out.printf("|  Capacity  |    Size    | Increment  | Specified  |Actual Load |\n");
        System.out.printf("|            |            |            |Load Factor |   Factor   |\n");
        System.out.printf("+================================================================+\n");
        System.out.printf("|     %-3d    |     %-3d    |     %-3d    |     %-3d    |    %-3d     |\n", tb.capacity(), tb.size(), 100-tb.MLF, tb.MLF, tb.MLF);
        System.out.printf("+================================================================+\n");
    }
    
    static public void createTable(){                   
        int capa, loadFac;
        System.out.printf("Enter Capacity: ");
        capa = scan.nextInt();
        System.out.printf("Enter Load Factor:  ");
        loadFac = scan.nextInt();
        tb = new HashTable<>(capa, loadFac);
        makeMembers((int) (tb.capacity()*tb.MLF/100.0f)-1);
        System.out.printf("Hash Table created with capacity of: %d \n", capa);
    }
    
    public static void removeIndex(){
        System.out.printf("Please enter index to remove: ");
        int selcRM = scan.nextInt();
        Data result = tb.removeIndex(selcRM);
        if(result == null)
            System.out.printf("Index already empty\n");
        else
            System.out.printf("Element removed: %s\n", result);
    }
    
    public static void removeID(){
        System.out.printf("Please enter ID to remove: ");
        int selcRM = scan.nextInt();
        Data v = tb.get(selcRM%tb.capacity());
        int home = tb.hash(v);
        if(tb.get(home)!=null){
            while(tb.get(home).ID != selcRM){
                home = (home+1) % tb.capacity();
                if(tb.get(home)==null)
                    break;
            }
        }
        if (tb.get(home)==null)System.out.printf("ID not found\n");
        else {
            Data result = tb.remove(tb.get(home));
            System.out.printf("Member removed %s\n", result);
        }
    }
    
    public static void makeMembers(int count){
        Data mem = null;
        for(int k=0; k<count; k++){
            mem = new Data();
            tb.put(mem);
        }
    }
    */
    static void checkRehash() {
        if (tb.size() > (tb.capacity()/100)*tb.MLF){
            tb.rehash();
        }
    }
    
    static void displayTBContents () {
        System.out.printf("\tObject   \t\t\t\t\tCurrent    Home    Offset \n");
        for (int i=0; i<tb.capacity(); i++){
            display(i);
        }
    }
    /*
    static void timeComplex() {
        System.out.printf("+================================================================+\n");
        System.out.printf("|      Time Complexities of Practical & Theoretic Hashtable      |\n");
        System.out.printf("|          Search vs. Theoretic Binary Search Algorithm          |\n");
        System.out.printf("+================================================================+\n");
        System.out.printf("| Practical  | Practical  | Theoretic  | Theoretic  |Theoretical |\n");
        System.out.printf("| Hashtable  | Hashtable  | Hashtable  | Hashtable  |   Binary   |\n");
        System.out.printf("| Successful |Unsuccessful| Successful |Unsuccessful|   Search   |\n");
        System.out.printf("|   Search   |   Search   |   Search   |   Search   |            |\n");
        System.out.printf("+================================================================+\n");
        System.out.printf("|    2.49    |   12.26    |    2.63    |    7.50    |    5.76    |\n");
        System.out.printf("+================================================================+\n");
    }
    */
    static void searchCani() {
        int pos = 0;
        for(int i=0; i<10; i++){
            String v = caniArr[i];
            pos = tb.searchT(v);
            if (pos < 0)System.out.printf("ID %d not found\n", i);
            else {
                System.out.printf("ID %d found at pos: %d", i, pos);
                display(pos);
            }
        }        
    }
    
    static void slowSearch(){
        boolean found = false;
        for(int i=0; i<10; i++){
            for (int k=0; k<100; k++){
                if(dataArr[k].compareTo(caniArr[i]) == 0){
                    System.out.printf("ID %d found at %d\n", i, k);
                    found = true;
                }
            }
            if(!found)
                System.out.printf("ID %d not found\n", i);
            found = false;
        }
    }
    
    static void display(int pos){
        String v = tb.get(pos);
        int home = tb.home(v);
        int offset = tb.distance(home, pos);
        System.out.printf("\t%-46s %7d %7d %7d\n", v, pos, home,offset);
    }
    
}
