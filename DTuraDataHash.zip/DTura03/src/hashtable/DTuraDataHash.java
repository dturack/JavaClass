package hashtable;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dturack
 */
public class DTuraDataHash{

    /**
     * @param args the command line arguments
     */
    
    static HashTable<String> tb = new HashTable<>();
    static ItemHash ih;
    static Random rdn = new Random();
    static String dataArr[];
    static String caniArr[];
    static String dataArr2[];
    static String caniArr2[];
    public static void main(String[] args) {
        try {
            File file = new File("src/hashtable/data1.txt");
            Scanner scan = new Scanner(file);
            dataArr = new String[100];
            int k=0;
            while(scan.hasNextLine()){
                String line = scan.nextLine();//used to clear header lines
                String fullString = "";
                for(int i=0; i<17 && scan.hasNextLine(); i++){
                    line = scan.nextLine();
                    fullString = fullString+line;
                }
                dataArr[k] = fullString;
                //if(k==10)
                //    System.out.printf(" testing: %s\n", fullString);
                if(scan.hasNextLine())
                    line = scan.nextLine(); //used to clear empty lines
                k++;
            }
            
            caniArr = new String[10];
            File file2 = new File("src/hashtable/candidate1.txt");
            Scanner scan2 = new Scanner(file2);
            k = 0;
            while(scan2.hasNextLine()){
                String line = scan2.nextLine();
                String fullString = "";
                for(int i=0; i<17 && scan2.hasNextLine(); i++){
                    line = scan2.nextLine();
                    fullString = fullString+line;
                }
                caniArr[k] = fullString;
                if(scan2.hasNextLine())
                    line = scan2.nextLine();
                k++;
            }

            dataArr2 = new String[100];
            File file3 = new File("src/hashtable/data2.txt");
            Scanner scan3 = new Scanner(file3);
            k = 0;
            while(scan3.hasNextLine()){
                String line = scan3.nextLine();
                String fullString = "";
                for(int i=0; i<17 && scan3.hasNextLine(); i++){
                    line = scan3.nextLine();
                    fullString = fullString+line;
                }
                dataArr2[k] = fullString;
                if(scan3.hasNextLine())
                    line = scan3.nextLine();
                k++;
            }

            caniArr2 = new String[10];
            File file4 = new File("src/hashtable/candidate2.txt");
            Scanner scan4 = new Scanner(file4);
            k = 0;
            while(scan4.hasNextLine()){
                String line = scan4.nextLine();
                if(scan4.hasNextLine()){
                    line = scan4.nextLine();
                    caniArr2[k] = line;
                }
                if(scan4.hasNextLine())
                    line = scan4.nextLine();
                k++;
            }            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DTuraDataHash.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.printf("Slow Search for Data1:\n");
        long startTime = System.currentTimeMillis();
        slowSearch();
        long endTime = System.currentTimeMillis();
        System.out.printf("Total time for long run is: %d milliseconds\n\n", endTime-startTime);
        
        
        System.out.printf("Hash Table Search for Data1:\n");
        startTime = System.currentTimeMillis();                   
        int capa = 125, loadFac = 80;
        tb = new HashTable<>(capa, loadFac);
        String mem;
        for(int k=0; k<100; k++){
            mem = dataArr[k];
            tb.put(mem);
            checkRehash();
        }
        System.out.printf("Hash Table created with capacity of: %d \n", capa);
        
        //displayTBContents();
        
        searchCani();
        
        endTime = System.currentTimeMillis();
        System.out.printf("Total time for hash run on data1 is: %d milliseconds\n\n", endTime-startTime);        
        
        
        System.out.printf("Slow Search for Data2:\n");
        startTime = System.currentTimeMillis();
        slowSearch2();
        endTime = System.currentTimeMillis();
        System.out.printf("Total time for long run Data 2 is: %d milliseconds\n\n", endTime-startTime);
        
        System.out.printf("Hash Table Search for Data2:\n");
        startTime = System.currentTimeMillis();
        int pos = -1;
        boolean found = false;
        int k = 0;
        for(int i=0; i<10; i++){
            for(; k<100; k++){
                ih = new ItemHash(caniArr2[i], dataArr2[k]);
                pos = ih.searchData();
                if(pos >=0){
                    System.out.printf("Canidate %d found in data %d \n\n", i, k, pos);
                    found = true;
                    pos = -1;
                }
            }
            if(!found)
                System.out.printf("Canidate %d not found\n", i);
            found = false;
            k = 0;
        }
        endTime = System.currentTimeMillis();
        System.out.printf("Total time for hash run on data2 is: %d milliseconds\n\n", endTime-startTime);        
        
        
        System.out.printf("\n\n Complete \n\n");
    }
        
    static void checkRehash() {
        if (tb.size() > (tb.capacity()/100)*tb.MLF){
            tb.rehash();
        }
    }
    
    static void displayTBContents () {
        System.out.printf("\tObject   \t\t\t\t\tCurrent    Home    Offset \n");
        for (int i=0; i<tb.capacity(); i++){
            display(i);
        }
    }
    
    static void searchCani() {
        int pos = 0;
        for(int i=0; i<10; i++){
            String v = caniArr[i];
            pos = tb.searchT(v);
            if (pos < 0)System.out.printf("ID %d not found\n", i);
            else {
                System.out.printf("ID %d found at pos: %d : \n %s\n ", i, pos, caniArr[i]);
                display(pos);
            }
        }        
    }
    
    static void slowSearch(){
        boolean found = false;
        for(int i=0; i<10; i++){
            for (int k=0; k<100; k++){
                if(dataArr[k].compareTo(caniArr[i]) == 0){
                    System.out.printf("ID %d found at %d : \n %s\n %s\n", i, k,caniArr[i], dataArr[k]);
                    found = true;
                }
            }
            if(!found)
                System.out.printf("ID %d not found\n", i);
            found = false;
        }
    }
    
    static void slowSearch2(){
        boolean found = false;
        for(int i=0; i<10; i++){
            for (int k=0; k<100; k++){
                String canidate = caniArr2[i];
                String data = dataArr2[k];
                String fullstrn;
                char[] strn = new char[canidate.length()];
                int t=0;
                while(t<data.length()-canidate.length()){
                    data.getChars(t, t+canidate.length(), strn, 0);
                    fullstrn = new String(strn);                
                    if(fullstrn.compareTo(canidate) == 0){
                        System.out.printf("Canidate %d found at %d : \n %s\n", i, k,caniArr2[i]);
                        found = true;
                    }
                    t++;
                }
            }
            if(!found)
                System.out.printf("ID %d not found\n", i);
            found = false;
        }
    }
    
    static void display(int pos){
        String v = tb.get(pos);
        int home = tb.home(v);
        int offset = tb.distance(home, pos);
        System.out.printf("%-46s %7d %7d %7d\n", v, pos, home,offset);
    }
    
}
