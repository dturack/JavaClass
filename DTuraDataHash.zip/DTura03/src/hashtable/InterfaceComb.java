package hashtable;

/**
 *
 * @author dturack
 */
public interface InterfaceComb extends java.lang.Comparable<String>, java.io.Serializable {
    
}
