package dtura10;

import java.io.ObjectOutputStream;
import java.io.Serializable;;
import java.util.StringTokenizer;

//class keeps track of visitor information for groups
public class Visitor implements Comparable<Visitor>, Serializable {

    public int	    ID ;
    public String    name   ;   // visitor's name
    public boolean   checked = true ;  // check to receive private message
    public ObjectOutputStream out ;   // output stream to the visitor

    // used on chatroom server side to add visitor to server list.
    public Visitor( ObjectOutputStream out ) { set(-1, null, true, out ); }
  
    //default initializer
    public Visitor( ) { set(-1, null, true, null) ; }
    //initializer to set the visitor ID number
    public Visitor(int id ) { set( id, "", true, null) ; }
    //initializer to set all visitor data from visitor object
    public Visitor(Visitor v ) { set(v.ID, v.name, v.checked, v.out) ; }
    //initializer to set only visitor name
    public Visitor( String name ) { set(-1, name, true , null) ; }
    //initializer to set visitor name and checked status
    public Visitor( String name, boolean c ) { set(-1,  name, c, null) ; }
    //initializer to set all values manually without visitor object
    public Visitor( int id, String name, boolean c, ObjectOutputStream out ) 
    { set(id, name, c, out) ; }

    //function to call in each initializer to set all values in Visitor Object
    public void set( int id, String n, boolean ck, ObjectOutputStream o )
    { ID = id; name = n == null ? null: new String(n); checked = ck; out = o == null ? null: o ; }

    //override function to compare visitor ID numbers
    @Override
    public int 	   compareTo( Visitor v )  { return ID - v.ID; }
    //override function to check if visitor IDs are equal
    @Override
    public boolean equals( Object v )     { return  ID == (( Visitor)v).ID ; }
    //override function to format string output
    @Override
    public String  toString() { return String.format("%s_%d", name, ID); }
    //function to format string output which includes checked status
    public String  longString() {
	return String.format("%10s_%4d %5s %s", name, ID, 
		    (checked ? "true" : false), (out == null? "null": "not null" ));
    }

    //function converts a visitor string to a visitor object
    public static Visitor toVisitor( String vName_vId ) {
        if ( vName_vId == null ) return null;
	StringTokenizer tk = new StringTokenizer( vName_vId, "_; ");
	if ( ! tk.hasMoreTokens()) return null;

	String name = tk.nextToken();
	return new Visitor( Integer.parseInt( tk.nextToken() ), name, false, null );
    }
}
