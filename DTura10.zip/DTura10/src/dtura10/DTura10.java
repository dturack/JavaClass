package dtura10;

/**
 *
 * @author dturack
 */
public class DTura10 {

    /**
     * @param args the command line arguments
     * Main class file which can autorun multiple instances of Client program. 
     * However, with this setup, if one is closed, all programs will close.
     * It is better to start the Client programs individually
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Client.main(args);
        Client.main(args);
        Client.main(args);
    }
    
}
