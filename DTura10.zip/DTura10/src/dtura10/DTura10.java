package dtura10;

import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dturack
 */
public class DTura10 {

    /**
     * @param args the command line arguments
     * Main class file which can autorun multiple instances of Client program. 
     * However, with this setup, if one is closed, all programs will close.
     * It is better to start the Client programs individually
     */
    public static void main(String[] args) {
        // Programs must be started in this order
        //  Server.java; //must be started seperately
        // Agent.jave; //start however many agents are wanted 
        // Client.java; //add number of desired clients
    }
    
}
