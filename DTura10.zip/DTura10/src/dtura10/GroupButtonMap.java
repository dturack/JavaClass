package dtura10;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.Font;
import java.util.HashMap;
/** GroupButtonMap class has two Hashmaps to provide easy access from RadioButton to Group
    and from Group ID to Radio button.
    */
//class functions as the controller for the GUI features of the group buttons
class GroupButtonMap {

    int				    groupID = -1;
    String			    groupName = null;
    ButtonGroup			    buttonGroup = new ButtonGroup();
    public HashMap<JRadioButton, Group>    buttonMap = new HashMap< >();
    public HashMap<Group, JRadioButton>    groupMap = new HashMap<>();

    //default initializer function
    public GroupButtonMap () {} 

    //function to add new buttons to list of group buttons
    public void add( JRadioButton button, Group group){
	button.setFont(new Font("verdana", Font.PLAIN, 10));
	buttonGroup.add( button );
	buttonMap.put( button, group );
	groupMap.put ( group, button );
    }
    
    //function to remove a group from the list of group buttons
    public void remove( Group group ){
	buttonGroup.remove( groupMap.get( group ) );
	buttonMap.remove( groupMap.get(group) );
	groupMap.remove( group );
    }

    //function used to select a specific group
    public Group get( JRadioButton button) { return buttonMap.get( button ) ; }
    //function used to select a specifc button for group
    public JRadioButton get( Group group ) { return groupMap.get( group ) ; }

    //function used to get entire set of current groups
    public Object[] getGroupArray() { return groupMap.keySet().toArray(); }
}
