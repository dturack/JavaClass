package dtura10;

import java.awt.* ;
import java.awt.event.* ;
import javax.swing.* ;
import javax.swing.border.TitledBorder ;
import java.io.* ;
import java.util.Random ;
import java.net.* ;
import java.util.* ;
import java.util.logging.Level;
import java.util.logging.Logger;

/* Agent Class is a main class which provides functionality for the client side of the chat system
*/
public class Agent extends JFrame {

    static Random	rnd	= new Random();
    static JFrame agentWindow ;
    String titleStr = "Online Help Chat - Agent ";
    String	hostAddress = "localhost";
    // String	hostAddress = "sleipnir.cs.csub.edu";
    //String	hostAddress = "delphi.cs.csubak.edu";
    static int	port 		= 9292;
    static int	frame_height	= 450;
    static int  frame_width 	= 900;
    static int	small_width 	= 280;
    int		font_size 	= 12 ;
    int		small_font_size = 10;
    JLabel	lbNameMsg[] 	= { new JLabel("Name"), new JLabel("Messsage") };
    JTextField	tfNameMsg[] 	= { new JTextField("Anthony"), new JTextField(20) };
    public JTextArea	msgBoard	= new JTextArea() ;
    JButton     btnTransferTo   = new JButton("Transfer To:");
    JPanel      plBtnNorth      = new JPanel( new BorderLayout() );
    JPanel	plNameMsg[] = { new JPanel(), new JPanel() };
    JPanel	plSouth = new JPanel();
    JPanel	plVisitors = new JPanel( new FlowLayout( FlowLayout.LEFT ));
    JPanel	plGroups   = new JPanel( new FlowLayout( FlowLayout.LEFT ));
    JScrollPane	sclEast = new JScrollPane ();
    JScrollPane	sclWest = new JScrollPane( );
    JScrollPane	sclGroups = new JScrollPane( );
    TitledBorder  plVisitorsTitledBorder = new TitledBorder("Members");
    JPanel	plWest = new JPanel(new BorderLayout());
    TitledBorder  plGroupsTitledBorder = new TitledBorder("Agents");

    Socket	chatSocket = null;

    boolean	privateMessage = false;
    String	privateReceiverIDs;
    String	privateReceiverNames;
    boolean      justChecked    = false;
    Message 	message = new Message();

    ObjectOutputStream	out = null;  
    ObjectInputStream	in  = null; 
    VGroup       vgroup = new VGroup();
    Group		group; // shared by all clients in the same group.
    Visitor		visitor = null;
    int			groupID = 1; 
    String		groupName ; 
    String	privateList = "";
    String  	visitorName; 

    Container		c =  null;
    AAgent	aAgent	= null;

    //Initializer for Agent class which primarily sets up GUI
    public Agent ( ) { 
	sclEast.getViewport().add( plVisitors );
	sclWest.getViewport().add( plWest);
	sclGroups.getViewport().add( plGroups );
	plWest.add( sclGroups, BorderLayout.CENTER );
	c = getContentPane();
	plVisitors.setBorder( plVisitorsTitledBorder );
	plVisitors.setToolTipText("Select Member(s) to send private Message"); 
	plVisitors.setPreferredSize(new Dimension(130, frame_height));
	plVisitors.setFont(new Font("verdana", Font.PLAIN, small_font_size));	
	c.add(sclEast, BorderLayout.EAST);
	c.add(sclWest, BorderLayout.WEST);

	plGroups.setBorder( plGroupsTitledBorder );
	plWest.setPreferredSize(new Dimension(150, frame_height - 100));
	plWest.setFont(new Font("verdana", Font.PLAIN, small_font_size - 70));	
	plGroups.setPreferredSize(new Dimension(140, frame_height-100));
	plGroups.setFont(new Font("verdana", Font.PLAIN, small_font_size));
        //for (Component t: plGroups.getComponents() ) t.setEnabled(false);
        btnTransferTo.setEnabled(false );
        btnTransferTo.setToolTipText ("Transfer Client to New Agent");
        
	plBtnNorth.add( btnTransferTo, BorderLayout.CENTER);
	plWest.add( plBtnNorth, BorderLayout.NORTH );
								 
	plSouth.setLayout(new BorderLayout());

	c.setBackground(Color.black);
	msgBoard.setBackground(Color.black);
	msgBoard.setForeground(Color.yellow );
	for ( int i = 0; i < plNameMsg.length; i ++ ) {
	    plNameMsg[i].setLayout(new FlowLayout());
	    lbNameMsg[i].setFont(new Font("verdana", Font.PLAIN, font_size));	
	    tfNameMsg[i].setFont(new Font("verdana", Font.PLAIN, font_size));	
	    plNameMsg[i].add(lbNameMsg[i]);
	    plNameMsg[i].add(tfNameMsg[i]);
	    tfNameMsg[i].setEnabled( false );
	}
	tfNameMsg[0].setColumns(8); tfNameMsg[0].setForeground(Color.blue);
        tfNameMsg[0].setEnabled( true );
	tfNameMsg[1].setColumns(20);
	tfNameMsg[1].setToolTipText("Enter message to send and press ENTER");
	plSouth.add(plNameMsg[0], BorderLayout.WEST) ;
	plSouth.add(plNameMsg[1], BorderLayout.CENTER);

	msgBoard.setFont(new Font("verdana", Font.PLAIN, font_size + 2) );
	c.add(new JScrollPane( msgBoard ), BorderLayout.CENTER);
	c.add(plSouth, BorderLayout.SOUTH);

	addListeners();

	setSize( small_width, frame_height);
	setTitle( titleStr );
	makeConnection();
	tfNameMsg[0].setText( Names.group[rnd.nextInt(Names.group.length)]);
    }

    //function to control how program behaves when window is closed rather than terminating program immediately
    public void stop() {
	try {
	    // Make a LOGOUT message, and send out.
	    message.set(Message.LOGOUT, null, null); 
	    Thread thr = new ClientSender( out, new Message(message));
	    thr.start() ;
	    try { thr.join(); } catch ( InterruptedException e ) { e.printStackTrace(); }
	    if ( in != null ) in.close(); 
	    if ( out != null ) out.close();
	    if ( chatSocket != null ) chatSocket.close();
	    out = null; in = null; message = null;
	} catch (IOException e ) {
	    e.printStackTrace();
	}
    }

    //function used to determine whether an input string contains numbers
    boolean isInt( String numStr ) {
	if ( numStr == null || numStr.trim().length() < 1 ) return false;
	for ( int i = 0; i < numStr.length(); i++ )
	    if ( numStr.charAt(i) < '0' || numStr.charAt(i) > '9' ) return false;
	return true;
    }

    //function which keeps track of all actions performed on the program and controls the response
    void addListeners() {
	btnTransferTo.addActionListener( new ActionListener() {
		public void actionPerformed ( ActionEvent e ) {
		String intStr = JOptionPane.showInputDialog(null, "Enter agent id int or cancel");
                if ( intStr == null  )  return;
                String vInt = JOptionPane.showInputDialog(null, "Enter client id to transfer or cancel");
                if ( vInt == null  )  return;
                int toVID = Integer.parseInt( vInt );
		int toGroupID = Integer.parseInt( intStr );
		Group grp = vgroup.find( toGroupID );
		if ( grp == null ) { 
			JOptionPane.showMessageDialog( null, "The group doesn't exist.");
			return;
		}
                Visitor vistr = group.find( toVID );
		if ( vistr == null ) { 
			JOptionPane.showMessageDialog( null, "The client doesn't exist.");
			return;
		}
		sendMessage ( new Message ( Message.CHANGEGROUP, toGroupID + "", toVID + "" ) );
		}});

        //Listener for user to initially enter name
	tfNameMsg[0].addActionListener(new ActionListener() {
                @Override
		public void actionPerformed(ActionEvent e ) {
		visitorName = new String(tfNameMsg[0].getText()).trim() ;
		if ( visitorName.equals("") ) {
		JOptionPane.showMessageDialog( null, "Enter your name and press ENTER!");
		return;
		}
		tfNameMsg[0].setEnabled(false); tfNameMsg[1].setEnabled(true);
		agentWindow.setTitle(titleStr);
		agentWindow.setSize( frame_width, frame_height);
                String gName = visitorName;
		gName = gName.replaceAll( ";", "").replaceAll("_", "").replaceAll(" ", "");
                int temp = vgroup.size();
		sendMessage( new Message( Message.ADDGROUP, gName, null) );
                while(vgroup.size()==temp){};//ensures groups have been updated
                group = vgroup.get(vgroup.size()-1);
		groupID = group.ID;
		groupName = group.name;                
		sendMessage( new Message( Message.LOGIN, groupID+"", visitorName ));
		return; 
		}});

        //listener for sending messages
	tfNameMsg[1].addActionListener( new ActionListener () {
                @Override
		public void actionPerformed(ActionEvent e ) {
		String msg = tfNameMsg[1].getText().trim();
		if ( msg.length() < 1 ) return;
		msg = visitorName + ": " + msg; 
		if ( privateMessage ) 
                    sendMessage ( new Message( Message.PRIVATE, msg,privateReceiverIDs));
		else   sendMessage ( new Message( Message.PUBLIC, msg, null));

		tfNameMsg[1].setText("");
		}}); // end of actionPerformed(), anonymos inner class and addListener().

        //listener to check when window is closing
	this.addWindowListener( new WindowAdapter ( ) {
                @Override
		public void 	windowClosed(WindowEvent e) {
                    if(group.size()>1){
                        JOptionPane.showMessageDialog(agentWindow, "ERROR: Cannot exit while clients still connected");
                        return;
                    }  
                    else
                        stop(); System.exit(0); 
                }
                @Override
		public void 	windowClosing(WindowEvent e) { 
                    if(group.size()>1){
                        JOptionPane.showMessageDialog(agentWindow, "ERROR: Cannot exit while clients still connected");
                        return;
                    }
                    else
                        stop(); System.exit(0); 
                }
        } );
    }
    
    //initiallize the connecteion to the server
    void makeConnection() {

	try {
	    chatSocket = new Socket(hostAddress, port); 
	    out = new ObjectOutputStream ( chatSocket.getOutputStream());
	    in  = new ObjectInputStream( chatSocket.getInputStream());
	    (aAgent = new AAgent()).start();

	    // get existing groups from server.
	    message.set( Message.GETGROUPS, null, null);
	    sendMessage( message );
            while(vgroup==null){};
            for (Component c: plGroups.getComponents() ) c.setEnabled(false);
	} catch(IOException er) {
	    System.out.printf("Error in connection to server!\n");
	    er.printStackTrace(); System.exit(-1);
	}
    }

    //function to control the sending of messages 
    void sendMessage( Message message ) {
        try {
            out.writeObject(message) ;
        } catch (IOException ex) {
            Logger.getLogger(Agent.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.printf("%s\n",message);
    }

    // Implementation of Action Listener.
    static int k = 1;
    static String str = null;


    //override function for painting the screen with GUI 
    @Override
    public void paint (Graphics g) {
	super.paint(g);
    }

    //main funtion for Client Class
    public static void main( String arg[] ) {
	agentWindow  =  new Agent ( );
	agentWindow.setTitle("Enter your name");
	agentWindow.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	EventQueue.invokeLater (new Runnable () {
            @Override
	    public void run() {
		agentWindow.setVisible(true);
	    }
	} );
    }


    //class for controlling the message writing from the Client
    class ClientSender extends Thread {

	ObjectOutputStream	out;  // OutputStreamWrite derived from Socket.
	Message	message;  // Message from a chat room client to other clients

	public ClientSender ( ObjectOutputStream w, Message s)
	{ 
	    out = w; message = s ; 
	} 

	public void run() {
            try {
                out.writeObject( message ) ;
            } catch (IOException ex) {
                Logger.getLogger(Agent.class.getName()).log(Level.SEVERE, null, ex);
            }
	}
    }


    //variables for AAgent class
    GroupButtonMap		groupMap = new GroupButtonMap ();
    VisitorButtonMap		visitorMap = new VisitorButtonMap ();
    boolean			loggedIn = false;

    //Class AAgent for controlling setup and GUI of Member selection for private chats
    class AAgent extends Thread {

	public AAgent ( ) { }

        //listener for check box selection of members for private chats or selection of groups
	ActionListener listener = new ActionListener() {
            @Override
	    public void actionPerformed(ActionEvent actionEvent) {
		AbstractButton aButton = (AbstractButton) actionEvent.getSource();
		switch(aButton.getClass().getName()) {
		    case "javax.swing.JRadioButton" :
			group = groupMap.get( (JRadioButton) aButton);
			groupID = group.ID;
			tfNameMsg[0].setEnabled( true); 
			agentWindow.setTitle("Enter your Name"); 
			groupName = aButton.getText();
			break;
		    case "javax.swing.JCheckBox" :
			visitorMap.setStatus( (JCheckBox) aButton );
			plVisitorsTitledBorder.setTitle( String.format("Clients ( %d )", visitorMap.selected));
			privateMessage = (visitorMap.selected > 0);
			plVisitors.revalidate(); plVisitors.repaint();
			if ( privateMessage ) {
			    privateReceiverIDs = group.visitorIDList( true ); 
			    privateReceiverNames = group.visitorList( true ); 
			}
			break;
		    default : break;
		}

	    }
	};

        //function to add a new group to the group list
	void addOneGroup( String newGroup_info ) { 
	    Group grp = Group.toGroup(newGroup_info) ;
	    vgroup.add( grp );  // add to group vecor.
	    JRadioButton button = new JRadioButton( newGroup_info, false ); // read a radio button for the group
	    button.setEnabled( false );
	    button.addActionListener( listener ) ;  // ad listener for the button.
	    groupMap.add( button, grp );	// add button-group pair to map. 
	    plGroups.add( button );		// add button a button panel.
	    plGroups.revalidate(); plGroups.repaint();   // repaint button panel.
	}
	
        //function to remove a group from the group list
	void removeOneGroup( String gID ) { 
	    Group grp = vgroup.find( Integer.parseInt( gID )) ;
	    JRadioButton button = groupMap.get( grp );
	    vgroup.remove( grp );  // add to group vecor.
	    groupMap.remove( grp );
	    plGroups.remove( button );		// add button a button panel.
	    plGroups.revalidate(); plGroups.repaint();   // repaint button panel.
	}
	
        //function to refresh list of available groups
	void synchronizeGroups ( String group_list ) { // update groups, sizes with new counts.
	
	    VGroup vgrp = VGroup.toVGroup( group_list );
	    Set<Group> set = groupMap.groupMap.keySet();
	    Group  grpMap[]    = set.toArray(new Group[0]); // .getGroupArray();
	    Group  grpSvr[]    = vgrp.vgroup.toArray( new Group[0] );
	    Arrays.sort( grpMap); Arrays.sort( grpSvr );
	    int i = 0, j = 0;
	    while ( i < grpSvr.length && j < grpMap.length )  {
	       
	       if ( grpSvr[i].ID == grpMap[j].ID ) {
		   groupMap.get( grpMap[j] ).setText( grpSvr[i].toString() );
		   i++; j++; 
		} else if ( grpSvr[i].ID > grpMap[j].ID ) {
		   		removeOneGroup ( grpMap[j].ID + "" );   j++;
		} else { addOneGroup( grpSvr[i].toString() ); i++; }
	    }
	    
	    while ( i < grpSvr.length ) {
	       addOneGroup ( grpSvr[i].toString() ); i ++;
	    }
	    
	    while ( j < grpMap.length ) {
		   removeOneGroup ( grpMap[j].ID + "" );   j++;
	    }
	    repaintGroupPanel();
	}


        //function to add all groups at once
	void addAllGroups( String groupList ) {
	    vgroup.add( groupList );
	    JRadioButton button; Group group;
	    for ( int i = 0; i < vgroup.size(); i ++ ) {
		group = vgroup.get(i);
		button = new JRadioButton( group.toString(), false  );
                button.setEnabled(false);
		button.addActionListener( listener ) ;
		groupMap.add( button, group );
		plGroups.add( button );
	    }
	    plGroups.revalidate(); plGroups.repaint();
	}

        //function performs initial setup of visitor on login
	void loginSetup( Visitor v ) { // setup visitor name, group variables and window title.
	    visitorName = v.toString() ;
	    tfNameMsg[0].setText( visitorName );
	    visitor = v;
	    agentWindow.setTitle( String.format("%s - Group [%s_%d] Agent [%s]", titleStr, group.name, group.ID, v ) ); 
	    //for (Component c: plGroups.getComponents() ) c.setEnabled(false);
            btnTransferTo.setEnabled(true);
	    loggedIn = true;
	}

        //function refreshes list of visitors
	void addAllVisitors ( String allVisitors ) {
	    Group grp = new Group();
	    grp.add( allVisitors );
	    for(int i = 0; i <  grp.size(); i++) {
                if(i==0){
                    addHost(grp.get(i));
                }
                else
                    addOneVisitor( grp.get(i) ) ;
            }
	}
        
        void addHost( Visitor v ) {
	    group.add( v );
	    JCheckBox box = new JCheckBox(v.toString());
	    visitorMap.add(box, v);
	    box.addActionListener(listener);
	    plVisitors.add(box);
            box.setVisible(false);
            box.setSelected(true);
            box.setEnabled(false);
            v.checked = true;
	}

        //function adds a new visitor to visitor list using the Visitor Object
	void addOneVisitor( Visitor v ) {
	    group.add( v );
	    JCheckBox box = new JCheckBox(v.toString());
	    visitorMap.add(box, v);
	    box.addActionListener(listener);
	    plVisitors.add(box);
	}

        //function adds a single visitor to visitor list using only the name of the visitor
	void addOneVisitor( String vName_vID ) {
	    Visitor v = Visitor.toVisitor( vName_vID );
	    addOneVisitor ( v );
	}

        //function removes all visitors from list
	void removeAllVisitors ( ) {
	   group.clear();
	   visitorMap.clear();
	   plVisitors.removeAll();
	   repaintVisitorPanel();
	}
        
	// Remove the visitor from group, visitor-buttom mal, and
	// remove the button from button map and panel.
	void removeOneVisitor ( String vId_vName ) {
	
	    Visitor v = Visitor.toVisitor( vId_vName );
	    if ( v == null ) return;
	    if ( group == null ) return ;
	    v = group.find(v.ID);
	    plVisitors.remove ( visitorMap.get( v ) );
	    group.remove( v );
	    visitorMap.remove( v );
	    plVisitorsTitledBorder.setTitle( String.format("Members ( %d )", visitorMap.selected));
	}
        
        void changeGroup(Message cGroupMsg){
            int vID = Integer.parseInt( cGroupMsg.others);
            if(visitor.ID==vID){
                sendMessage ( new Message ( Message.TRANSFERTO, cGroupMsg.body, visitor.ID + "" ) );
            }
            else
                return;
        }

        //function called when a visitor changes to a new group
        // DT - Added a message to display whenever user leaves or enters a group.
	void processGroupChanged( Message changeGroupMsg ) {  // group list is rececived.
	    Visitor v = Visitor.toVisitor( changeGroupMsg.body);
	    if ( v.ID == visitor.ID ) {
                System.out.printf("error\n");//this should not happen since agents cannot change groups
	    } else if ( changeGroupMsg.others == null ) { // This client is in the visitor of the original group..
		removeOneVisitor( changeGroupMsg.body);
		repaintVisitorPanel();
                msgBoard.append(v + " HAS LEFT GROUP.\n" );
	    } else {  // For the visitors in the new group of the visitor of changing group.
		addOneVisitor( v );
                msgBoard.append(v + " HAS JOINED GROUP.\n" );
	    }
	    repaintVisitorPanel();
	}

        //functions to call when redrawing visitor or Group sections
	void repaintVisitorPanel() { plVisitors.revalidate(); plVisitors.repaint(); }
	void repaintGroupPanel() { plGroups.revalidate(); plGroups.repaint(); }

        //function to run CAgent
	public void run() {
	    if ( in == null || msgBoard == null ) return;
	    try {
		while ( true ) {

		    // Read message
		    try {
			message = (Message) in.readObject() ;
		    } catch (ClassNotFoundException nfdEx) {
			msgBoard.append("Error in readObject() from socket client agent.\n"
			    + nfdEx); 
			return ;
			}

                    //switch statement to interpret Message classifications
		    switch( message.type ) {

			case Message.GETGROUPS: // message: ( GETGROUP, null, group_list) 
			    addAllGroups( message.others );  // group list is rececived.
			    break;

			case Message.ADDGROUP: // message: (ADDGROUP, new_group_info, group_list )
			    addOneGroup( message.body ); // add the new group.
			    synchronizeGroups ( message.others); // update groups, sizes with new counts.
			    break;

			case Message.REMOVEGROUP: // message: (REMOVEGROUP, removed_gID,, group_list).
			    removeOneGroup( message.body ); // removethe new group.
			    synchronizeGroups ( message.others); // update groups, sizes with new counts.
			    break;
			case Message.SYNCHRONIZE: // message: (SYNCHRONIZE, null,, group_list).
			    synchronizeGroups ( message.others); // update groups, sizes with new counts.
			    break;

			case Message.TRANSFERTO: // message received: (CHANGEGROUP, v_info, list_v_info_of_toGroup))
			    processGroupChanged( message );  // group list is rececived.
			    repaintVisitorPanel();
			    break;
                            
                        case Message.CHANGEGROUP://message received (CHANGEGROUP, gID, vID)
                            changeGroup(message);
                            break;

			case Message.LOGIN: // message: (LOGIN, login_visitor, group_member_list)
			    group = vgroup.find(groupID );
			    Visitor v = Visitor.toVisitor( message.body);
			    if ( (v.name.compareTo( tfNameMsg[0].getText().trim()) == 0) && ! loggedIn ) { 
                                loginSetup( v );
				addAllVisitors( message.others);
			    } else { 
				addOneVisitor( v );
			    }
			    repaintVisitorPanel();
			    msgBoard.append(message.body+ ": logged in.\n" );
			    break;

			case Message.PUBLIC:
			    msgBoard.append(message.body + "\t\t<PUBLIC>" + '\n' );
			    break;

			case Message.PRIVATE:
                            if(message.body.contains(visitor.toString())){
                                msgBoard.append(message.body + String.format("\t\t<PRIVATE to %s>\n", privateReceiverNames) );                                
                            }
                            else
                                msgBoard.append(message.body + '\n' );
			    break;

			case Message.LOGOUT: // messge Received: LOGOUT, out_visitor, remaing_visitors ). 
			    removeOneVisitor( message.body );
			    repaintVisitorPanel();
			    msgBoard.append(message.body + ": logged out.\n" );
			    break;
		    }
		    if ( msgBoard.getText().length() > 0 )
			msgBoard.setCaretPosition(msgBoard.getText().length()  - 1) ;
		} // end of 
	    } catch( IOException e ) { msgBoard.append("Chatroom server is down.\n"); return; }
	} // end of run()
    }  // end of class AAgent, the agent's agent or receiver.

} // end of class Agent
