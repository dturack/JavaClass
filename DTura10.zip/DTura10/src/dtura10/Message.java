package dtura10;

/* Message class defines a set of messages sent between the chatroom server
 *      and  chatroom visitors.
 *  Data members:
 *  	. type    : an integer to indicate kind of message
 *  	. body    : mainly contains the  message sent out to some or all visitors.
 * 	. others  : a string contains other information that is not in message body.
*/

import java.io.*;
import java.util.*;

/* This class assigns static int values to each message classification in order to better interpret
 * The Comments next to each declaration give the standard formatting for each message.
*/
public class Message implements Serializable {

    public static final int
	ADDGROUP = 10,      // Message: server received : (ADDGROUP, new_group_name, null).
			    //          visitor receied : (ADDGROUP, new_group_info, group_list) 

	REMOVEGROUP = 11,   // Message: server received : (REMOVEGROUP, to_remove_group_ID, null).
			    //          visitor receied : (REMOVEGROUP, removed_group_ID, remaininggroup_list) 

	GETGROUPS = 12,     // Message: server received : (GETGROUPS, null, null) 
			    //	        visitor received: (GETGROUPS, null, group_listl )
			    //	The visitor's interface sends this message to server as the first message. 
			    //  Then the client software will converts the group_list into VGroup objec which is
			    //	a vector of groups with related functions.,
			    //  and uses the VGroup object to display the list of groups

	SYNCHRONIZE = 13,   // Message: server received : (SYNCHRONIZED, null, null).
			    //          visitor receied : (SYNCHRONIZED, null, group_list) 
			   
	TRANSFERTO = 14,   // Message: server received : ( TRANSFERTO, to_gId, null)
			    //	        visitor received: ( TRANSFERTO, visitor_info, to_group_visitors)
			    //    The server received the message from a visitor for changing group. The
			    //	  server change the group. The list of visitor (vId_v_name) are sent back
			    //	  to client. The visitor requested the change will renew the list of visitors
			    //    and the other vistors will either delete or add the requester to or from
			    //	  their visitor list.
	PUBLIC = 0,	    // Message: server received : (PUBLIC, body, null).
			    //		visitor received: (PUBLIC, body, sender_info);  
	PRIVATE = 1,	    // Message: server received : (PRIVATE, body, vID_list) 
			    //		visitor received: (PRIVATE, body, vID_list ); 
	LOGIN   = 2,	    // Message: Server received : (LOGIN, group_id, login_visitor_name)
			    //          visitor received: (LOGIN, loginz_visitorinfo, group_visitor_list ).
			    //   When client software receiced login body, it uses group_visitor_list
			    //   to create a vector of visitors, and display the list of vectors.
	LOGOUT  = 3;	    // Message: server received : (LOGOUT, null, null))
			    //          visitor received: (LOGOUT, logout_visitor, visitor_list)
			    //  The client uses the visitor_list to update its visitor list.
		
    public static final String
	NAME_SEPARATOR = ";"; // string used to separate visitor names. 
    public int 		type 	    = PUBLIC;	// type of message defined above

    // body contains message to receivers, or name if message type is
    // either LOGIN or LOGOUT type.
    public String	body = ""; 


    // hold list of receiver names. If it is null or empty, all visitors
    // are receivers.
    public String       others = "";   // null, one or more visitor names.

    //default compilers for various message types
    public  Message( ) { set ( PUBLIC, "invalid", null ); }
    public  Message( Message m ) { set( m.type, m.body, m.others ); }
    public  Message(int type, String body, String others) { set( type, body , others ); }

    //sets the Message data members to the incoming information
    public  void set(int type, String body, String others ) {
	this.type = type ;  this.body = body == null? null : new String ( body ); 
	                this.others = (others == null) ? null : new String( others );

    }

    //Override of toString() function used for formatting the output
    @Override
    public  String toString() {
	return String.format("%3d %s %s", type, body, others);
    }

    //function to get names of users which will receive sent message
    public  Vector<String> getReceiverNames() { 
	if ( others == null ) return null;
	Vector<String> v = new Vector<String>( 10 );
	if ( others.trim().equals("") ) return v;
	else {
	    StringTokenizer token = new StringTokenizer( others, NAME_SEPARATOR);
	    while ( token.hasMoreTokens() ) v.add( token.nextToken() );
	}
	Collections.sort(v);
	return v;
    }
}
