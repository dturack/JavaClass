/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura08cc;

import java.io.ObjectInputStream;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;

/**
 *
 * @author student
 */

class CAgent implements Runnable {

    ObjectInputStream in = null;
    JTextArea	      msg = null;

    public CAgent ( ObjectInputStream in, JTextArea msg ) {
	this.in = in; this.msg = msg;
    }

    public void run( ) {
	Object obj ;
        String mssg ;
	while ( true ) {
	    try {
		// obj = (Object) in.readUTF();
		mssg = (String) in.readObject();
                boolean test = checkWelcome(mssg);
                if(test)
                    msg.append( "\n" );
                else
                    msg.append( mssg + '\n');
	    } catch ( Exception e ) { e.printStackTrace(); } 
	}
    }
    
    public boolean checkWelcome(String mssg){
        if(mssg.contains("////")){
            String name = "";
            String message = mssg.substring(4);
            for(int i=1; i<10; i++ ){
                if(!message.contains("//"))
                    break;
                int idx = message.indexOf("//");
                name = message.substring(0,idx);
                message = message.substring(idx+2);
                DTura08CC.jCheckBox[i].setText(name);
                DTura08CC.jCheckBox[i].setVisible(true);
                DTura08CC.jpRight.add(DTura08CC.jCheckBox[i]);
                if(DTura08CC.jCheckBox[0].isSelected()){
                    DTura08CC.jCheckBox[i].setSelected(true);
                }
            }
            return true;
        }
        return false;
    }
}
