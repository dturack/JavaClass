/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura08cc;

import java.io.ObjectInputStream;
import javax.swing.JTextArea;

/**
 *
 * @author student
 */

class CAgent implements Runnable {

    ObjectInputStream in = null;
    JTextArea	      msg = null;

    public CAgent ( ObjectInputStream in, JTextArea msg ) {
	this.in = in; this.msg = msg;
    }

    public void run( ) {
	Object obj ;
	while ( true ) {
	    try {
		// obj = (Object) in.readUTF();
		obj = (Object) in.readObject();
		msg.append( obj.toString() + '\n');
	    } catch ( Exception e ) { e.printStackTrace(); } 
	}
    }
}
