package dtura08cc;

/**
 *
 * @author dturack
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class DTura08CC extends JFrame {

    public static Container   c	= null ;
    JPanel		jpSouth = new JPanel();
    public static JPanel jpRight = new JPanel();
    JTextArea		taMsg	= new JTextArea(20,40);
    JLabel              tfNLb   = new JLabel("Name:");
    JLabel              tfMLb   = new JLabel("Message:");
    JLabel              jpRLb   = new JLabel("Select Users to Send:  ");
    JTextField		tfName	= new JTextField ( 6 );
    JTextField		tfMsg 	= new JTextField ( 20 );
    JScrollPane scroll;
    public static JScrollBar vertical;
    public static JCheckBox [] jCheckBox = new JCheckBox[25];
    Socket		sk    	= null;
    ObjectInputStream in	= null;
    ObjectOutputStream out	= null;
    // String		host	= "delphi.cs.csub.edu";
    //String            host    = "sleipnir.cs.csub.edu";
    String		host	= "localhost";
    public static String  username = "";
    String              welcome = "Welcome to the Chatroom ";
    int			port	= 1992;
    int                 clients = 2;

    public DTura08CC () {
        for(int i=0; i<25; i++){
            jCheckBox[i] = new JCheckBox();
            jCheckBox[i].setVisible(false);
        }
	c = getContentPane() ;
	c.setLayout ( new BorderLayout() );
        taMsg.setBackground(Color.gray);
        taMsg.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
        scroll = new JScrollPane(taMsg);
        vertical = scroll.getVerticalScrollBar();
	c.add( scroll, BorderLayout.CENTER );
        //c.add(taMsg, BorderLayout.CENTER);
        jpSouth.add(tfNLb);
	jpSouth.add( tfName );
        jpSouth.add(tfMLb);
	jpSouth.add( tfMsg );
        jpSouth.setBackground(Color.white);
        c.add( jpSouth, BorderLayout.SOUTH);
        jCheckBox[0].setText("All Users");
        jCheckBox[0].setVisible(true);
        jpRight.setLayout(new BoxLayout(jpRight, BoxLayout.Y_AXIS));
        jpRight.add(jpRLb);
        jpRight.add(jCheckBox[0]);
        jCheckBox[0].setSelected(true);
        c.add(jpRight, BorderLayout.EAST);
        tfMsg.setEnabled(false);
	tfName.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() == tfName) {
                    tfMsg.setEnabled(true);
                    username = tfName.getText();
                    startConnection();
                    try { out.writeObject( "///"+username ); out.flush(); }
                    catch (IOException er) { er.printStackTrace(); }
                    setTitle( username+" is now in the Chatroom");
                    tfName.setEnabled(false);
                }
            }
        });
        tfMsg.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( e.getSource() == tfMsg ) {
                    String str = tfMsg.getText();
                    String header = "/:/";
                    if(jCheckBox[0].isSelected())
                        header = header+"all";
                    else{
                        for(int i=1; i<25; i++){
                            if(jCheckBox[i].isSelected())
                                header = header+i+",";
                        }
                    }
                    header = header+"/:/";
                    try { out.writeObject( header+str ); out.flush(); }
                    catch (IOException er) { er.printStackTrace(); }
                    tfMsg.setText("");
                }
            }
        });
        taMsg.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                vertical.setValue(vertical.getMaximum());
                setVisible(true);
            }
            @Override
            public void removeUpdate(DocumentEvent e) {setVisible(true);}
            @Override
            public void changedUpdate(DocumentEvent e) {setVisible(true);}
        });
        jCheckBox[0].addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                {
                    for(int i=1; i<25; i++){
                        if(jCheckBox[0].isSelected()){
                            jCheckBox[i].setSelected(true);
                            jCheckBox[i].setEnabled(false);
                        }
                        else{
                            jCheckBox[i].setSelected(false);
                            jCheckBox[i].setEnabled(true);
                        }
                    }
                }
            }
        });
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        WindowListener exitListener = new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if(out!=null){
                    try { out.writeObject( "/;/" ); out.flush(); }
                    catch (IOException er) { er.printStackTrace(); }
                }
                System.exit(0);
            }
        };
        addWindowListener(exitListener);
	setTitle( "Client Chatroom GUI");
        pack();
 	setVisible( true );

    
	
    }
    
    public void startConnection(){
        try { 
    	   sk = new Socket( host, port);
	   out = new ObjectOutputStream( sk.getOutputStream() );
	   in  = new ObjectInputStream( sk.getInputStream() );
	} catch ( IOException e) { e.printStackTrace(); return; }	   

	 try { Thread.sleep(1000); } catch( Exception e) {  }
	( new Thread ( new CAgent ( in, taMsg ) )).start();
    }

    public static void main( String arg[]  ) {
	JFrame app = new DTura08CC();
    }

}


