/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura08cc;

/**
 *
 * @author student
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class DTura08CC extends JFrame {

    Container		    c	= null ;
    JPanel		jpSouth = new JPanel();
    public static JPanel jpRight = new JPanel();
    JTextArea		taMsg	= new JTextArea(20,40);
    JLabel              tfNLb   = new JLabel("Name:");
    JLabel              tfMLb   = new JLabel("Message:");
    JLabel              jpRLb   = new JLabel("Select Users to Send:  ");
    JTextField		tfName	= new JTextField ( 6 );
    JTextField		tfMsg 	= new JTextField ( 20 );
    //JPanel              jPanel1 = new JPanel();
    //JCheckBox        jCheckBox1 = new JCheckBox();
    //JCheckBox        jCheckBox2 = new JCheckBox();
    //JCheckBox        jCheckBox3 = new JCheckBox();
    //JCheckBox        jCheckBox4 = new JCheckBox();
    //JCheckBox        jCheckBox5 = new JCheckBox();
    //JList            list       = new JList
    public static JCheckBox [] jCheckBox = new JCheckBox[10];
    Socket		sk    	= null;
    ObjectInputStream in	= null;
    ObjectOutputStream out	= null;
    // String		host	= "delphi.cs.csub.edu";
    //String            host    = "sleipnir.cs.csub.edu";
    String		host	= "localhost";
    String              username = "";
    String              welcome = "Welcome to the Chatroom ";
    int			port	= 9901;
    int                 clients = 2;

    public DTura08CC () {
        for(int i=0; i<10; i++){
            jCheckBox[i] = new JCheckBox();
            jCheckBox[i].setVisible(false);
        }
	c = getContentPane() ;
	c.setLayout ( new BorderLayout() );
	c.add( taMsg, BorderLayout.CENTER );
        jpSouth.add(tfNLb);
	jpSouth.add( tfName );
        jpSouth.add(tfMLb);
	jpSouth.add( tfMsg );
        c.add( jpSouth, BorderLayout.SOUTH);
        //jCheckBox[0] = new JCheckBox();
        jCheckBox[0].setText("All Users");
        jCheckBox[0].setVisible(true);
        jpRight.setLayout(new BoxLayout(jpRight, BoxLayout.Y_AXIS));
        jpRight.add(jpRLb);
        jpRight.add(jCheckBox[0]);
        jCheckBox[0].setSelected(true);
        c.add(jpRight, BorderLayout.EAST);
        //tfName.addActionListener(this);
        tfMsg.setEnabled(false);
	tfName.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource() == tfName) {
                    tfMsg.setEnabled(true);
                    username = tfName.getText();
                    startConnection();
                    try { out.writeObject( "///"+username ); out.flush(); }
                    catch (IOException er) { er.printStackTrace(); }
                    setTitle( username+" is now in the Chatroom");
                    tfName.setEnabled(false);
                }
            }
        });
        tfMsg.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( e.getSource() == tfMsg ) {
                    try { out.writeObject( tfMsg.getText() ); out.flush(); }
                    catch (IOException er) { er.printStackTrace(); }
                    tfMsg.setText("");
                }
            }
        });
        jCheckBox[0].addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                {
                    for(int i=1; i<20; i++){
                        if(jCheckBox[0].isSelected())
                            jCheckBox[i].setSelected(true);
                        else
                            jCheckBox[i].setSelected(false);
                    }
                }
            }
        });
	setSize(600, 600);
	setTitle( "Client Chatroom GUI");
 	setVisible( true );
    
	
    }
    
    public void startConnection(){
        try { 
    	   sk = new Socket( host, port);
	   out = new ObjectOutputStream( sk.getOutputStream() );
	   in  = new ObjectInputStream( sk.getInputStream() );
	} catch ( IOException e) { e.printStackTrace(); return; }	   

	 try { Thread.sleep(1000); } catch( Exception e) {  }
	( new Thread ( new CAgent ( in, taMsg ) )).start();
    }

    /*@Override
    public void actionPerformed ( ActionEvent e ) {
	if ( e.getSource() == tfMsg ) {
	    // taMsg.append( tfMsg.getText() + '\n' );
	    // try { out.writeUTF( tfMsg.getText() ); out.flush(); }
	    try { out.writeObject( tfMsg.getText() ); out.flush(); }
	    catch (IOException er) { er.printStackTrace(); }
	    tfMsg.setText("");
	}
        else if(e.getSource() == tfName) {
            tfMsg.setEnabled(true);
            username = tfName.getText();
            startConnection();
            try { out.writeObject( "///"+username ); out.flush(); }
	    catch (IOException er) { er.printStackTrace(); }
            setTitle( username+" is now in the Chatroom");
            tfName.setEnabled(false);
        }
    }*/
    public static void main( String arg[]  ) {
	JFrame app = new DTura08CC();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}


