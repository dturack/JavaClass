/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura08cc;

/**
 *
 * @author student
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class DTura08CC extends JFrame implements ActionListener {

    Container		    c	= null ;
    JPanel		jpSouth = new JPanel();
    JTextArea		taMsg	=  new JTextArea(20,40);
    JTextField		tfName	= new JTextField ( 5 );
    JTextField		tfMsg 	= new JTextField ( 30 );
    JPanel              jPanel1 = new JPanel();
    JCheckBox        jCheckBox1 = new javax.swing.JCheckBox();
    JCheckBox        jCheckBox2 = new javax.swing.JCheckBox();
    JCheckBox        jCheckBox3 = new javax.swing.JCheckBox();
    JCheckBox        jCheckBox4 = new javax.swing.JCheckBox();
    JCheckBox        jCheckBox5 = new javax.swing.JCheckBox();
    //JCheckBox [] jCheckBox = null;
    Socket		sk    	= null;
    ObjectInputStream in	= null;
    ObjectOutputStream out	= null;
    // String		host	= "delphi.cs.csub.edu";
    //String            host    = "sleipnir.cs.csub.edu";
    String		host	= "localhost";
    int			port	= 9901;
    int                 clients = 2;

    public DTura08CC () {
	c = getContentPane() ;
	c.setLayout ( new BorderLayout() );
	c.add( taMsg, BorderLayout.CENTER ); 
	jpSouth.add( tfName ); 
	jpSouth.add( tfMsg );
        jCheckBox1.setText("jCheckBox1");
        jCheckBox2.setText("jCheckBox2");
        jCheckBox3.setText("jCheckBox3");
        jCheckBox4.setText("jCheckBox4");
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jCheckBox3)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBox1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jCheckBox2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jCheckBox4, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jCheckBox1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox4)
                .addGap(0, 200, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addContainerGap(188, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
	c.add( jpSouth, BorderLayout.SOUTH);
	tfMsg.addActionListener( this );
	setSize(500, 500);
	setTitle( "Simple GUI Client");
 	setVisible( true );
    
	
	try { 
    	   sk = new Socket( host, port);
	   out = new ObjectOutputStream( sk.getOutputStream() );
	   in  = new ObjectInputStream( sk.getInputStream() );
	} catch ( IOException e) { e.printStackTrace(); return; }	   

	 try { Thread.sleep(1000); } catch( Exception e) {  }
	( new Thread ( new CAgent ( in, taMsg ) )).start();
    }

    public void actionPerformed ( ActionEvent e ) {
	if ( e.getSource() == tfMsg ) {
	    // taMsg.append( tfMsg.getText() + '\n' );
	    // try { out.writeUTF( tfMsg.getText() ); out.flush(); }
	    try { out.writeObject( tfMsg.getText() ); out.flush(); }
	    catch (IOException er) { er.printStackTrace(); }
	    tfMsg.setText("");
	}
    }
    public static void main( String arg[]  ) {
	JFrame app = new DTura08CC();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}


