package list;

/**
 *
 * @author dturack
 * @param <T>
 */
public class Queue<T> extends List<T> {
   
    public Queue(){super();}
    
    public Queue<T> enque( T v ){
        addToRear(v);
        return this;
    }
    public T deque(){
        if (empty() ) return null;
        T v = front.data;
        removeFront();
        return v;
    }
}
