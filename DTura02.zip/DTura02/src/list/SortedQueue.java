
package list;

/**
 *
 * @author dturack
 * @param <T>
 */
public class SortedQueue<T> extends List<T> {
    
    public SortedQueue() {super();}
    
    /*public SortedQueue<T> insert( T v ){
        //Search for correct pos
        if(size < 1 || v.compareTo(front.data) <= 0)
            return (SortedQueue<T> ) addToFront(v);
        if(v.compareTo(rear.data) >= 0)
            return (SortedQueue<T>) addToRear(v);
        Node cur = front, nn = new Node(v);
        for (; cur.next.data.compareTo(v) < 0; ) cur = cur.next;
        add(v, cur.next.);
    }*/
    
    /*public T remove( T v ) {
        
        T v2 = search();
        return v2;
    }*/
    
}
