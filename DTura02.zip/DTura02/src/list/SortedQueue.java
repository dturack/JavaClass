
package list;
/**
 *
 * @author dturack
 * @param <T>
 */
public class SortedQueue<T> extends List<T> {
    
    public SortedQueue() {super();}
    
    public void insert( T v ){
        //Search for correct pos

        if(size < 1 || retID(v).compareTo(retID(front.data)) <= 0){
            addToFront(v);
            return;
        }
        if(retID(v).compareTo(retID(rear.data)) >= 0){
            addToRear(v);
            return;
        }
        Node cur = front, nn = new Node(v);
        int k = 1;
        for (; retID(cur.next.data).compareTo(retID(v)) < 0 ; k++ ) cur = cur.next;
        add(v, k);
    }
    
    public T remove( T v ) {
        if(retID(v).compareTo(retID(front.data)) == 0){
            removeFront();
            return v;
        }
        if(retID(v).compareTo(retID(rear.data)) == 0){
            rear = rear.previous;
            remove(this.size());
            rear.next = null;
            return v;
        }
        Node cur = front, nn = new Node(v);
        int k = 2;
        for (; retID(cur.next.data).compareTo(retID(v)) != 0 ; k++ ) cur = cur.next;
        remove(k);
        return v;
    }
    
}
