/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list;

/**
 *
 * @author dturack
 */
public class SortedQueue<T> extends List<T> {
    
    public SortedQueue() {super();}
    
    public void insert( T v ){
        //Search for correct pos
        int pos = 0;
        add(v, pos);
        
    }
    
    public T remove( T v ) {
        
        T v2 = search();
        return v2;
    }
    
}
