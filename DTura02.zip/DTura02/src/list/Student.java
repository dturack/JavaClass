package list;

import java.util.Random;

/**
 *
 * @author Daniel Turack
 */
public class Student extends Member {
    public Student () {
        generate();
    }
    protected String major, sport; 
    protected float GPA;
    @Override
    void generate() {
        super.generate();
        Random rdn=new Random(); 
        memClass = "STU";
        major = Names.department[rdn.nextInt(Names.department.length)];
        sport = Names.sport[rdn.nextInt(Names.sport.length)];
        GPA = (float) ((rdn.nextInt(400)) / 100.0);
    }   
    @Override
    public String htmlColumns() {
        return String.format("%s<td></td><td></td><td></td><td>%f</td><td>%s</td><td>%s</td>", super.htmlColumns(), GPA, major, sport);
    }
    @Override
    public String toString(){
        return String.format("%15s %-15s %-15s %4f", super.toString(), major, sport, GPA);
    };
    @Override
    public String toString( boolean lab ){
        return lab ? "STU " + toString() : toString();
    };    
}