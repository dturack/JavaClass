/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list;
import java.util.Iterator;
/**
 *
 * @author student
 */
public class List<T> implements Iterable<T>{

    public Iterator<T> iterator(boolean fwd) { return new ListIterator( fwd ) ;}
    public Iterator<T> iterator() { return new ListIterator( true ) ;}

    protected class Node {
        protected Node next, previous;
        protected T data;
        public Node( T data ) {
            next = previous = null;
            this.data = data;
        }
    }
    
    protected Node front, rear ;
    protected int size =0;
    
    public List() {front = rear = null;}
    
    public int size() { return size; }
    public boolean empty() { return size < 1; }

    protected List<T> addToFront( T v ){
        Node nn = new Node( v );
        
        if ( front != null ) front.previous = nn;
        else rear = nn;
        nn.next = front;
        front = nn;
        size ++;
        return this;
    }
    
    protected List<T> addToRear( T v ){
        Node nn = new Node( v );
        
        if ( rear != null ) {
            rear.next = null;
        }
        else 
            front = nn;
        rear.next = nn;
        nn.previous = rear;
        rear = nn;
        size ++;
        return this;
    }
    
    protected List<T> add ( T v, int pos ) {
        //Adjust position if necessary
        if ( pos<=0) return addToFront( v );
        if ( pos>=size) return addToRear( v );
        
        Node cur = front;
        for (int i = 1; i< pos; i++) cur = cur.next;
        
        //New node will be append to current node.
        Node nn = new Node( v );
        nn.next = cur.next;
        nn.previous = cur;
        cur.next = nn.next.previous = nn;
        size++;
        return this;
    }
    
    class ListIterator implements Iterator<T>{
        Node cur = front;
        boolean fwd;
        //public ListIterator ( ) { init(true);}
        //public ListIterator(boolean fwd) { 
        //    init( fwd );
        //}
        protected void init( boolean fwd ){
            this.fwd = fwd;
            cur = fwd ? front : rear;
        }
        public boolean hasNext() {return cur != null; }
        public T next() {
            T v = cur.data;
            cur = fwd ? cur.next : cur.previous; 
            return v;
        }
        public void remove() {return ; }
        
        }   
}
