package list;
import java.util.*;
/**
 *
 * @author dturack
 */
public class DTura02 {

    static Random rdn = new Random();

    /**
     * @param args the command line arguments
     */
    static Stack<Member> stk = new Stack<>();
    static Queue<Member> que = new Queue<>();
    static SortedQueue<Member> sque = new SortedQueue<>();
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.printf("Enter H/h/? for help, or command : ");
        String selc = scn.next();
        
        while (!"E".equals(selc) && !"e".equals(selc)){
            switch(selc){
                case "H": case "h": case "?":
                    System.out.printf("%s\n", MemberConst.menu); break;
                case "G": case "g":
                    System.out.printf("Enter number of Members: ");
                    makeMembers(scn.nextInt()); break;
                case "S": case "s":
                    show (stk.iterator()) ; break;
                case "Q": case "q":
                    show (que.iterator()) ; break;
                case "O": case "o":
                    show (sque.iterator()) ; break;
                case "D": case "d":
                    deleteElement(); break;
                case "I": case "i":
                    makeMembers(1); break;
            }
            System.out.printf("Enter H/h/? for help, or command : ");
            selc = scn.next();
        }     
    }
    
    public static void deleteElement(){
        Member stkele, queele;
        stkele = stk.pop();
        System.out.printf("Element popped from Stack: \n %s \n", stkele);
        queele = que.deque();
        System.out.printf("Element dequed from Queue: \n %s \n", queele);
        sque.remove(stkele);
        System.out.printf("Element removed from Sorted Queue: \n %s \n", stkele);
    }
    
    static void show(Iterator<Member> itr) {
        Scanner scn = new Scanner(System.in);
        System.out.printf("Enter number of elements per page: ");
        int npp = scn.nextInt();
        String selc;
        int page = 0;
        while (itr.hasNext()){                    
            
                System.out.printf("%s \n", itr.next());
                page++;
                if (page%npp==0){
                    System.out.printf("\nEnter 'q' or 'Q' to quit, return or any other key to continue: ");
                    selc = scn.nextLine();
                    if ("Q".equals(selc) || "q".equals(selc)) break;
                }
        }
        if(itr.hasNext()){
            System.out.printf("\n%d elements printed of %d total\n", page, stk.size());
        }
        else
            System.out.printf("\n\n End of Data\n");
    }

    public static void makeMembers(int count){
        Member mem = null;
        for(int k=0; k<count; k++){
            int pick = rdn.nextInt(5)+1;
            switch(pick){
                case 1:
                    mem = new Member(); break;
                case 2:
                    mem = new Employee(); break;
                case 3:
                    mem = new Student(); break;
                case 4:
                    mem = new Faculty(); break;
                case 5:
                    mem = new Staff(); break;
            }
            stk.push(mem);
            que.enque(mem);
            sque.insert(mem);
        }
        System.out.printf("\n %d Members created \n", count);
        
        if(count==1){
            System.out.printf("Member data: \n %s \n\n", mem);
        }
    }    
}
