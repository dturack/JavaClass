package list;
import java.util.*;
import java.io.*;
import java.awt.Desktop;
/**
 *
 * @author dturack
 */
public class DTura02 {

    static Random rdn = new Random();

    /**
     * @param args the command line arguments
     */
    static Stack<Member> stk = new Stack<Member>();
    static Queue<Member> que = new Queue<Member>();
    static SortedQueue<Member> sque = new SortedQueue<Member>();
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scn = new Scanner(System.in);
        System.out.printf("Enter H/h/? for help, or command : ");
        String selc = scn.next();
        
        while (!"E".equals(selc) && !"e".equals(selc)){
            switch(selc){
                case "H": case "h": case "?":
                    System.out.printf("%s\n", MemberConst.menu); break;
                case "G": case "g":
                    System.out.printf("Enter number of Members: ");
                    makeMembers(scn.nextInt()); break;
                case "S": case "s":
                    show (stk.iterator()) ; 
                    break;
                case "J": case "j":
                    show (que.iterator()) ; 
                    break;
                case "O": case "o":
                    //show (sque.iterator()) ; 
                    break;
                case "D": case "d":
                    //deleteElement(); 
                    break;
                case "I": case "i":
                    makeMembers(1); break;
            }
            System.out.printf("Enter H/h/? for help, or command : ");
            selc = scn.next();
        }     
    }
    
    static void show(Iterator<Member> itr) {
        Scanner scn = new Scanner(System.in);
        System.out.printf("Enter number of elements per page: ");
        int npp = scn.nextInt();
        String selc = scn.nextLine();
        int page = 0;
        while (itr.hasNext()){ //&& !"Q".equals(selc) && !"q".equals(selc)){                    
            
                System.out.printf("%s \n", itr.next());
                page++;
                if (page%npp==0){
                    System.out.printf("\nEnter 'q' or 'Q' to quit, return or any other key to continue: ");
                    selc = scn.nextLine();
                    if ("Q".equals(selc) || "q".equals(selc)) break;
                }
        }
        System.out.printf("\n\n End of Data, %d pages\n", page);
        //while (itr.hasNext())
        //    System.out.printf("%5d ", itr.next());
    }

    public static void makeMembers(int count){
        Member mem = null;
        for(int k=0; k<count; k++){
            int pick = rdn.nextInt(5)+1;
            switch(pick){
                case 1:
                    mem = new Member(); break;
                case 2:
                    mem = new Employee(); break;
                case 3:
                    mem = new Student(); break;
                case 4:
                    mem = new Faculty(); break;
                case 5:
                    mem = new Staff(); break;
            }
            stk.push(mem);
            que.enque(mem);
            //hsque.insert(mem);
        }
        System.out.printf("\n %d Members created \n", count);
        System.out.printf("Sizes: %5d and %5d ", stk.size(), que.size());
    }
    
}
