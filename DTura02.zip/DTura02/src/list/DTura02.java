package list;
import java.util.*;
import java.io.*;
import java.awt.Desktop;
/**
 *
 * @author student
 */
public class DTura02 {

    static Random rdn = new Random();

    /**
     * @param args the command line arguments
     */
    static Stack<Integer> stk = new Stack<Integer>();
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scn = new Scanner(System.in);
        for (int i=0; i<10; i++){
            stk.push(rdn.nextInt(10000));
        }
        show (stk.iterator()) ;
        show (stk.iterator(false)) ;
        
        int npp = 20;
        int page = 0;
        String selc = scn.next();
        for(int i=0; ){
            page ++;
            if (page%20==0){
                scn.nextChar();
                if (selc == "Q" || selc == "q") break;
            }
        }

    }
    static void show(Iterator<Integer> itr) {
        System.out.printf("\n\n Data from Iterator ===========\n");
        while (itr.hasNext())
            System.out.printf("%5d ", itr.next());
    }
    
}
