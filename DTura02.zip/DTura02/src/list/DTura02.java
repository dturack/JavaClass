package list;
import java.util.Iterator;
import java.util.Random;
/**
 *
 * @author student
 */
public class DTura02 {

    static Random rdn = new Random();

    /**
     * @param args the command line arguments
     */
    static Stack<Integer> stk = new Stack<Integer>();
    public static void main(String[] args) {
        // TODO code application logic here
        for (int i=0; i<10; i++){
            stk.push(rdn.nextInt(10000));
        }
        show (stk.iterator()) ;
        show (stk.iterator(false)) ;

    }
    static void show(Iterator<Iterator> itr) {
        System.out.printf("\n\n Data from Iterator ===========\n");
        while (itr.hasNext())
            System.out.printf("%5d ", itr.next());
    }
    
}
