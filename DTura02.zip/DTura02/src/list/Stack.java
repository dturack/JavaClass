/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list;

/**
 *
 * @author student
 */
public class Stack<T> extends List<T> {
    public Stack(){super();}
    //public Stack( Stack<T> stk) { super( stk );}
    public Stack<T> push(T v) { addToFront(v); return this; }
    public T pop() { 
        if (empty() ) return null;
        T v = front.data;
        //removeFront(); 
        return v; 
    }
    public T top() { 
        return front == null ? null : front.data; 
    }

    
}
