package list;

/**
 *
 * @author dturack
 * @param <T>
 */
public class Stack<T> extends List<T> {
    public Stack(){super();}
    public Stack<T> push(T v) { addToFront(v); return this; }
    public T pop() { 
        if (empty() ) return null;
        T v = front.data;
        removeFront(); 
        return v; 
    }
    public T top() { 
        return front == null ? null : front.data; 
    }  
}
