package com.example.dturack.dtura11;

import android.graphics.Canvas;

/**
 * Created by dturack on 5/11/17.
 */

public interface GameObject {
    public void draw(Canvas canvas);
    public void update();
}
