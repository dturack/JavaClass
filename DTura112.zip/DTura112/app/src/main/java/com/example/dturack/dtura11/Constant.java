package com.example.dturack.dtura11;

/**
 * Created by dturack on 5/11/17.
 */

public class Constant {
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;
}
