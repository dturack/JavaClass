package com.example.dturack.dtura11;

import android.graphics.Canvas;
import android.graphics.Color;

import java.util.ArrayList;

/**
 * Created by dturack on 5/11/17.
 */

public class ObstacleManager implements GameObject {
    private ArrayList<Obstacle> obstacles;
    private int playerGap;
    private int obstacleGap;
    private int obstacleHeight;
    private int color;
    private int score;

    private long startTime;
    private long initTime;

    public ObstacleManager(int playerGap, int obstacleGap, int obstacleHeight, int color) {
        this.playerGap = playerGap;
        this.obstacleGap = obstacleGap;
        this.obstacleHeight = obstacleHeight;
        this.color = color;

        startTime = initTime = System.currentTimeMillis();

        obstacles = new ArrayList<>();

        populateObstacles();
    }

    public boolean playerCollide(RectPlayer player) {
        int count = 0;
        for(Obstacle ob : obstacles) {
            if(ob.playerCollide(player)) {
                if(ob.getColor()==Color.rgb(0,200,0)){
                    obstacles.remove(count);
                    addScore(200);
                    populateObstacles();
                    return false;
                }
                else if(ob.getColor()==Color.rgb(255,255,0)){
                    obstacles.remove(count);
                    addScore(-200);
                    populateObstacles();
                    return false;
                }
                return true;
            }
            count++;
        }
        return false;
    }

    public void populateObstacles() {
        int currY = -5*Constant.SCREEN_HEIGHT/4;
        while(currY < 0) {
            int xStart = (int)(Math.random()*(Constant.SCREEN_WIDTH - 25.0));
            int rand = (int)(Math.random()*10.0);
            if(rand==3)
                obstacles.add(new Obstacle(obstacleHeight, Color.rgb(0,200,0), xStart, currY, playerGap));
            else if(rand==2)
                obstacles.add(new Obstacle(obstacleHeight, Color.rgb(255,255,0), xStart, currY, playerGap));
            else
                obstacles.add(new Obstacle(obstacleHeight, color, xStart, currY, playerGap));
            currY += obstacleHeight + obstacleGap;
        }
    }

    public void update() {
        int elapsedTime = (int) (System.currentTimeMillis() - startTime);
        startTime = System.currentTimeMillis();
        float speed = (float) (Math.sqrt(1.0 + (startTime - initTime) / 3000.0)) * Constant.SCREEN_HEIGHT / (10000.0f);
        int count = 0;
        for (Obstacle ob : obstacles) {
            ob.incrementY(speed * elapsedTime);
        }
        for (Obstacle ob : obstacles){
            if (ob.getRectangle().top >= Constant.SCREEN_HEIGHT) {
                int xStart = (int) (Math.random() * (Constant.SCREEN_WIDTH - 25.0));
                int rand = (int) (Math.random() * 5.0);
                if (rand == 3)
                    obstacles.add(0, new Obstacle(obstacleHeight, Color.rgb(0, 200, 0), xStart, 0, playerGap));
                else if (rand == 2)
                    obstacles.add(0, new Obstacle(obstacleHeight, Color.rgb(255, 255, 0), xStart, 0, playerGap));
                else
                    obstacles.add(0, new Obstacle(obstacleHeight, color, xStart, 0, playerGap));
                obstacles.remove(count+1);
                addScore(100);
                break;
            }
            count++;
        }
    }

    public void addScore(int add) {
        score += add;
    }

    public int getScore() {
        return score;
    }

    public void draw(Canvas canvas) {
        for(Obstacle ob : obstacles)
            ob.draw(canvas);
    }
}
