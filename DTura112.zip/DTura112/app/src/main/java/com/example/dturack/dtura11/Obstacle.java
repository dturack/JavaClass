package com.example.dturack.dtura11;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;

/**
 * Created by dturack on 5/11/17.
 */

public class Obstacle implements GameObject {
    private Rect rectangle;
    private int color;
    private int startX;
    private int playerGap;

    public Rect getRectangle() {
        return rectangle;
    }

    public void incrementY(float y) {
        rectangle.top += y;
        rectangle.bottom += y;
    }

    public Obstacle(int rectHeight, int color, int startX, int startY, int playerGap) {
        this.rectangle = rectangle;
        rectangle = new Rect(startX, startY, startX+30, startY+40);
        this.color = color;
        this.startX = startX;
        this.playerGap = playerGap;
    }

    public boolean playerCollide(RectPlayer player) {
        return Rect.intersects(rectangle, player.getRectangle());// || Rect.intersects(rectangle2, player.getRectangle());
    }

    public int getColor(){
        return color;
    }

    @Override
    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(color);
        canvas.drawRect(rectangle, paint);
    }

    @Override
    public void update() {

    }
}
