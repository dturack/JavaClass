package hashtable;

/**
 *
 * @author dturack
 */
public interface InterfaceComb extends Names, java.lang.Comparable<Member>, java.io.Serializable {
    
}
