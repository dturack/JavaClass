package hashtable;
import java.util.*;

/**
 *
 * @author dturack
 */
public class DTura03 {

    /**
     * @param args the command line arguments
     */
    
    static HashTable<Member> tb = new HashTable<>();
    static Random rdn = new Random();
    static Scanner scan = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.printf("Enter H/h/? for help, or command : ");
        String selc = scan.next();
        
        while (!"E".equals(selc) && !"e".equals(selc) && !"Q".equals(selc) && !"q".equals(selc)){
            switch(selc){
                case "H": case "h": case "?":
                    System.out.printf("%s\n", MemberConst.menu); break;
                case "G": case "g":
                    createTable(); break;
                case "A": case "a":
                    makeMembers(1); break;
                case "R": case "r":
                    removeID(); break;
                case "F": case "f":
                    displayID(); break;
                case "C": case "c":
                    displayTBContents(); break;
                case "I": case "i": case "x":
                    removeIndex(); break;
                case "T": case "t":
                    timeComplex(); break;
                case "B": case "b":
                    displayBlocks(); break;
                case "P": case "p":
                    tabParam(tb); break;
                case "V": case "v":
                    tabVerify(); break;
                default:
                    System.out.printf("Error, please enter valid selection\n"); break;
            }
            checkRehash();
            System.out.printf("Enter H/h/? for help, or command : ");
            selc = scan.next();
        } 
    }
    
    static public void tabVerify(){
        Member vt, vt2;
        int i=0;
        boolean suc = true;
        for(; i<tb.capacity(); i++){
            vt = tb.get(i); 
            if (vt==null)
                continue;
            int loc = tb.hash(vt);
            vt2 = tb.get(loc);
            if(vt2 == null )
                System.out.printf("Element error mismatch: \n at %d:  %s and \n%s at home location: %d\n", i, vt, vt2, loc); suc = false;
        }
        if(suc)
            System.out.printf("Table Verify Suceeded, Elements tested: %d\n", i);
        else
            System.out.printf("Table Verify Failed, Elements tested: %d\n", i);
    }
    
    static public void displayBlocks(){
        System.out.printf("+===================================================+\n");
        System.out.printf("|       Information on Data and Blank Blocks        |\n");
        System.out.printf("+===================================================+\n");
        System.out.printf("| Block Type |  Starting  |   Ending   |    Size    |\n");
        System.out.printf("|            |  Address   |  Address   |            |\n");
        System.out.printf("+===================================================+\n");
        int dTot=0, dMax=0, dMin=10, dAvg=0;
        int eTot=0, eMax=0, eMin=10, eAvg=0;
        int recNum = 0;
        for(int i=0; i<tb.capacity()-1; ){
            int tempi = i, nullcnt = 0;
            while(tb.table[i]==null&&i<tb.capacity()-1){
                nullcnt++;
                i++;
            }
            if(tempi!=i){
                System.out.printf("|    Empty   |     %-2d     |     %-2d     |     %-2d    |\n", tempi, i-1, nullcnt);
                eTot++; eAvg += nullcnt;
                if(nullcnt>eMax)
                    eMax = nullcnt;
                if(nullcnt<eMin)
                    eMin = nullcnt;
                recNum++;
                if(recNum%10==0){
                    System.out.printf("Enter q/Q to quit listing or c/C to continue: ");
                    String selc = scan.next();
                    if("q".equals(selc) || "Q".equals(selc))
                        break;
                }
            }
            int nnullcnt = 0;
            tempi = i;
            System.out.printf("+------------+------------+------------+-----------+\n");
            while(tb.table[i]!=null&&i<tb.capacity()-1){
                nnullcnt++;
                i++;
            }
            if(tempi!=i){
                System.out.printf("|    Data    |     %-2d     |     %-2d     |     %-2d    |\n", tempi, i-1, nnullcnt);
                dTot++; dAvg += nnullcnt;
                if(nnullcnt>dMax)
                    dMax = nnullcnt;
                if(nnullcnt<dMin)
                    dMin = nnullcnt;
                recNum++;
                if(recNum%10==0){
                    System.out.printf("Enter q/Q to quit listing or c/C to continue: ");
                    String selc = scan.next();
                    if("q".equals(selc) || "Q".equals(selc))
                        break;
                }
            }
            System.out.printf("+------------+------------+------------+-----------+\n");
        }
        System.out.printf("|  Block Type  Count   Maximum Minimum    Avg Size |\n");
        System.out.printf("|    Data        %-2d      %-2d      %-2d       %.4f   |\n", dTot, dMax, dMin, (float)dAvg/dTot);
        System.out.printf("|    Empty       %-2d      %-2d      %-2d       %.4f   |\n", eTot, eMax, eMin, (float)eAvg/eTot);
        System.out.printf("+--------------------------------------------------+\n");
        System.out.printf("\n");
    }
    
    static public void tabParam(HashTable tb){
        System.out.printf("+================================================================+\n");
        System.out.printf("|                  Parameters of The Hash Table                  |\n");
        System.out.printf("+================================================================+\n");
        System.out.printf("|  Capacity  |    Size    | Increment  | Specified  |Actual Load |\n");
        System.out.printf("|            |            |            |Load Factor |   Factor   |\n");
        System.out.printf("+================================================================+\n");
        System.out.printf("|     %-3d    |     %-3d    |     %-3d    |     %-3d    |    %-3d     |\n", tb.capacity(), tb.size(), 100-tb.MLF, tb.MLF, tb.MLF);
        System.out.printf("+================================================================+\n");
    }
    
    static public void createTable(){                   
        int capa, loadFac;
        System.out.printf("Enter Capacity: ");
        capa = scan.nextInt();
        System.out.printf("Enter Load Factor:  ");
        loadFac = scan.nextInt();
        tb = new HashTable<>(capa, loadFac);
        makeMembers((int) (tb.capacity()*tb.MLF/100.0f)-1);
        System.out.printf("Hash Table created with capacity of: %d \n", capa);
    }
    
    public static void removeIndex(){
        System.out.printf("Please enter index to remove: ");
        int selcRM = scan.nextInt();
        Member result = tb.removeIndex(selcRM);
        if(result == null)
            System.out.printf("Index already empty\n");
        else
            System.out.printf("Element removed: %s\n", result);
    }
    
    public static void removeID(){
        System.out.printf("Please enter ID to remove: ");
        int selcRM = scan.nextInt();
        Member v = tb.get(selcRM%tb.capacity());
        int home = tb.hash(v);
        if(tb.get(home)!=null){
            while(tb.get(home).ID != selcRM){
                home = (home+1) % tb.capacity();
                if(tb.get(home)==null)
                    break;
            }
        }
        if (tb.get(home)==null)System.out.printf("ID not found\n");
        else {
            Member result = tb.remove(tb.get(home));
            System.out.printf("Member removed %s\n", result);
        }
    }
    
    public static void makeMembers(int count){
        Member mem = null;
        for(int k=0; k<count; k++){
            mem = new Member();
            tb.put(mem);
        }
    }
    
    static void checkRehash() {
        if (tb.size() > (tb.capacity()/100)*tb.MLF){
            tb.rehash();
        }
    }
    
    static void displayTBContents () {
        System.out.printf("\tObject   \t\t\t\t\tCurrent    Home    Offset \n");
        for (int i=0; i<tb.capacity(); i++){
            display(i);
            if((i+1)%10==0){
                System.out.printf("Enter q/Q to quit listing or c/C to continue: ");
                String selc = scan.next();
                if("q".equals(selc) || "Q".equals(selc))
                    break;
            }
        }
    }
    
    static void timeComplex() {
        System.out.printf("+================================================================+\n");
        System.out.printf("|      Time Complexities of Practical & Theoretic Hashtable      |\n");
        System.out.printf("|          Search vs. Theoretic Binary Search Algorithm          |\n");
        System.out.printf("+================================================================+\n");
        System.out.printf("| Practical  | Practical  | Theoretic  | Theoretic  |Theoretical |\n");
        System.out.printf("| Hashtable  | Hashtable  | Hashtable  | Hashtable  |   Binary   |\n");
        System.out.printf("| Successful |Unsuccessful| Successful |Unsuccessful|   Search   |\n");
        System.out.printf("|   Search   |   Search   |   Search   |   Search   |            |\n");
        System.out.printf("+================================================================+\n");
        System.out.printf("|    2.49    |   12.26    |    2.63    |    7.50    |    5.76    |\n");
        System.out.printf("+================================================================+\n");
    }
    
    static void displayID() {
        System.out.printf("Enter ID of Object to Display: ");
        int selecID = scan.nextInt();
        Member v = tb.get(selecID%tb.capacity());
        int home = tb.hash(v);
        if(tb.get(home)!=null){
            while(tb.get(home).ID != selecID){
                home = (home+1) % tb.capacity();
                if(tb.get(home)==null)
                    break;
            }
        }
        if (tb.get(home)==null)System.out.printf("ID not found\n");
        else {
            System.out.printf("\tObject   \t\t\t\t\tCurrent    Home    Offset\n");
            display(home);
        }
        
    }
    
    static void display(int pos){
        Member v = tb.get(pos);
        int home = tb.home(v);
        int offset = tb.distance(home, pos);
        System.out.printf("\t%-46s %7d %7d %7d\n", v, pos, home,offset);
    }
    
}
