package hashtable;
import java.util.*;
import java.lang.*;

/**
 *
 * @author student
 */
public class DTura03 {

    /**
     * @param args the command line arguments
     */
    
    static HashTable<Member> tb = new HashTable<>();
    static Random rdn = new Random();
    static Scanner scan = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.printf("Enter H/h/? for help, or command : ");
        String selc = scan.next();
        
        while (!"E".equals(selc) && !"e".equals(selc) && !"Q".equals(selc) && !"q".equals(selc)){
            switch(selc){
                case "H": case "h": case "?":
                    System.out.printf("%s\n", MemberConst.menu); break;
                case "G": case "g":
                    createTable(); break;
                case "A": case "a":
                    makeMembers(1); break;
                /*case "R": case "r":
                    removeID(); break;
                case "F": case "f":
                    displayID() ; break;*/
                case "C": case "c":
                    show(); break;
                    //displayTbContents(); break;
                /*case "I": case "i": case "x":
                    removeIndex(); break;
                case "T": case "t":
                    timeComplex(); break;
                case "B": case "b":
                    displayBlocks(); break;*/
                case "P": case "p":
                    tabParam(tb); break;
                /*case "V": case "v":
                    tabVerify(); break;*/
                default:
                    System.out.printf("Error, please enter valid selection\n"); break;
            }
            checkRehash();
            System.out.printf("Enter H/h/? for help, or command : ");
            selc = scan.next();
        } 
        /*for (int i=0; i<8; i++) {
            int rand = rdn.nextInt(100);
            tb.put();
            System.out.printf("%4d ", rand);
        }
        System.out.printf("\n");
        for (int i=0; i<tb.capacity(); i++)
            System.out.printf("\t\t %4d \n", tb.get(i));
        show();*/
    }
    
    static public void tabParam(HashTable tb){
        System.out.printf("Parameters of the Hash Table\n");
        System.out.printf("\t Capacity \t Size \t Increment \t Specified Load Factor \t Actual Load Factor \n");
        System.out.printf("\t%8d %7d %7d %7d %7d\n", tb.capacity(), tb.size(), 100-tb.MLF, tb.MLF, tb.MLF);
    }
    
    static public void createTable(){                   
        int capa, loadFac;
        System.out.printf("Enter Capacity: ");
        capa = scan.nextInt();
        System.out.printf("Enter Load Factor:  ");
        loadFac = scan.nextInt();
        tb = new HashTable<>(capa, loadFac);
        System.out.printf("Hash Table created with capacity of: %d", capa);
        makeMembers(((tb.capacity()/100)*tb.MLF)-1);
    }
    
    public static void makeMembers(int count){
        Member mem = null;
        for(int k=0; k<count; k++){
            int pick = rdn.nextInt(5)+1;
            switch(pick){
                case 1:
                    mem = new Member(); break;
                case 2:
                    mem = new Employee(); break;
                case 3:
                    mem = new Student(); break;
                case 4:
                    mem = new Faculty(); break;
                case 5:
                    mem = new Staff(); break;
            }
            tb.put(mem);
        }
    }
    
    static void checkRehash() {
        if (tb.size() >= (tb.capacity()/100)*tb.MLF){
            tb.rehash();
        }
    }
    
    static void show () {
        System.out.printf("\t\tObject   Current Home    Offset \n");
        for (int i=0; i<tb.capacity(); i++){
            Member v = tb.get(i);
            int home = tb.home(v);
            int offset = tb.distance(home, i);
            System.out.printf("\t\t%8s %7d %7d %7d\n", v, i, home,offset);
        }
    }
    
}
