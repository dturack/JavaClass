package hashtable;
import java.util.*;
/**
 *
 * @author student
 */
public class DTura03 {

    /**
     * @param args the command line arguments
     */
    
    static HashTable<Integer> tb = new HashTable<Integer>();
    static Random rdn = new Random();
    static Scanner scan = new Scanner(System.in);
    public static void main(String[] args) {
        // TODO code application logic here
        for (int i=0; i<8; i++) {
            int rand = rdn.nextInt(100);
            tb.put(rand);
            System.out.printf("%4d ", rand);
        }
        System.out.printf("\n");
        for (int i=0; i<tb.capacity(); i++)
            System.out.printf("\t\t %4d \n", tb.get(i));
        show();
    }
    
    static void show () {
        System.out.printf("\t\tObject   Current Home    Offset \n");
        for (int i=0; i<tb.capacity(); i++){
            Integer v = tb.get(i);
            int home = tb.home(v);
            int offset = tb.distance(home, i);
            System.out.printf("\t\t%8d %7d %7d %7d\n", v, i, home,offset);
        }
    }
    
}
