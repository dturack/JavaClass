package hashtable;
/**
 *
 * @author dturack
 */
public interface MemberConst {
    
	String menu = new StringBuilder(50).append("\t+===================================================+\n")
        .append("\t|    CS 3990 Assignment:  Linked List Structures    |\n")
        .append("\t+===================================================+\n")
        .append("\t| G: Ask for a N, and generate N members of mixed   |\n")
        .append("\t|     kinds and put them into three list structures.|\n")
        .append("\t|     Make sure you destroy the lists before create |\n")
        .append("\t|     new ones if the lists are not empty.          |\n")
        .append("\t+---------------------------------------------------+\n")
        .append("\t| S: List members in stack, 1 member per line,      |\n")
        .append("\t|     20 members per screen with header line, allow |\n")
        .append("\t|     Q/q to quit listing after each 20 members.    |\n")
        .append("\t+---------------------------------------------------+\n")
        .append("\t| Q: List members in queue (same requirements).     |\n")
        .append("\t+---------------------------------------------------+\n")
        .append("\t| O: List members in ordered queue sorted by SSN    |\n")
        .append("\t|    (same requirements).                           |\n")
        .append("\t|                                                   |\n")
        .append("\t+---------------------------------------------------+\n")
        .append("\t| D: Remove first element from queue, pop member    |\n")
        .append("\t|    from stack, and delete the same member from    |\n")
        .append("\t|    sorted queue as the one removed from stack.    |\n")
        .append("\t|                                                   |\n")
        .append("\t+---------------------------------------------------+\n")
        .append("\t| I: Randomly generate new member, and put          |\n")
        .append("\t|    the object into the three structures. Print    |\n")
        .append("\t|    out the new member added in.                   |\n")
        .append("\t+---------------------------------------------------+\n")
        .append("\t| H/?: Display this menu.                           |\n")
        .append("\t| E  : Exit                                         |\n")
        .append("\t+===================================================+\n").toString();
}
