
package hashtable;

/**
 *
 * @author dturack
 * @param <T>
 */
public class HashTable<T extends Comparable> {
    int capacity = 10, MLF = 80, size = 0;
    
    T table[] = null;
    
    @SuppressWarnings("unchecked")
    public HashTable() {
        table = (T[]) new Object[capacity];
    }
    
    @SuppressWarnings("unchecked")
    public HashTable(int cap, int mlf){
        capacity = cap; MLF = mlf;
        table = (T[]) new Object[capacity];        
    }
    
    protected int hash(T v) { 
        return v.hashCode() % capacity ;
    }
    
    public int home(T v){
        return hash(v);
    }
    protected void rehash(){}
    
    public int size() {return size;}
    public int capacity() {return capacity;}
    public T get(int i){return i<0 || i>= capacity ? null : table[i];}
    public int distance(int from, int to){
        return to >= from ? to - from : (capacity - from) + to;
    }
    
    public T put(T v) {
        if (size / (float) capacity >= MLF / 100.0f) rehash();
        int home = hash(v);
        for(; table[home] != null; ) home  = (home + 1) % capacity;
        table[home] = v;
        size++;
        return v;
    }
    
    public T remove(T v){
        int home = hash(v);
        /*while(table[home] != null && v.compareTo(table[home]) !=0)
            home = (home + 1) % capacity;
        if ( table[home] == null) return null;
        
        v = table[home];
        table[home] = null;
        size--;
        shift(home, (home+1)%capacity);
        return v;*/
        
        while(table[home] != null){
            if(v.compareTo(table[home])==0){
                v = table[home];
                table[home] = null;
                size--;
                shift(home, (home+1)%capacity);
                return v; 
            }
            else
                home = (home+1) % capacity;
        }
        return null;
        
    }
    
    protected void shift(int blank, int nxt){
        if (table[nxt] == null) return;
        int home  = home(table[nxt]);
        int distCH = distance(home, nxt);
        int distBH = distance(home, blank);
        
        if ( distBH < distCH){
            table[blank] = table[nxt];
            table[nxt] = null;
            shift(nxt, (nxt+1)%capacity);
        }else shift(blank, (nxt+1)%capacity);
    }
    
    /*protected void shift(int home){
        int i = home;
        while(table[i]!=null)
            
    }*/
}
