
package hashtable;

/**
 *
 * @author dturack
 * @param <T>
 */
public class HashTable<T> {
    int capacity = 10, MLF = 80, size = 0;
    
    T table[] = null;
    
    @SuppressWarnings("unchecked")
    public HashTable(int cap, int mlf){
        capacity = cap; MLF = mlf;
        table = (T[]) new Object[capacity];        
    }
    
    public add(T v)
}
