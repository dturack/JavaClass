
package hashtable;

/**
 *
 * @author dturack
 * @param <T>
 */
public class HashTable<T> {
    int capacity = 10, MLF = 80, size = 0;
    
    T table[] = null;
    
    @SuppressWarnings("unchecked")
    public HashTable() {
        table = (T[]) new Object[capacity];
    }
    
    @SuppressWarnings("unchecked")
    public HashTable(int cap, int mlf){
        capacity = cap; MLF = mlf;
        table = (T[]) new Object[capacity];        
    }
    
    protected int hash(T v) { 
        return v.hashCode() % capacity ;
    }
    
    public int home(T v){
        return hash(v);
    }
    protected void rehash(){}
    
    public int size() {return size;}
    public int capacity() {return capacity;}
    public T get(int i){return i<0 || i>= capacity ? null : table[i];}
    public int distance(int from, int to){
        return to >= from ? to - from : (capacity - from) + to;
    }
    
    public T put(T v) {
        if (size / (float) capacity >= MLF / 100.0f) rehash();
        int home = hash(v);
        for(; table[home] != null; ) home  = (home + 1) % capacity;
        table[home] = v;
        size++;
        return v;
    }
    
    public T remove(T v){
        return v;
    }
}
