package heap;
/**
 *
 * @author dturack
 */
public interface HeapConst {
    
	String menu = new StringBuilder(50).append("============================ 3390 Assignment 4 =======================\n" )
.append("|    Heap Sort - Entire or Part of Array                             |\n" )
.append("======================================================================\n" )
.append("| Command  |                   Description                           |\n" )
.append("+----------+---------------------------------------------------------+\n" )
.append("|   g G    |  Prompt for two integers, N for array size and K        |\n" )
.append("|          |  for the number of sections. Then create an array       |\n" )
.append("|          |of Integers with size of N, and an array of Border       |\n" )
.append("|          |objects with a size of K. Call initializing functions    |\n" )
.append("|          |         for each array.                                 |\n" )
.append("+----------+---------------------------------------------------------+\n" )
.append("|   b B    | Show Border Information                                 |\n" )
.append("+----------+---------------------------------------------------------+\n" )
.append("|   a A    | Display all integers in array, one section of integers  |\n" )
.append("|          |     per line. Include section number and border info.   |\n" )
.append("+----------+---------------------------------------------------------+\n" )
.append("|   s S    |   Ask section nunmber. Sort and display the requested   |\n" )
.append("|          | section. If Ff is entered, sort and display entire array|\n" )
.append("+----------+---------------------------------------------------------+\n" )
.append("|   d D    | Display array section containing integer S. If S is out |\n" )
.append("|          |   of range, display entire array.                       |\n" )
.append("+----------+---------------------------------------------------------+\n" )
.append("|   m M    |  Scramble or Mix the data in the entire array.          |\n" )
.append("+----------+---------------------------------------------------------+\n" )
.append("|   e E    |                 Exit the project.                       |\n" )
.append("|   h H ?  |                 Show this menu.                         |\n" )
.append("+----------+---------------------------------------------------------+\n").toString();
}
