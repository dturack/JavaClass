package heap;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author student
 */
public class DTura04 {

    /**
     * @param args the command line arguments
     */
    static Random rdn = new Random();
    static Scanner scan = new Scanner(System.in);
    static Integer dArr[];
    static Border brds[];
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.printf("Enter H/h/? for menu or E/e to exit: ");
        String selc = scan.next();
        
        while (!"E".equals(selc) && !"e".equals(selc) ){
            switch(selc){
                case "H": case "h": case "?":
                    System.out.printf("%s\n", HeapConst.menu); break;
                case "G": case "g":
                    generate(); break;
                case "B": case "b":
                    showBorders(); break;
                case "A": case "a":
                    showAllInt(); break;
                case "S": case "s":
                    sortSection(); break;
                case "D": case "d":
                    displayInt(); break;
                case "M": case "m": case "x":
                    scramble(); break;
                default:
                    System.out.printf("Error, please enter valid selection\n"); break;
            }
            System.out.printf("Enter H/h/? for menu or E/e to exit: ");
            selc = scan.next();
        } 

    }
    
    static void scramble(){
        for (int i=0; i<dArr.length; i++){
            swapRdm(i);
        }
        System.out.printf("Array Scrambled\n");
    }
    
    static void swapRdm(int p1){
        int randm = rdn.nextInt(dArr.length);
        int tmp = dArr[p1];
        dArr[p1] = dArr[randm];
        dArr[randm] = tmp;
    }
    
    static void sortSection(){
        System.out.printf("Please enter Section number: ");
        int sect = scan.nextInt();
        MinHeap mnHp;
        if(sect >= brds.length || sect < 0){
            //sort and display entire array
            mnHp = new MinHeap(dArr);
            mnHp.sort(0, dArr.length);
            showAllInt();
        }
        else{
            //sort and display section
            mnHp = new MinHeap(dArr, brds[sect].start, brds[sect].size);
            //mnHp = new MinHeap(dArr2, 0, 10);
            mnHp.sort(brds[sect].start, brds[sect].size);
            System.out.printf("Section #: %d - ", sect);
            for(int i=mnHp.start; i<mnHp.size+mnHp.start; i++){
                System.out.printf("%7d, ", dArr[i]);
            }
            System.out.printf("\n");
        }
        
    }
    
    static void displayInt(){
        System.out.printf("Enter Integer to search for: ");
        int srch = scan.nextInt();
        int fnd = -1;
        for (int i=0; i<brds.length; i++){
            int tmpStrt = brds[i].start, tmpEnd = brds[i].start+brds[i].size;
            if(srch < dArr[tmpStrt] && srch > dArr[tmpEnd]){
                for(int k=tmpStrt; k<tmpEnd; k++)
                    if(dArr[k].compareTo(srch) == 0)
                        fnd = i;
            }
        }
        if(fnd>=0){
            System.out.printf("Integer found in %d section: \n", fnd);
            for(int i=brds[fnd].start; i<brds[fnd].size+brds[fnd].start; i++){
                System.out.printf("%d, ", dArr[i]);
            }
            System.out.printf("\n");            
        }
        else{
            System.out.printf("Integer not found.  Array: \n");
            for(int i=0; i<dArr.length; i++){
                System.out.printf("%d, ", dArr[i]);
            }
            System.out.printf("\n");
        }
    }
    
    static void showAllInt(){
        int size = dArr.length/brds.length;
        if (size<=0){
            System.out.printf("Arrays are empty, may need to initialize\n");
            return;
        }
        for(int i=0; i<brds.length; i++){
            System.out.printf("Section #: %d  -  ", i);
            int brdstart = brds[i].start;
            for(int k=0; k<brds[i].size; k++){
                System.out.printf(" %7d,", dArr[brdstart+k]);
            }
            System.out.printf("\n");
        }
    }
    
    static void showBorders(){
        int x = dArr.length, y = brds.length;
        System.out.printf("For N = %d, K = %d, section size = %d/%d = %d\n", x, y, x, y, x/y);
        for(int i=0; i<brds.length; i++){
            System.out.printf("%3d:[%3d, %3d], ", i, brds[i].start, (brds[i].start+brds[i].size-1));
        }
        System.out.printf("-- before the heap is introduced\n");
        for(int i=0; i<brds.length; i++){
            System.out.printf("%3d:[%3d, %3d], ", i, brds[i].start, brds[i].size);
        }
        System.out.printf("--for convience of heapsort\n");
    }
    
    static void generate(){
        int n, k;
        System.out.printf("Please enter N value for array size: ");
        n = scan.nextInt();
        System.out.printf("Please enter K value for number of sections: ");
        k = scan.nextInt();
        brds = new Border[k];
        dArr = new Integer[n];
        for(int i=0; i<n; i++) dArr[i] = rdn.nextInt(dArr.length*50);
        int size = n/k, start = 0;
        for (int i=0; i<k; i++){
            brds[i] = new Border(start, size);
            start += size;
        }
        brds[k-1].size = size + n%k;
    }
}
