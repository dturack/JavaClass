package heap;

import java.util.Scanner;

/**
 *
 * @author dturack
 * @param <T>
 */
public class MinHeap<T extends Comparable> {
    int start, size;
    T arr[] = null;
    
    public MinHeap(T [] arr){
        start = 0; size = arr.length; this.arr = arr; }
    
    public MinHeap(T [] arr, int size){
        start = 0; this.size = size; this.arr = arr;
    }
    
    public MinHeap(T [] arr, int start, int size){
        this.start = start; this.size = size; this.arr = arr;
    }
    
    void heapify(){
        for(int i = (start+size-1)/2; i>=start; i--){
            heapDown(i);
        }
    }
    
    void heapDown(int parent){
        int smallChild = getSmallChild(parent);
        if (smallChild<0)
            return;
        if(smallChild!=parent){
            T tmp = arr[parent]; arr[parent] = arr[smallChild]; arr[smallChild] = tmp;
            heapDown(smallChild);
        }
    }
     
    int getSmallChild(int parent){
        int lChild = parent*2+1;
        if (outOfBound(lChild)) return -1;
        int rChild = lChild+1;
        if (outOfBound(rChild)) {
            return arr[lChild].compareTo(arr[parent]) <0 ? lChild : parent;
        }
        int smlrChild = arr[lChild].compareTo(arr[rChild]) <= 0 ? lChild : rChild;
        return arr[smlrChild].compareTo(arr[parent]) < 0 ? smlrChild : parent;
    }
    
    boolean outOfBound(int pos){
        return pos >= start+size-1; // || pos < start;
    }
    
    public void sort(){
        int origSize = size;
        T tmp;
        heapify();
        for(; size > 1; size--){
            tmp = arr[start]; 
            arr[start] = arr[start+size-1]; 
            arr[start+size-1] = tmp;
            heapDown(start);
        }
        size = origSize;
    }
    
}
