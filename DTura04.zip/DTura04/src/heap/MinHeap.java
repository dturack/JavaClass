package heap;

import java.util.Scanner;

/**
 *
 * @author dturack
 * @param <T>
 */
public class MinHeap<T extends Comparable> {
    int start, size;
    T arr[] = null;
    
    public MinHeap(T [] arr){
        start = 0; size = arr.length; this.arr = arr; }
    
    public MinHeap(T [] arr, int size){
        start = 0; this.size = size; this.arr = arr;
    }
    
    public MinHeap(T [] arr, int start, int size){
        this.start = start; this.size = size; this.arr = arr; }
    
    void heapify(){
        for(int i = (start+size-2)/2; i>=start; i--){
            heapDown(i);
        }
    }
    
    void heapDown(int parent){
        System.out.printf("Size: %d Start: %d \n", size, start);
        int smallChild = getSmallChild(parent);
        if (smallChild<0)
            return;
        if(arr[smallChild].compareTo(arr[parent]) < 0){
            System.out.printf("Swap %d and %d \n", arr[parent], arr[smallChild]);
            T tmp = arr[parent]; arr[parent] = arr[smallChild]; arr[smallChild] = tmp;
            heapDown(smallChild);
        }
    }
     
    int getSmallChild(int parent){
        int lChild = (parent-start)*2+1+start;
        if (outOfBound(lChild)) return -1;
        int rChild = lChild+1;
        if (outOfBound(rChild)) {
            return arr[lChild].compareTo(arr[parent]) <0 ? lChild : -1;
        }
        int smlrChild = arr[lChild].compareTo(arr[rChild]) <= 0 ? lChild : rChild;
        return arr[smlrChild].compareTo(arr[parent]) < 0 ? smlrChild : parent;
    }
    
    boolean outOfBound(int pos){
        return pos >= start+size-1;// || pos < start;
    }
    
    public void sort(){
        int origSize = size;
        T tmp;
        System.out.printf("%d\n",arr[start]);
        heapify();
        System.out.printf("%d  Size: %d  Start: %d \n",arr[start],size, start);
        for(; size > 1; size--){
            tmp = arr[start]; 
            arr[start] = arr[start+size-1]; 
            arr[start+size-1] = tmp;
            heapDown(start);
        }
        size = origSize;
    }
    
}
