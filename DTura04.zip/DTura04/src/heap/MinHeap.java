package heap;

import java.util.Scanner;

/**
 *
 * @author dturack
 * @param <T>
 */
public class MinHeap<T extends Comparable> {
    int start, size;
    T arr[] = null;
    
    public MinHeap(T [] arr){
        start = 0; size = arr.length; this.arr = arr; }
    
    public MinHeap(T [] arr, int size){
        start = 0; this.size = size; this.arr = arr;
    }
    
    public MinHeap(T [] arr, int start, int size){
        this.start = start; this.size = size; this.arr = arr; }
    
    void heapify(){
        for(int i = start+(size-2)/2; i>=start; i--){
            heapDown(i);
        }
    }
    
    void heapDown(int parent){
        //I was able to greater reduce the number of lines of code to simplify things
        while(((parent-start)*2+1+start)<=start+size-1){
            int child = (parent-start)*2+1+start;
            if (child+1 < size+start-1 && arr[child+1].compareTo(arr[child])<0)
                child = child +1;
            if (child < size+start-1 && arr[child].compareTo(arr[parent]) < 0){
                swapVal(arr, parent, child);
                parent = child;
            }
            else
                return;
        }
    } 
    
    // Old heapDown function
        /*int smallChild = getSmallChild(parent);
        if (smallChild<0)
            return;
        if(arr[smallChild].compareTo(arr[parent]) < 0){
            swapVal(arr,parent, smallChild);
            heapDown(smallChild);
        }*/
    
    //condensed code so function no longer necessary
    /*int getSmallChild(int parent){
        int lChild = ((parent-start)*2)+1+start;
        if (outOfBound(lChild)) return -1;
        int rChild = lChild+1;
        if (outOfBound(rChild)) {
            return arr[lChild].compareTo(arr[parent]) <0 ? lChild : -1;
        }
        int smlrChild = arr[lChild].compareTo(arr[rChild]) <= 0 ? lChild : rChild;
        return arr[smlrChild].compareTo(arr[parent]) < 0 ? smlrChild : -1;
    }
    
    boolean outOfBound(int pos){
        return pos >= start+size-1;// || pos < start;
    }*/
    
    public void swapVal(T [] arr1, int pos1, int pos2){
        T tmp = arr1[pos1];
        arr1[pos1] = arr1[pos2];
        arr1[pos2] = tmp;
    }
    
    public void sort(T [] arr1, int str, int sz){
        arr = arr1; //values passed in are assigned to the minheap values
        size = sz;
        start = str;
        T tmp;
        heapify();
        for(; size > 1; size--){
            swapVal(arr, start, (start+size-1));
            heapDown(start);
        }
        size = sz; //each value is restored
        start = str;
        arr = arr1;
        //verify last two elements
        if(arr[start+size-2].compareTo(arr[start+size-1])<0)
            swapVal(arr, start+size-1, start+size-2);
    }
    
}
