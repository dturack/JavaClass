/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heap;

/**
 *
 * @author student
 * @param <T>
 */
public class MinHeap<T extends Comparable> {
    int start, size;
    T arr[] = null;
    
    public MinHeap(T [] arr){
        start = 0; size = arr.length; this.arr = arr; }
    
    public MinHeap(T [] arr, int size){
        start = 0; this.size = size; this.arr = arr;
    }
    
    public MinHeap(T [] arr, int start, int size){
        this.start = start; this.size = size; this.arr = arr;
    }
    
    void heapify(){
        for(int i = (start+size-2) /2; i>=start; i--){
            heapDown(i);
        }
    }
    
    void heapDown(int parent){
        int smallChild = getSmallChild(parent);
        if(arr[smallChild].compareTo(arr[parent]) <0){
            T tmp = arr[parent]; arr[parent] = arr[smallChild]; arr[smallChild] = tmp;
            heapDown(smallChild);
        }
    }
     
    int getSmallChild(int parent){
        int lChild = (parent-start)*2+1+start;
        if (outOfBound(lChild)) return -1;
        int rChild = lChild+1;
        if (outOfBound(rChild)) {
            if(arr[lChild].compareTo(arr[parent])<0)
                return lChild;
        }
        int smlrChild = arr[lChild].compareTo(arr[rChild]) <= 0 ? lChild : rChild;
        return arr[smlrChild].compareTo(arr[parent]) < 0 ? smlrChild : -1;
    }
    
    boolean outOfBound(int pos){
        return pos >= start+size;
    }
    
    public void sort(){
        int origSize = size;
        T tmp;
        for(; size > 1; size--){
            tmp = arr[start]; 
            arr[start] = arr[start+size-1]; 
            arr[start+size-1] = tmp;
            heapDown(start);
        }
        size = origSize;
    }
    
}
