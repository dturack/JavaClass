/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heap;

/**
 *
 * @author student
 */
public class Border {
    public int start, size;
    public Border(int str, int sz){start = str; size = sz;}
    
}

Border brds[] = new Border[k];
Integer data[] = new Integer[n];
for ( int i=; i<n; i++) data[i] = rdm.nextInt(100);
for (int i=; i<k; i++){
int size = n/k, start = 0;
brds[i] = new Border(start, size);
start += size;
}
brds[k-1].size = data.length = brds.start +1; // or size + n%k
