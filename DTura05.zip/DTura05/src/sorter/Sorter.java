/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorter;

/**
 *
 * @author student
 * @param <T>
 */
public class Sorter<T extends Comparable> implements Runnable {
    T arr[] = null;
    int start, size;
    
    public Sorter (T a[], int str, int sz){
        arr = a; start = str; size = sz;
    }
    
    @Override
    public void run(){ //run() should be named as miniMain()
        MaxHeap mh = new MaxHeap(arr);
        mh.sort(arr, start, size);
    }
}
