package sorter;

import java.util.Scanner;

/**
 *
 * @author dturack
 * @param <T>
 */
public class MaxHeap<T extends Comparable> {
    int start, size;
    T arr[] = null;
    
    public MaxHeap(T [] arr){
        start = 0; size = arr.length; this.arr = arr; }
    
    public MaxHeap(T [] arr, int size){
        start = 0; this.size = size; this.arr = arr;
    }
    
    public MaxHeap(T [] arr, int start, int size){
        this.start = start; this.size = size; this.arr = arr; }
    
    void heapify(){
        for(int i = start+(size-2)/2; i>=start; i--){
            heapUp(i);
        }
    }
    
    void heapUp(int child){
        //I was able to greater reduce the number of lines of code to simplify things
        int parent = child/2;
        while(parent>start){
            if (arr[child].compareTo(arr[parent]) > 0){
                swapVal(arr, parent, child);
                child = parent;
                parent = child/2;
            }
            else
                return;
        }
    } 
       
    public void swapVal(T [] arr1, int pos1, int pos2){
        T tmp = arr1[pos1];
        arr1[pos1] = arr1[pos2];
        arr1[pos2] = tmp;
    }
    
    public void sort(T [] arr1, int str, int sz){
        arr = arr1; //values passed in are assigned to the minheap values
        size = sz;
        start = str;
        T tmp;
        heapify();
        for(; size > 1; size--){
            swapVal(arr, start, (start+size-1));
            heapUp(start);
        }
        size = sz; //each value is restored
        start = str;
        arr = arr1;
        //verify last two elements
        if(arr[start+size-2].compareTo(arr[start+size-1])<0)
            swapVal(arr, start+size-1, start+size-2);
    }
    
}
