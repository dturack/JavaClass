package threads;

/**
 *
 * @author dturack
 */
public class Border {
    public int start, size;
    public Border(int str, int sz){start = str; size = sz;}
    
}


