package threads;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dturack
 */
public class DTura05 {
    
    static Random rdn = new Random();
    static Scanner scan = new Scanner(System.in);

    static Integer [] arrs[] = new Integer[2][]; //{ new Integer [] {}, new Integer[] {} };
    
    static Border bdrs[] = new Border[4];
    static int n = 42, k = 4, level;
    
    static Thread lv1Mgr[][] = new Thread[k/2][];
    //Thread lv2Mgr[][] = new Thread[k/2/2][];
    static Thread sorter [] = new Thread[k];
    
    void initialize(){
        for (int i =0; i< arrs.length; i++){
            arrs[i] = new Integer[n];
        }
        
        for(int i = 0; i<n; i++){
            arrs[0][i] = (int) (Math.random() * n * 50);
        }
        
        for(int i=0; i<sorter.length; i++){
            sorter[i] = new Thread ( new Sorter(arrs[0], bdrs[i].start, bdrs[i].size));
            sorter[i].start();
        }
    }
    static void startThreads() {
        for(int i = 0; i<k; i++) {
            sorter[i] = new Thread ( new Sorter(arrs[0], bdrs[i].start, bdrs[i].size));
            sorter[i].start();
        }
    }
    
    static void startLV1Merger(){
        for(int i= 0; i< lv1Mgr.length; i++){
            lv1Mgr[i] = new Thread (new Merger<Integer> (arrs[0],
            bdrs[i*2].start, bdrs[i*2].size,
            bdrs[i*2+1].start, bdrs[i*2+1].size,
            arrs[1], sorter[i*2], sorter[i*2+1]));
            //for(int j = 0; j<mgr[lv].length; j++)
                //mgr[lv][j] = new Merger(arrs, 0, lv, );
        }
    }
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        //DTura05 app = new DTura05();
        //app.initialize();
        System.out.printf("How many elements? ");
        int scn = scan.nextInt();
        Integer arr[] = new Integer[scn];
        System.out.printf("Unsorted Array: \n");
        for(int i=0; i<scn; i++){
            arr[i] = rdn.nextInt(arr.length*50);
            System.out.printf("%d, ", arr[i]);
        }
        System.out.printf("\n");
        MaxHeap mxHp = new MaxHeap(0, arr, 0, arr.length);
        mxHp.run();
        System.out.printf("Sorted Array: ");
        for (int i=0; i<scn; i++){
            System.out.printf("%d, ", arr[i]);
        }
        System.out.printf("\n");
    }
    
}
