package threads;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dturack
 */
public class DTura05 {
    
    static Random rdn = new Random();
    static Scanner scan = new Scanner(System.in);

    Integer [] arrs[] = new Integer[2][]; //{ new Integer [] {}, new Integer[] {} };
    
    Border bdrs[] = new Border[4];
    int n, k = 4, level;
    
    Thread mgr[][] = new Thread[2][];
    Thread sorter [] = new Thread[4];
    
    void initialize(){
        for (int i =0; i< arrs.length; i++){
            arrs[i] = new Integer[n];
        }
        
        for(int i = 0; i<n; i++){
            arrs[0][i] = (int) (Math.random() * n * 50);
        }
        
        for(int i=0; i<sorter.length; i++){
            sorter[i] = new Thread ( new Sorter(arrs[0], bdrs[i].start, bdrs[i].size));
            sorter[i].start();
        }
        
        for(int lv= mgr.length-1; lv>=0; lv--){
            //for(int j = 0; j<mgr[lv].length; j++)
                //mgr[lv][j] = new Merger(arrs, 0, lv, );
        }
        
        
        
    }
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        //DTura05 app = new DTura05();
        //app.initialize();
        System.out.printf("How many elements? ");
        int scn = scan.nextInt();
        Integer arr[] = new Integer[scn];
        System.out.printf("Unsorted Array: \n");
        for(int i=0; i<scn; i++){
            arr[i] = rdn.nextInt(arr.length*50);
            System.out.printf("%d, ", arr[i]);
        }
        System.out.printf("\n");
        MaxHeap mxHp = new MaxHeap(arr);
        mxHp.sort(arr, 0, arr.length);
        System.out.printf("Sorted Array: ");
        for (int i=0; i<scn; i++){
            System.out.printf("%d, ", arr[i]);
        }
        System.out.printf("\n");
    }
    
}
