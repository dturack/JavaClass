package threads;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dturack
 */
public class DTura05 {
    
    static Random rdn = new Random();
    static Scanner scan = new Scanner(System.in);

    static Integer [] arrs[] = new Integer[2][]; //{ new Integer [] {}, new Integer[] {} };
    
    
    //static Border bdrs[] = {new Border(0,10), new Border(10,10), new Border(20, 10), new Border(30, 12)}; 
    
    static int n = 42, k = 4;
    
    static Border bdrs[] = new Border[k];
    static Thread lv1Mgr[] = new Thread[k/2];
    static Thread lv2Mgr[] = new Thread[k/2/2];
    static Thread sorter [] = new Thread[k];
    
    static void initialize(){
        System.out.printf("How many elements in Array: ");
        n = scan.nextInt();
        int sz = n/k;
        int strt = 0;
        for (int i=0; i<k; i++){
            bdrs[i] = new Border(strt, sz);
            strt = strt+sz;
        }
        bdrs[k-1].size = bdrs[k-1].size + n%k;
        
        for (int i =0; i< arrs.length; i++){
            arrs[i] = new Integer[n];
        }
        
        for(int i = 0; i<n; i++){
            arrs[0][i] = (int) (Math.random() * n * 20);
        }
    }
    static void startThreads() {
        for(int i = 0; i<k; i++) {
            sorter[i] = new Thread ( new MaxHeapSorter<>(i, arrs[0], bdrs[i].start, bdrs[i].size));
            sorter[i].start();
        }
    }
    
    static void startLV1Merger(){
        for(int i= 0; i< lv1Mgr.length; i++){
            lv1Mgr[i] = new Thread (new Merger<> (arrs[0],
            bdrs[i*2].start, bdrs[i*2].size,
            bdrs[i*2+1].start, bdrs[i*2+1].size,
            arrs[1], sorter[i*2], sorter[i*2+1]));
            lv1Mgr[i].start();
        }
    }
    
    static void startLV2Merger(){
        for(int i= 0; i< lv2Mgr.length; i++){
            lv2Mgr[i] = new Thread (new Merger<> (arrs[1],
            bdrs[i*2].start, bdrs[i*2].size + bdrs[i*2+1].size,
            bdrs[i*2+2].start, bdrs[i*2+2].size + bdrs[i*2+3].size,
            arrs[0], sorter[i*2], sorter[i*2+2]));
            lv2Mgr[i].start();
        }
    }    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
System.out.printf("Enter H/h/? for help, or command : ");
        String selc = scan.next();
        
        while (!"E".equals(selc) && !"e".equals(selc) && !"Q".equals(selc) && !"q".equals(selc)){
            switch(selc){
                case "H": case "h": case "?":
                    System.out.printf("%s\n", ThreadConst.menu); break;
                case "G": case "g":
                    initialize(); sortArray(); break;
                case "B": case "b":
                    showBorders(); break;
                case "A": case "a":
                    showWithBorders("Final Array with Border Division", arrs[0]); break;
                case "S": case "s":
                    showResults(); break;
                default:
                    System.out.printf("Error, please enter valid selection\n"); break;
            }
            System.out.printf("Enter H/h/? for help, or command : ");
            selc = scan.next();
        }
        //show( "Original Data", arrs[0]) ;

        
	//show("After Sections Are Sorted", arrs[0] ) ;
	

    }
    
    static void showBorders(){
        if(arrs[0]==null){
            System.out.printf("Error, Array has not been initialized\n");
            return;
        }
        int x = n, y = k;
        System.out.printf("For N = %d, K = %d, section size = %d/%d = %d\n", x, y, x, y, x/y);
        for(int i=0; i<bdrs.length; i++){
            System.out.printf("%3d:[%3d, %3d], ", i, bdrs[i].start, (bdrs[i].start+bdrs[i].size-1));
        }
        System.out.printf("-- Start and End Positions\n");
        for(int i=0; i<bdrs.length; i++){
            System.out.printf("%3d:[%3d, %3d], ", i, bdrs[i].start, bdrs[i].size);
        }
        System.out.printf("--Start and Size Info\n");
    }

    static void showWithBorders( String title, Integer [] a ) {
        if(arrs[0]==null){
            System.out.printf("Error, Array has not been initialized\n");
            return;
        }
        System.out.printf("\n\t\t====== %s ==========", title);
        for ( int i = 0; i < k; i ++ ) {
            System.out.printf("\nSection [%d] [%d, %d] ", i, bdrs[i].start, bdrs[i].size);
            for ( int j = bdrs[i].start ; j < bdrs[i].size + bdrs[i].start; j ++ ){
                if((j-bdrs[i].start)%10==0)
                    System.out.printf("\n\t\t");
                System.out.printf("%6d ", a[j]);
            }
        }
        System.out.printf("\n");	
    }    
    
    static void showResults(){
        if(arrs[1] == null){
            System.out.printf("Error, Array has not been initialized\n");
            return;
        }
        
        //clear input buffer
        String clear;
        if (scan.hasNextLine())
            clear = scan.nextLine();
        
        show("After Level One Merged", arrs[1]);

        show("Final Sorted Result", arrs[0]);
    }
    
    static void sortArray(){
        startThreads();
        
        startLV1Merger();
        
        startLV2Merger();

        System.out.printf("\nArray has been sorted\n");
    }
    
    static void show( String title, Integer [] a ) {

        System.out.printf("\n\t\t====== %s ==========\n", title);
        int i=0, t=0, d=0;
        //System.out.printf("\nSection [%d] [%d, %d]: \n", i, bdrs[i].start, bdrs[i].size);
        for ( int j = 0 ; j < a.length; j++ ){
            /*if(bdrs[i+1].start == j){
            i++;
            System.out.printf("\nSection [%d] [%d, %d]: \n", i, bdrs[i].start, bdrs[i].size);
            t = 0;
            }*/
            System.out.printf("%6d ", a[j]);
            t++;
            if(t==10){
                System.out.printf("\n");
                d++;
                t = 0;
            }

            if((d+1)%20==0){
               d++;
               System.out.printf("Enter q/Q to quit listing or RETURN to continue: ");
               String selc = scan.nextLine();
               if(selc.isEmpty())
                   continue;
               else if("q".equals(selc) || "Q".equals(selc))
                   break;
            }
        }
        System.out.printf("\n\n");	
    }
}
