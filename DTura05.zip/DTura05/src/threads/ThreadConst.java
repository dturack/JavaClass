package threads;
/**
 *
 * @author dturack
 */
public interface ThreadConst {
    
	String menu = new StringBuilder(50).append("============================ 3390 Assignment 5 ==========================\n" )
.append("|                  Multi-Threaded Multi-Leval Two-Way Meree Sort.          |\n" )
.append("============================================================================\n" )
.append("| Command  |                         Description                           |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   g G    | 1. Ask N for array size. 2. Create two  arrays of some sizes. |\n" )
.append("|          | Fill the first array with random integers. 3.  Fill first     |\n" )
.append("|          | array into 4 section, 4. Create 4 sorter threads and allocate |\n" )
.append("|          | one sect to each sorter. 5. Create two levels of mergers,     |\n" )
.append("|          |  the level for merging the sorters's results has two mergers, |\n" )
.append("|          |  each of them wainging two sorters. The next level of mergers |\n" )
.append("|          |   has one merger which merges the result of two mergers.      |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   s S    | 1. Show the results of two array with 10 values perline,      |\n" )
.append("|          | and 20 lines per screen. After each screen, Q/q will stop     |\n" )
.append("|          | listing and RETURN without letter to contiune.                |\n" )
.append("|          | 2.  Print out the array which contain the final sorted result |\n" )
.append("|          | after the other array.                                        |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   e E    |                 Exit the project.                             |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   h H ?  |                 Show this menu.                               |\n" )
.append("+----------+---------------------------------------------------------------+\n").toString();
}
