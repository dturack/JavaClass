package threads;

/**
 *
 * @author dturack
 * @param <T>
 */
public class Merger <T extends Comparable> implements Runnable {
    T [] src = null, dest = null;
    int start1, start2, size1, size2;
    Thread thr1 = null, thr2 = null;
    
    
    public Merger (T sr[], int str1, int sz1, int str2, int sz2, T dst[], Thread t1, Thread t2){
        src = sr; dest = dst; start1 = str1; size1 = sz1; start2 = str2; size2 = sz2;
        thr1 = t1; thr2 = t2;
    }
    
    @Override
    public void run(){ //run() should be named as miniMain()
        try{
            if(thr1!=null) thr1.join();
            if(thr2!=null) thr2.join();
        } catch (InterruptedException e) {}
        
        int i = start1, j = start2, k = start1;
        
        while(i<start1+size1 && j<start2+size2){
            dest[k++] = src[i].compareTo(src[j])<=0 ? src[i++]:src[j++];
        }
        while(i<start1+size1)
            dest[k++] = src[i++];
        while(j<start2+size2)
            dest[k++] = src[j++];
    }    
}
