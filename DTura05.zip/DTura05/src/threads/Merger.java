/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

/**
 *
 * @author student
 * @param <T>
 */
public class Merger <T extends Comparable> implements Runnable {
    T src[] = null, dest[] = null;
    int start1, start2, size1, size2, end1, end2;
    
    public Merger (T sr[], int str1, int sz1, int str2, int sz2, T dst[]){
        src = sr; dest = dst; start1 = str1; size1 = sz1; start2 = str2; size2 = sz2;
        end1 = start1 + size1; end2 = start2+size2;
    }
    
    @Override
    public void run(){ //run() should be named as miniMain()
        int i = start1, j = start2, k = start1;
        
        while(i<end1 && j<end2){
            dest[k++] = src[i].compareTo(src[j])<=0 ? src[i++]:src[j++];
        }
        while(i<end1)
            dest[k++] = src[i++];
        while(j<end2)
            dest[k++] = src[j++];
    }    
}
