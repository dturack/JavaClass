package threads;

/**
 *
 * @author dturack
 * @param <T>
 */
public class MaxHeap<T extends Comparable> {
    int ID, start, size;
    T arr[] = null;
    
    public MaxHeap(int id, T [] data, int str, int sz){
        ID = id; arr = data; start = str; size = sz;
    }
    
    void heapify(){
        for(int i = start+(size-2)/2; i>=start; i--){
            heapDown(i);
        }
    }
    
    void heapDown(int parent){
        while(((parent-start)*2+1+start)<=start+size-1){
            int child = (parent-start)*2+1+start;
            if (child+1 < size+start-1 && arr[child+1].compareTo(arr[child])> 0)
                child = child +1;
            if (child < size+start-1 && arr[child].compareTo(arr[parent]) > 0){
                swapVal(arr, parent, child);
                parent = child;
            }
            else
                return;
        }
    }
        
        
        /*int lChild = (parent-start)*2+1+start;
        int rChild = lChild + 1;
        int maxNode = parent;
        if(lChild < size+start-1 && arr[lChild].compareTo(arr[parent]) > 0)
            maxNode = lChild;
        if(rChild < size+start-1 && arr[rChild].compareTo(arr[maxNode]) > 0)
            maxNode = rChild;
        if(maxNode != parent){
            swapVal(arr, parent, maxNode);
            heapDown(maxNode);
        }
            
    }*/
    
    void heapUp(int child){
        int parent = child/2;
        while(parent>start){
            if (arr[child].compareTo(arr[parent]) > 0){
                swapVal(arr, parent, child);
                child = parent;
                parent = child/2;
            }
            else
                return;
        }
    } 
       
    public void swapVal(T [] arr1, int pos1, int pos2){
        T tmp = arr1[pos1];
        arr1[pos1] = arr1[pos2];
        arr1[pos2] = tmp;
    }
    
    public void sort(){
        int origSize = size;
        T tmp;
        heapify();
        while( size > 1 ){
            swapVal(arr, start, (start+size-1));
            size--;
            heapDown(start);
        }
        size = origSize;
    }
    
    public void run(){
        System.out.printf("Sorter[%d] is running", ID);
        sort();
    }
    
}
