/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura08;
import java.io.*;
import java.net.*;
/**
 *
 * @author student
 */
public class SAgent implements Runnable{
    int ID;
    Socket sk;
    public SAgent(int id, Socket sk){
        ID = id; this.sk = sk;
    }
    
    @Override
    public void run(){
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        
    }
}
