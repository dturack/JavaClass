/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura08;
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class DTura08 {

    static ServerSocket ssk = null;
    static int nextID = 0;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {ssk = new ServerSocket(9901);} 
        catch (Exception e) { 
            System.out.printf("Error occurred when server socket instantiated");
            e.printStackTrace();
            return;
        }
        while(true){
            Socket sk = null;
            
            try{
                sk = ssk.accept();
                new SAgent(++nextID, sk);
                SAgent.start();
            }catch(IOException ex) {}
        }
    }
    
}
