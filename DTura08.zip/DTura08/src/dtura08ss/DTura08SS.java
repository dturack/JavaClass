package dtura08ss;

/**
 *
 * @author dturack
 */
import java.net.*;
import java.io.*;
import java.util.Vector;

public class DTura08SS {

    static int portNo = 1992;
    static int clientNO = 0;

    public static void main ( String args[] ) {
	ServerSocket ssk = null;
	Socket 	     sk  = null;
	try { ssk = new ServerSocket ( portNo);
	} catch (Exception e ) { e.printStackTrace() ; }

	ChatMonitor chatMtr = new ChatMonitor();

	Thread th = null;
	while ( true )  {
	    try {
		sk = ssk.accept();
		System.out.printf("\n\t\tClient %d is connected.", ++clientNO );
		th = new Thread ( new SAgent ( clientNO,  sk, chatMtr ) );
		th.start();

	    } catch ( Exception e) { e.printStackTrace(); return; }
	}
    }
}   


