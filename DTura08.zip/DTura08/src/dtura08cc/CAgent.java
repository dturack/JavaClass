package dtura08cc;

import java.io.ObjectInputStream;
import javax.swing.JTextArea;

/**
 *
 * @author dturack
 */

class CAgent implements Runnable {

    ObjectInputStream in = null;
    JTextArea	      msg = null;

    public CAgent ( ObjectInputStream in, JTextArea msg ) {
	this.in = in; this.msg = msg;
    }

    public void run( ) {
	Object obj ;
        String mssg ;
	while ( true ) {
	    try {
		mssg = (String) in.readObject();
                boolean test = checkWelcome(mssg) || checkGoodbye(mssg);
                if(!test){
                    msg.append( mssg + '\n');
                }
	    } catch ( Exception e ) { e.printStackTrace(); }
	}
    }
    
    public boolean checkGoodbye(String mssg){
        if (mssg.contains("/?/")){
            int idx = mssg.indexOf("/?/");
            mssg = mssg.substring(0,idx);
            idx = mssg.indexOf("-");
            int i = Integer.parseInt(mssg.substring(idx+1));
            DTura08CC.jCheckBox[i].setVisible(false);
            DTura08CC.jpRight.remove(DTura08CC.jCheckBox[i]);
            msg.append(mssg + '\n');
            return true;
        }
        else
            return false;
    }
    
    public boolean checkWelcome(String mssg){
        if(mssg.contains("////")){
            String name = "";
            String message = mssg.substring(4);
            for(int i=1; i<25; i++ ){
                if(!message.contains("//"))
                    break;
                int idx = message.indexOf("//");
                name = message.substring(0,idx);
                message = message.substring(idx+2);
                idx = name.indexOf("-");
                int k= Integer.parseInt(name.substring(idx+1));
                DTura08CC.jCheckBox[k].setText(name);
                DTura08CC.jCheckBox[k].setVisible(true);
                DTura08CC.jpRight.add(DTura08CC.jCheckBox[k]);
                if(DTura08CC.jCheckBox[0].isSelected()){
                    DTura08CC.jCheckBox[k].setSelected(true);
                    DTura08CC.jCheckBox[k].setEnabled(false);
                }
            }
            return true;
        }
        return false;
    }
}
