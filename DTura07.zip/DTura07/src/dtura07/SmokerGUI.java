/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author student
 */
public class SmokerGUI extends JFrame {

   public SmokerGUI () {
	getContentPane().add(p);
	setSize(600, 400);
	p.setBackground(Color.black);
	setTitle("Smoker Problem: Multithread & Synchronization");
	setVisible(true);
	g = (Graphics2D) p.getGraphics();
        g.setFont(new Font("Roman", Font.BOLD, 20));
	try { Thread.sleep(100); } catch(Exception e) {}
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setBackground(Color.black);
        g.setXORMode ( Color.green);
   }
}
