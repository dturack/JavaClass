/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

/**
 *
 * @author dturack
 */
class Philosophers extends Thread {
  static int	x[] = {100, 330, 650, 600, 140};
  static int	y[] = {320, 500, 320, 50, 50};
   int count = 0;
   int id;
   PhilosopherMonitor mtr;
   Graphics2D	g;
   JPanel p;
   int ing = -1;
   public Philosophers( int k, PhilosopherMonitor m, Graphics2D gr, JPanel pnl) { id = k; mtr = m; g = gr; p=pnl;}  

   @Override
   public void run() {
       

	while (true ) {
		PhilosopherUtil.simulate(g, id, "Thinking", 2000, 3000);
                //try {sleep(2000);} catch (Exception e) {}
                //System.out.printf("%d thinking\n", id);
		ing = mtr.get( id , x[id], y[id]+20);
                PhilosopherUtil.forksts[id] = 1;
                ing = mtr.get((id+1)%5, x[id]+40, y[id]+20);
                PhilosopherUtil.forksts[(id+1)%5] = 2;                
                System.out.printf("%d Eating\n", id+1);
		PhilosopherUtil.simulate(g, id, "Eating", 3000, 4000);
                //try {sleep(3000);} catch (Exception e) {}
                PhilosopherUtil.forksts[id] = 0;
                PhilosopherUtil.forksts[(id+1)%5] = 0;
                mtr.put2(id);                                
                //mtr.put((id+1)%5);                              
                count++;
                System.out.printf("%d Done Eating; Total: %d\n", id+1, count);
                for(int i=0;i<5;i++){
                    System.out.printf("Fork %d status: %d, ",i+1, PhilosopherUtil.forksts[i]);
                }
                System.out.printf("\n");

                
                
                //p.repaint();
                PhilosopherUtil.setImages(g);
                //SmokerUtil.simulate(g, id, "Thinking", 3000, 4000);
	}
   }
}
