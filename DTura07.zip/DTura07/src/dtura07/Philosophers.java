package dtura07;

import java.awt.*;

/**
 *
 * @author dturack
 */
class Philosophers extends Thread {
   int count = 0;
   int id;
   PhilosopherMonitor mtr;
   Graphics2D	g;
   int ing = -1;
   public Philosophers( int k, PhilosopherMonitor m, Graphics2D gr) { id = k; mtr = m; g = gr;}  

   @Override
   public void run() {
       

	while (true ) {
		PhilosopherUtil.simulate(g, id, "Thinking", 2000, 3000);
		ing = mtr.get( id , id);
                ing = mtr.get((id+1)%5, id);
		PhilosopherUtil.simulate(g, id, "Eating", 3000, 4000);
                mtr.put2(id);//special function created to return both forks to table when finished eating                             
                count++;
                System.out.printf("%d Done Eating; Total: %d\n", id+1, count);
                PhilosopherUtil.setImages(g);
	}
   }
}
