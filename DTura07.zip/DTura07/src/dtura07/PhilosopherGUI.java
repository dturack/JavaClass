/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author student
 */
public class PhilosopherGUI extends JFrame {
   JPanel p = new JPanel();
   Graphics2D g;
   Graphics2D g2;
   
   public PhilosopherGUI () {
	getContentPane().add(p);
	setSize(850, 700);
	p.setBackground(Color.darkGray);
	setTitle("Dining Philosopher Problem: Multithread & Synchronization");
	setVisible(true);
	g = (Graphics2D) p.getGraphics();
        g.setFont(new Font("Roman", Font.BOLD, 18));
	try { Thread.sleep(100); } catch(Exception e) {}
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setBackground(Color.darkGray);
        PhilosopherUtil.setImages(g);
        //g.setXORMode ( Color.green);
   }
}
