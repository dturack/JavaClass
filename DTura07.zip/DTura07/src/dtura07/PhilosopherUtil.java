/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.*;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 *
 * @author student
 */
public class PhilosopherUtil extends Component{
  static int	x[] = {100, 330, 650, 600, 140};
  static int	y[] = {320, 500, 320, 50, 50};
  static int	x2[] = {150, 160, 380, 340, 250};
  static int	y2[] = {150, 275, 275, 150, 70};
  static int    forksts[] = {0,0,0,0,0};
  static int	labelX = 250, labelY = 210;
  static String ingredient[] = {"F1", "F2", "F3", "F4", "F5", "Agent" };
  static Color  color[] = { Color.pink, Color.yellow, Color.blue, Color.red, Color.orange, Color.orange};
  static boolean printTitle[] = { true, true, true, true, true, true };
  static Random rnd = new Random();
  static BufferedImage [] phil = {null,null,null,null,null};
  static BufferedImage fork = null;
  static BufferedImage table = null;
  static RescaleOp rop = null;
  
  synchronized static void setImages(Graphics2D g){
      try {
          phil[0] = ImageIO.read(new File("src/dtura07/hWang1.jpg"));
          phil[1] = ImageIO.read(new File("src/dtura07/Lei_single.jpg"));
          phil[2] = ImageIO.read(new File("src/dtura07/derrick.jpg"));
          phil[3] = ImageIO.read(new File("src/dtura07/gordon1.png"));
          phil[4] = ImageIO.read(new File("src/dtura07/melissa.jpg"));          
          table = ImageIO.read(new File("src/dtura07/Table.png"));
          fork = ImageIO.read(new File("src/dtura07/fork1.png"));
      }catch (IOException e) {}
      g.drawImage(table, 230, 100, null);
      for(int i=0; i<5; i++){
          String title = "Phil0"+ (i+1);
            g.setColor( color[i] );
            g.drawImage(phil[i], x[i]-5, y[i]-20, null);
            g.drawString( title , x[i]+10, y[i] + 115);
	}
  }
          

  synchronized static void simulate (Graphics2D g, int k, String msg, int lb, int ub ) {
	//String title = "Phil0"+ (k+1);
	g.setColor( color[k] );
	/*if ( printTitle[k] ) {
                g.drawImage(phil[k], x[k]-5, y[k]-20, null);
		g.drawString( title , x[k]+10, y[k] + 115);
		printTitle[k] = ! printTitle[k];
	}*/
	g.clearRect(x[k], y[k] +120, 120, 20);
	g.drawString( msg, x[k], y[k]+135 );
        try { Thread.sleep( rnd.nextInt( ub - lb + 1) + lb ); }
	catch (Exception e) {}
        
  }

  synchronized static void moveToTable(Graphics2D g, int ing) {
	//g.clearRect(x[ing], y[ing] + 131, 120, 20);
        //g.setColor(color[ing]);
        //g.drawString(ingredient[ing], x2[ing], y2[ing]);
        //g.drawImage(table, 230, 100, null);
        
        g.drawImage(fork, x2[ing], y2[ing], null);

	//move(g, ing, x1, y1, x2[ing], y2[ing], true, false);
        //g.clearRect(x, y, ing, ing);
  }
  
  synchronized static void moveFromTable(Graphics2D g, int smkr, int x1, int y1) {
        //g.clearRect(x2[smkr], y2[smkr]+135,40,20);
        //g.setColor(color[smkr]);
        //g.drawString(ingredient[smkr], x1, y1);
        //g.drawImage(table, 230, 100, null);
        
        g.drawImage(fork, x1, y1, null);

        //move(g, smkr, x2[smkr], y2[smkr], x[smkr], y[smkr],  smkr % 4 == 1, true);
  }
  
  static void move(Graphics2D g, int ing, int x1, int y1, int x2, int y2, boolean vertical, boolean clearSMKMsg ){
	int u, u1, u2, v, v1, v2, inc;
	float k;
	
	u1 = vertical? y1 : x1;
	u2 = vertical? y2 : x2;
	v1 = vertical? x1 : y1;
	v2 = vertical? x2 : y2;
	k =  (v2 - v1 ) / ((float) u2 - u1);
	inc = u1 <= u2 ? 1 : -1 ; 
	g.setColor(color[ing]);
	try { Thread.sleep( 10 ); } catch (Exception e) {}
	u = u1;
	v = v1;		
	if ( vertical)
		g.drawString(ingredient[ing], v, u);
	else
		g.drawString(ingredient[ing], u, v );
	for ( ; u != u2; u = u + inc ) {
		if ( vertical)
			g.drawString(ingredient[ing], v, u);
		else
			g.drawString(ingredient[ing], u, v);
		v = (int) (k * (u - u1) + v1);
		try { Thread.sleep( 10 ); } catch (Exception e) {}
		if ( vertical)
			g.drawString(ingredient[ing], v, u);
		else
			g.drawString(ingredient[ing], u, v);
	}
	if (clearSMKMsg) g.clearRect(x[ing], y[ing] - 16, 120, 20);
	if ( vertical)
		g.drawString(ingredient[ing], v, u);
	else
		g.drawString(ingredient[ing], u, v);
  }
}
