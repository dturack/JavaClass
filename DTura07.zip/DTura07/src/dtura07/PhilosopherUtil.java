package dtura07;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Random;
import javax.imageio.ImageIO;

/**
 *
 * @author dturack
 */
public class PhilosopherUtil extends Component{
  static int	x[] = {100, 370, 650, 600, 140};
  static int	y[] = {320, 485, 320, 50, 50};
  static int	x2[] = {260, 300, 430, 460, 400};//x and y values for placement of forks
  static int	y2[] = {185, 320, 320, 180, 120};
  static int    forksts[] = {0,0,0,0,0};//array to keep track of the status of each fork: 0 - available, 1 - phil with same number is using, 2 - previous numbered phil using
  static String status[] = {"Thinking", "Thinking", "Thinking", "Thinking", "Thinking"};
  static Color  color[] = { Color.green, Color.yellow, Color.blue, Color.red, Color.orange};
  static Random rnd = new Random();
  static BufferedImage [] phil = {null,null,null,null,null};
  static BufferedImage [] fork = {null,null,null,null,null,null};
  static BufferedImage forksp = null;
  static BufferedImage table = null;
  static AffineTransform trans = new AffineTransform();
  
  static void initImages(Graphics2D g){
      try {
          phil[0] = ImageIO.read(new File("src/dtura07/hWang1.jpg"));
          phil[1] = ImageIO.read(new File("src/dtura07/Lei_single.jpg"));
          phil[2] = ImageIO.read(new File("src/dtura07/derrick.jpg"));
          phil[3] = ImageIO.read(new File("src/dtura07/gordon1.png"));
          phil[4] = ImageIO.read(new File("src/dtura07/melissa.jpg"));          
          table = ImageIO.read(new File("src/dtura07/Table.png"));
          fork[0] = ImageIO.read(new File("src/dtura07/fork1.png"));
          fork[1] = ImageIO.read(new File("src/dtura07/fork2.png"));
          fork[2] = ImageIO.read(new File("src/dtura07/fork3.png"));
          fork[3] = ImageIO.read(new File("src/dtura07/fork4.png"));
          fork[4] = ImageIO.read(new File("src/dtura07/fork5.png"));
          fork[5] = ImageIO.read(new File("src/dtura07/fork6.png"));
          forksp = ImageIO.read(new File("src/dtura07/spfork.png"));
      }catch (IOException e) {}
  }
  
  synchronized static void setImages(Graphics2D g){
      g.clearRect(0, 0, 850, 700);
      g.drawImage(table, 230, 100, null);
      for(int i=0; i<5; i++){
          String title = "Phil0"+ (i+1);
            g.setColor( color[i] );
            g.drawImage(phil[i], x[i]-5, y[i]-20, null);
            g.drawString( title , x[i]+10, y[i] + 115);
      }
      for(int k=0; k<5; k++){
            switch(forksts[k]){
                case 0:
                    g.drawImage(fork[k], x2[k], y2[k], null);
                    status[k] = "Thinking";
                    statusUpdate(g);
                    break;
                case 1:
                    if(forksts[(k+1)%5]!=2){
                        g.drawImage(fork[5], x[k], y[k]+140, null);
                        status[k] = "Waiting";
                        statusUpdate(g);
                    }
                    else{
                        g.drawImage(forksp, x[k]+30, y[k]+50, null);
                        statusUpdate(g);
                    }
                    break;
                case 2:
                    if(forksts[(k+4)%5]!=1){
                        g.drawImage(fork[5], x[k], y[k]+140, null);
                        statusUpdate(g);
                    }
                    else{
                        g.drawImage(forksp, x[(k+4)%5]-25+forksp.getWidth(), y[(k+4)%5]+50,-forksp.getWidth(),forksp.getHeight(), null);
                        status[(k+4)%5] = "Eating";
                        statusUpdate(g);
                    }
                    break;
                default:
                    System.out.printf("Error invalid selection for %d\n", k);
                    break;
            }
	}
  }
  
  static void statusUpdate(Graphics2D g){
      for(int k=0; k<5;k++){
        g.setColor( color[k] );
        g.clearRect(x[k], y[k] +120, 80, 20);
        g.drawString( status[k], x[k], y[k]+135 );
      }
  }
          

  synchronized static void simulate (Graphics2D g, int k, String msg, int lb, int ub ) {
        status[k] = msg;
        setImages(g);
        try { Thread.sleep( rnd.nextInt( ub - lb + 1) + lb ); }
	catch (Exception e) {}   
  }

  synchronized static void moveToTable(Graphics2D g, int phil, int fork) {
        forksts[fork] = 0;
        setImages(g);
        try{Thread.sleep(10);}catch(Exception e){}
  }
  
  synchronized static void moveFromTable(Graphics2D g, int phil, int fork) {
      //check if fork is 1st or 2nd fork
        if(phil==fork){
            forksts[fork] = 1;
            setImages(g);
            try{Thread.sleep(100);}catch(Exception e){}
        }
        else{
            forksts[fork] = 2;
            setImages(g);
            try { Thread.sleep( rnd.nextInt( 1001 ) + 2500 ); }//Random amount of time to eat
            catch (Exception e) {}
        }
  }
}
