package dtura07;
import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 *
 * @author student
 */
public class DTura07 extends JFrame {
    JPanel p = new JPanel();
    Graphics2D g;
  static int	x2[] = {100, 160, 380, 340, 250, 250};
  static int	y2[] = {150, 275, 275, 150, 70, 50};
    public static Random rnd = new Random();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      SmokerGUI app = new SmokerGUI();
      SmokerMonitor mtr = new SmokerMonitor( app.g ) ;
      for( int i = 0; i < 5; i ++ ){
          new Smoker(i, mtr, app.g ).start();
          new Fork(i);
      }
      for(int i=0; i<5; i++)
          mtr.put(i);
      
      //new Agent(5, mtr, app.g).start();
    }  
}





