package dtura07;
import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 *
 * @author student
 */
public class DTura07 extends JFrame {
    JPanel p = new JPanel();
    Graphics2D g;
    public static Random rnd = new Random();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      SmokerGUI app = new SmokerGUI();
      SmokerMonitor mtr = new SmokerMonitor( app.g ) ;
      SmokerUtil.setImages(app.g);
      for( int i = 0; i < 5; i ++ ){
          new Smoker(i, mtr, app.g, app.p ).start();
      }
      for(int i=0; i<5; i++)
          mtr.put(i);
      //new Agent(5, mtr, app.g).start();
    }  
}





