package dtura07;
import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 *
 * @author dturack
 */
public class DTura07 extends JFrame {
    JPanel p = new JPanel();
    Graphics2D g;
    public static Random rnd = new Random();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      PhilosopherGUI app = new PhilosopherGUI();
      PhilosopherMonitor mtr = new PhilosopherMonitor( app.g ) ;
      //PhilosopherUtil.setImages(app.g);
      for( int i = 0; i < 5; i ++ ){
          new Philosophers(i, mtr, app.g, app.p ).start();
      }
      for(int i=0; i<5; i++)
          PhilosopherUtil.moveToTable(app.g, i);
      //new Agent(5, mtr, app.g).start();
    }  
}





