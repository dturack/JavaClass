package dtura07;
import javax.swing.*;
import java.util.Random;

/**
 *
 * @author dturack
 */
public class DTura07 extends JFrame {
    static PhilosopherGUI app;
    public static Random rnd = new Random();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      app = new PhilosopherGUI();
      PhilosopherMonitor mtr = new PhilosopherMonitor( app.g ) ;
      PhilosopherUtil.initImages(app.g);
      PhilosopherUtil.setImages(app.g);
      for( int i = 0; i < 5; i ++ ){
          new Philosophers(i, mtr, app.g).start();
      }      
    }  
}





