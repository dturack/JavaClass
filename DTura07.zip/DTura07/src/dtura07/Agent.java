/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.Graphics2D;
import java.util.Random;

/**
 *
 * @author student
 */
class Agent extends Thread {
   int id;
   SmokerMonitor mtr;
   Graphics2D g;
   static Random rnd = new Random();

   public Agent( int k, SmokerMonitor m, Graphics2D gr ) { id = k; mtr = m; g = gr;}  

   @Override
   public void run() {
	int ing;
        for(int i=0; i<5; i++){
            mtr.put(i, 250, 50);
        }
	/*while (true ) {
		SmokerUtil.simulate(g, id, "Making", 1000, 2000);
		ing = rnd.nextInt(5);
		mtr.put( ing );
		SmokerUtil.simulate(g, id, "Relaxing", 1000, 2000);
	}*/
   }
}
