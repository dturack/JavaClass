/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.*;

/**
 *
 * @author student
 */
public class SmokerMonitor {
  int [] available = {-1,-1,-1,-1,-1};
  Graphics2D g = null;
  static int	x[] = {100, 330, 650, 600, 140};
  static int	y[] = {320, 500, 320, 50, 50};

  public SmokerMonitor( Graphics2D gr ) { g = gr; }

  synchronized public int get( int fork, int x1, int y1) {
	while ( available[fork] != fork) {
		notify();
		SmokerUtil.simulate(g, fork, "Waiting", 100, 200);
		try { wait(5000); } catch (Exception e) {}
                if(x[fork]!=x1 && available[fork] != fork){
                    put((fork+3)%5); //returns held fork to table if waiting too long
                    return (fork+3)%5;
                }
	}

	int ing = available[fork];
	available[fork] = -1;
	SmokerUtil.moveFromTable(g, fork, x1, y1);
	notify();
	return fork;
  }

  synchronized public void put( int ing) {
	/*while ( available[ing] >= 0  ) {
		notifyAll();
		SmokerUtil.simulate(g, 5, "Waiting", 400, 1000);
		try { wait(); } catch (Exception e) {}
	}*/

	// SmokerUtil.simulate(g, 3, SmokerUtil.ingredient[ing], 400, 1000); 
	available[ing] = ing ;
	SmokerUtil.moveToTable(g, ing);
	notify();
  }
}
