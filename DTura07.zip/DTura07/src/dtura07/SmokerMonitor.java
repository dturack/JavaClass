/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.Graphics2D;

/**
 *
 * @author student
 */
public class SmokerMonitor {
  int [] available = {-1,-1,-1,-1,-1};
  Graphics2D g = null;

  public SmokerMonitor( Graphics2D gr ) { g = gr; }

  synchronized public int get( int fork ) {
	while ( available[fork] != fork) {
		notifyAll();
		SmokerUtil.simulate(g, fork, "Waiting", 400, 1000);
		try { wait(); } catch (Exception e) {}
	}

	int ing = available[fork];
	available[fork] = -1 ;
	SmokerUtil.moveFromTable(g, fork);
	notifyAll();
	return fork;
  }

  synchronized public void put( int ing, int x, int y) {
	/*while ( available[ing] >= 0  ) {
		notifyAll();
		SmokerUtil.simulate(g, 5, "Waiting", 400, 1000);
		try { wait(); } catch (Exception e) {}
	}*/

	// SmokerUtil.simulate(g, 3, SmokerUtil.ingredient[ing], 400, 1000); 
	available[ing] = ing ;
	SmokerUtil.moveToTable(g, ing, x, y);
	notifyAll();
  }
}
