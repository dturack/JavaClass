package dtura07;

import java.awt.*;

/**
 *
 * @author dturack
 */
public class PhilosopherMonitor {
  Graphics2D g = null;

  public PhilosopherMonitor( Graphics2D gr ) { g = gr; }

  synchronized public int get( int fork, int phil) {
      if(phil!=fork && PhilosopherUtil.forksts[phil]!=1)
          return phil;
	while ( PhilosopherUtil.forksts[fork] != 0) {
		notifyAll();
		PhilosopherUtil.simulate(g, fork, "Waiting", 100, 200);
		try { wait(10000); } catch (Exception e) {}
                if(fork!=phil && PhilosopherUtil.forksts[fork] != 0){
                    put((fork+4)%5); //returns held fork to table if waiting too long
                    return (fork+4)%5;
                }
	}
        if(fork!=phil)
            PhilosopherUtil.moveFromTable(g, (fork+4)%5, fork);
        else
            PhilosopherUtil.moveFromTable(g, fork, fork);
        try{Thread.sleep(10);}catch(Exception e){}
	notifyAll();
	return fork;
  }

  synchronized public void put( int ing) {
	PhilosopherUtil.moveToTable(g, ing, ing);    
	notifyAll();
  }
  synchronized public void put2(int ing) {
	PhilosopherUtil.moveToTable(g, ing, (ing+1)%5);
        try{Thread.sleep(10);}catch(Exception e){}
	PhilosopherUtil.moveToTable(g, ing,ing);        
	notifyAll();
  }
}
