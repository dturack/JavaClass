/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.*;

/**
 *
 * @author student
 */
public class PhilosopherMonitor {
  int [] available = {0,1,2,3,4};
  Graphics2D g = null;
  static int	x[] = {100, 330, 650, 600, 140};
  static int	y[] = {320, 500, 320, 50, 50};

  public PhilosopherMonitor( Graphics2D gr ) { g = gr; }

  synchronized public int get( int fork, int x1, int y1) {
	while ( available[fork] != fork) {
		notifyAll();
		PhilosopherUtil.simulate(g, fork, "Waiting", 100, 200);
                //System.out.printf("%d waiting on fork\n", fork);
		try { wait(5000); } catch (Exception e) {}
                if(x[fork]!=x1 && available[fork] != fork){
                    //System.out.printf("Wait timeout for fork %d\n", fork);
                    put((fork+5)%5); //returns held fork to table if waiting too long
                    return (fork+5)%5;
                }
	}
	PhilosopherUtil.moveFromTable(g, fork, x1, y1);
	int ing = available[fork];
	available[fork] = -1;
        try{Thread.sleep(10);}catch(Exception e){}
	notifyAll();
	return fork;
  }

  synchronized public void put( int ing) {
	/*while ( available[ing] >= 0  ) {
		notifyAll();
		PhilosopherUtil.simulate(g, 5, "Waiting", 400, 1000);
		try { wait(); } catch (Exception e) {}
	}*/

	// PhilosopherUtil.simulate(g, 3, PhilosopherUtil.ingredient[ing], 400, 1000); 
	available[ing] = ing ;
	PhilosopherUtil.moveToTable(g, ing);
        //available[(ing+1)%5] = (ing+1)%5;
	//PhilosopherUtil.moveToTable(g, (ing+1)%5);        
	notifyAll();
  }
  synchronized public void put2(int ing) {
      	available[ing] = ing ;
	PhilosopherUtil.moveToTable(g, ing);
        available[(ing+1)%5] = (ing+1)%5;
	PhilosopherUtil.moveToTable(g, (ing+1)%5);        
	notifyAll();
  }
}
