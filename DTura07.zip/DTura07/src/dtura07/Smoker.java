/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
class Smoker extends Thread {
   static int	x[] = {60, 250, 420, 380, 80, 250};
   static int	y[] = {210, 350, 210, 50, 50, 50};
   int id;
   SmokerMonitor mtr;
   Graphics2D	g;
   int ing = -1;
   public Smoker( int k, SmokerMonitor m, Graphics2D gr) { id = k; mtr = m; g = gr;}  

   @Override
   public void run() {

	while (true ) {
		SmokerUtil.simulate(g, id, "Waiting", 1000, 2000);
		ing = mtr.get( id );
                ing = mtr.get((id+1)%5);
		SmokerUtil.simulate(g, id, "Eating", 1000, 2000);
            try {sleep(10);} catch (InterruptedException ex) {}
                mtr.put(id, x[id], y[id]);
                mtr.put((id+1)%5, x[id], y[id]);
                SmokerUtil.simulate(g, id, "Thinking", 1000, 2000);
            try {sleep(10);} catch (InterruptedException ex) {}
	}
   }
}
