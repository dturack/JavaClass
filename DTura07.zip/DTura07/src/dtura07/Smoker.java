/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura07;

import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
class Smoker extends Thread {
   static int	x[] = {60, 250, 420, 380, 80, 250};
   static int	y[] = {210, 330, 210, 50, 50, 50};
   int id;
   SmokerMonitor mtr;
   Graphics2D	g;
   int ing = -1;
   public Smoker( int k, SmokerMonitor m, Graphics2D gr) { id = k; mtr = m; g = gr;}  

   @Override
   public void run() {

	while (true ) {
		SmokerUtil.simulate(g, id, "Thinking", 2000, 4000);
		ing = mtr.get( id , x[id], y[id]+20);
                ing = mtr.get((id+1)%5, x[id]+40, y[id]+20);
		SmokerUtil.simulate(g, id, "Eating", 3000, 4000);
                mtr.put(id);
                mtr.put((id+1)%5);
                //SmokerUtil.simulate(g, id, "Thinking", 3000, 4000);
	}
   }
}
