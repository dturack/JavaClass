/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smoker;

/**
 *
 * @author student
 */
public class Smoker {
    public interface smokerConst{
        int paper = 0;
        int tobacco = 1;
        int match = 2;
    }
    
    String items[] = {"Paper","Tobacco","Match"};
    
    static int ID;
    static SAMonitor smtr; 
    public Smoker(int i, SAMonitor sam){
        ID = i; smtr = sam;
    }
    
}
