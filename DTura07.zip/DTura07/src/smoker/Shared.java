/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smoker;
import java.util.Random;

/**
 *
 * @author student
 */
enum Smokers{ PAPER, MATCH, TABACOO};

public class Shared {
    public static Random rnd = new Random();
    public static void simulate(String msg, int lbSecs, int ubSecs){
        try {
            Thread.sleep((ubSecs * 1000 - lbSecs * 1000 +1) + lbSecs * 1000);
        } catch (Exception e) {}
    }
}
