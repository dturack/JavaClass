/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smoker;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */

public class SAMonitor {
    private int table = -1; //if -1 empty, if 0 paper, if 1 tabacoo, if 2 match
    
    public boolean empty(){return table == -1;}
    
    synchronized public void put(int item){
        while(!empty()){
            notifyAll();
            try {
                wait();//wait for empty table
                System.out.printf("Item %d waiting in the put queue",item);
            } catch (InterruptedException ex) {
                Logger.getLogger(SAMonitor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        table = item;
        notifyAll();
    }
    
    synchronized public int get(int item){
        while(table!=item){
            notifyAll();
            try {
                wait();
                System.out.printf("Item %d waiting in the get queue",item);
            } catch (InterruptedException ex) {
                Logger.getLogger(SAMonitor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        int i = table;
        table = -1;
        notifyAll();
        return i;
    }
}
