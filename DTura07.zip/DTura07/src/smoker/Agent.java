/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smoker;

/**
 *
 * @author student
 */


public class Agent implements Runnable {
    
    static SAMonitor smtr = null;
    
    public Agent(SAMonitor sam){
        smtr = sam;
    }
    
    
    public void run(){
        int kind = -1;
        
        while(true){
            Shared.simulate("Making ingredient " + Shared.component(kind), 3, 4);
            kind = Shared.rnd.nextInt(3);
            Shared.simulate("Agent: Mode a " + Shared.component(kind), 1, 3);
            smtr.put(kind);
            Shared.simulate("Agent: Relax ... ", 1, 3);
        }
    }
}
