package smoker;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */

public class DTura07 {

    static SAMonitor mtr = new SAMonitor();
    static Thread agent = null;
    static Thread smkr[] = new Thread[3];

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        agent = new Thread( new Agent (mtr));
        agent.start();
        for(int i=0; i<3; i++){
            smkr[i] = new Thread(new Smoker(i, mtr));
            smkr[i].start();
        }
    }
    
}
