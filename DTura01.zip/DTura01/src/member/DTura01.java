
package member;
import java.util.*;
import java.awt.Desktop;
import java.io.*;
//import java.nio.file.*;
//import java.lang.Object;

/**
 *
 * @author Daniel Turack
 */
public class DTura01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        System.out.printf("Enter H/h/? for help, or command : ");
        String selc = input.next();
        
        while (!"E".equals(selc) && !"e".equals(selc)){
            switch(selc){
                case "H": case "h": case "?":
                    System.out.printf("%s\n", MemberConst.menu); break;
                case "G": case "g":
                    System.out.printf("Enter number of Members: ");
                    makeMembers(input.nextInt()); break;
                case "S": case "s":
                    sortMembers(); break;
                case "V": case "v":
                    show(); break;
                case "O": case "o":
                    save("hw01.html", memVector); break;
                case "F": case "f":
                    showContents("hw01.html"); break;
                case "L": case "l":
                    showHTMLFile("hw01.html"); break;
            }
            System.out.printf("Enter H/h/? for help, or command : ");
            selc = input.next();
        }
    }

    public static Vector<Member> memVector = new Vector<Member>();
    public static ArrayList<Member> arrMember = new ArrayList<Member>();
    /**
     *
     * @param filename
     */
    public static void showHTMLFile(String filename) {
        if(Desktop.isDesktopSupported()){
            try{
                File ofile = new File(filename);
                Desktop.getDesktop().browse(ofile.toURI());
            } catch ( Exception e ) {}
        }
        System.out.printf("HTML page loaded sucessfully \n");
    }
    
    public static void showContents (String filename) throws IOException {
        try {
        FileInputStream fis = new FileInputStream(filename);
        ObjectInputStream ois = new ObjectInputStream(fis);
        System.out.printf("Contents of HTML file: \n");
        while (fis.available()>0){
            System.out.printf("%s \n", (String)ois.readObject());
        }
        ois.close();
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        System.out.printf("\n");
    }   
        
    
    public static void sortMembers() {
        Collections.sort(arrMember);
        Collections.sort(memVector);
        System.out.printf("Array and Vector sorted sucessfully \n");
    }

    public static void show(){
        System.out.printf("From Vector: \n");
        for (int i=0; i<memVector.size(); i++){
            System.out.printf("%s \n", memVector.get(i).toString(true));
        }
        System.out.printf("\nFrom Array: \n");
        for (int k=0; k<arrMember.size(); k++) {
            System.out.printf("%s \n", arrMember.get(k).toString(true));
        }
    }
    /**
     *
     * @param count
     * 
     */
    public static void makeMembers(int count){
        Member mem = null;
        for(int k=0; k<count; k++){
            Random rdn=new Random();
            int pick = rdn.nextInt(5)+1;
            switch(pick){
                case 1:
                    mem = new Member(); break;
                case 2:
                    mem = new Employee(); break;
                case 3:
                    mem = new Student(); break;
                case 4:
                    mem = new Faculty(); break;
                case 5:
                    mem = new Staff(); break;
            }
            memVector.add(k, mem);
            arrMember.add(k, mem);
            //memVector.get(k).generate();
            //arrMember.get(k).generate();
        }
        System.out.printf("\n %d Members created \n", count);
    }

    public static void save (String filename, Vector<Member> memVector ) throws IOException {
        File file = new File(filename);
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        oos.writeObject(htmlStart());
        for (int i=0; i<memVector.size(); i++)
            oos.writeObject(memVector.get(i).htmlRow());
        oos.writeObject(htmlEnd());
        oos.flush();
        oos.close();
        System.out.printf("Data sucessfully saved to file \n");
    }
    
    public static String htmlStart() { 
        return String.format("<!DOCTYPE HTML><html><head><title>HTML DATA FROM JAVA</title> <meta charset=utf-8\">"
        +"<style>table,th,td {border: 1px solid black}</style>"
    +"</head><body><table><tr><th>Class</th><th>SSN</th><th>Firstname</th><th>Lastname</th><th>Year Hired</th>"
     + "<th>Department</th><th>Title/Position</th><th>GPA</th><th>Major</th><th>Sport</th></tr>");
    };
    
    public static String htmlEnd() {
        return String.format("</table></body></html>");
    };
    
}
