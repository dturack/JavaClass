package member;

import java.util.Random;

/**
 *
 * @author Daniel Turack
 */
public class Staff extends Employee {
    public Staff () {
    }
    protected String jobTitle;
    void generate() {
        super.generate();
        Random rdn=new Random(); 
        jobTitle = Names.title[rdn.nextInt(Names.title.length)];
        memClass = "STA";
    }   
    @Override
    public String htmlColumns() {
        return String.format("%s<td>%s</td><td></td><td></td><td></td>", super.htmlColumns(), jobTitle);
    }
    @Override
    public String toString(){
        return String.format("%15s %-15s", super.toString(), jobTitle);
    };
    @Override
    public String toString( boolean lab ){
        return lab ? "STA " + toString() : toString();
    };
    
}
