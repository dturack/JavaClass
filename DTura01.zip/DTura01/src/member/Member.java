
package member;

import java.util.Random;
/**
 *
 * @author Daniel Turack
 */
public class Member implements InterfaceComb {
    public Member () {        
    }
    protected String firstName, lastName, memClass;
    int ID;
    void generate() {
        Random rdn=new Random();
        ID = rdn.nextInt(999999999 - 100000000) + 100000000;//randomly generate ID number between 100000000 and 999999999
        firstName = Names.firstName[rdn.nextInt(Names.firstName.length)]; 
        lastName = Names.lastName[rdn.nextInt(Names.lastName.length)];
        memClass = "MEM";
    }

    @Override
    public String toString(){
        return String.format("%3.3s-%2.2s-%4.4s %15s %-15s", ID%100000000, ID%1000000, ID%10000, firstName, lastName);
    };
    public String toString( boolean lab ){
        return lab ? "MEM " + toString() : toString();
    };
    @Override
    public int compareTo(Member m) {return ID - m.ID; };
    public String htmlRow() { return String.format("<tr>%s</tr>", htmlColumns());};
    public String htmlColumns() {
        return String.format("<td>%s</td><td>%9d</td><td>%15s</td><td>%-15s</td>", memClass, ID, firstName, lastName);
    }
}
