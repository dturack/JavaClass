
package member;

import java.util.Random;

/**
 *
 * @author Daniel Turack
 */
public class Faculty extends Employee {
    public Faculty () {
    }
    protected String degreeHeld;
    void generate() {
        super.generate();
        Random rdn=new Random(); 
        degreeHeld = Names.degree[rdn.nextInt(Names.degree.length)];
        memClass = "FAC";
    }   
    @Override
    public String htmlColumns() {
        return String.format("%s<td>%s</td><td></td><td></td><td></td>", super.htmlColumns(), degreeHeld);
    }
    @Override
    public String toString(){
        return String.format("%15s %-5s", super.toString(), degreeHeld);
    };
    @Override
    public String toString( boolean lab ){
        return lab ? "FAC " + toString() : toString();
    };
}
