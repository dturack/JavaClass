
package member;
import java.util.Random;
/**
 *
 * @author Daniel Turack
 */
public class Employee extends Member {
    public Employee () {
    }
    protected String department; int yearHired;
    void generate() {
        super.generate();
        Random rdn=new Random(); 
        department = Names.department[rdn.nextInt(Names.department.length)];
        yearHired = rdn.nextInt(2017-1950) + 1950; //randomly generate year hired between 1950 and 2017
        memClass = "EMP";
    }   
    @Override
    public String htmlColumns() {
        return String.format("%s<td>%d</td><td>%s</td>", super.htmlColumns(), yearHired, department);
    }
    @Override
    public String toString(){
        return String.format("%15s %-15s %4d", super.toString(), department, yearHired);
    };
    @Override
    public String toString( boolean lab ){
        return lab ? "EMP " + toString() : toString();
    };
}
