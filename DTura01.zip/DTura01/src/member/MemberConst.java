package member;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public interface MemberConst {
    
	String menu = new StringBuilder(50).append("\t================ CS 394 Assignment 1 ===============\n")
		.append("\tG/g:   Ask for a N, and generate N members of mixed\n")
                .append("\t       Member class's objects, and store in a Vector \n")
		.append("\t       and a array Objects.\n\n")
		.append("\tS/s/ : Sort the members in the vector and array in\n")
                .append("\t       ascending order.\n\n")
		.append("\tV/v/ : Show the members in the vector and array .\n\n")
		.append("\tO/o/ : Save objects inside vector into a HTML file\n")
		.append("\t       with objects saved in the format of HTML\n")
		.append("\t       Table.\n")
		.append("\tF/f  : Show HTML file contents on screen.\n\n")
		.append("\tL/l  : Launch the default internet browser to\n")
		.append("\t       display the generated HTML file.\n")
		.append("\t--------------------------------------------------\n")
		.append("\tH/h/?: Display this menu.\n")
		.append("\tE/e  : Exit\n")
		.append("\t=================================================\n").toString();
}
