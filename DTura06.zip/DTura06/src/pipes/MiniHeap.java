/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pipes;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 * @param <T>
 */
public class MiniHeap<T extends Comparable> implements Runnable {
    int start, size;
    T arr[] = null;
    PipedOutputStream pOut;
    public MiniHeap(PipedOutputStream pOuts, T [] a, int str, int sz){
        start = str; size = sz; arr = a; pOut = pOuts;
    }
    
    public void sort(){
        ObjectOutputStream oOut = null;
        int originalSize = size;
        heapify();
        try{oOut = new ObjectOutputStream(pOut);}catch (IOException e){}
        while(size>0){
            swapVal(start, start+size-1);
            try{oOut.writeObject(arr[start+size-1]);oOut.flush();}catch (IOException e){}
            size--;
            heapDown(start);
        }
        size = originalSize;
    } 
    
    void heapDown(int parent){
        while(((parent-start)*2+1+start)<=start+size-1){
            int child = (parent-start)*2+1+start;
            if (child+1 < size+start && arr[child+1].compareTo(arr[child])< 0)
                child = child +1;
            if (child < size+start && arr[child].compareTo(arr[parent]) < 0){
                swapVal(parent, child);
                parent = child;
            }
            else
                return;
        }
    }

    void heapify(){
        for(int i = start+(size-2)/2; i>=start; i--){
            heapDown(i);
        }
    }    
    
    public void swapVal(int pos1, int pos2){
        T tmp = arr[pos1];
        arr[pos1] = arr[pos2];
        arr[pos2] = tmp;
    }
    
    @Override
    public void run(){
        sort();
    }
}
