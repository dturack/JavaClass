/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pipes;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 * @param <T>
 */
public class MiniHeap<T extends Comparable> implements Runnable {
    int start, size;
    T arr[] = null;
    PipedOutputStream pOut;
    public MiniHeap(PipedOutputStream pOuts, T [] a, int str, int sz){
        start = str; size = sz; arr = a; pOut = pOuts;
    }
    
    public void sort(){
        //ObjectOutputStream oOut = null;
        int originalSize = size;
        heapify();
        //try{oOut = new ObjectOutputStream(pOut);}catch (IOException e){}
        while(size>1){
            swapVal(start, start+size-1);
            //System.out.printf("%d, ", arr[size-1]);
            //try{oOut.writeObject(arr[size-1]);oOut.flush();}catch (IOException e){}
            size--;
            heapDown(start);
        }
        //System.out.printf("\n");
        size = originalSize;
        transfer();
    }
    
    public void transfer(){
        //ObjectOutputStream oOut = null;
        //try{oOut = new ObjectOutputStream(pOut);}catch (IOException e){}
        for(int i=size-1; i>=start; i--){
            System.out.printf("%d, ", arr[i]);
            //try{oOut.writeObject(arr[i]);oOut.flush();}catch (IOException e){}
        }
    }
    
	void heapDown( int parent ) {
	
		int bigChild = getBigChild( parent );
		if ( bigChild < 0 ) return ;
		if ( arr[bigChild].compareTo(arr[parent]) < 0 ) {
		    swapVal( parent, bigChild );
		    heapDown( bigChild );
		}
	}

        int getBigChild( int parent ) {
		int lChild =  (parent - start) * 2 + 1 + start, rChild = lChild +1 ;
		if ( outOfBound(lChild) ) return -1;
		if ( outOfBound(rChild) ) return lChild;
		return arr[lChild].compareTo(arr[rChild]) <= 0? lChild : rChild;
	}		

	
	boolean outOfBound( int idx ) {
		return idx >= start + size;
	}    
    
    /*void heapDown(int parent){
        while(((parent-start)*2+1+start)<=start+size-1){
            int child = (parent-start)*2+1+start;
            if (child+1 < size+start && arr[child+1].compareTo(arr[child])< 0)
                child = child +1;
            if (child < size+start && arr[child].compareTo(arr[parent]) < 0){
                swapVal(parent, child);
                parent = child;
            }
            else
                return;
        }
    }*/

    void heapify(){
        for(int i = start+(size-2)/2; i>=start; i--){
            heapDown(i);
        }
    }    
    
    public void swapVal(int pos1, int pos2){
        T tmp = arr[pos1];
        arr[pos1] = arr[pos2];
        arr[pos2] = tmp;
    }
    
    @Override
    public void run(){
        sort();
    }
}
