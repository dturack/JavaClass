package pipes;
/**
 *
 * @author dturack
 */
public interface PipeConst {
    
	String menu = new StringBuilder(50).append("============================ 3390 Assignment 6 ==========================\n" )
.append("|        Merge Sort with Multi Threads and Piped Input and Output          |\n" )
.append("============================================================================\n" )
.append("| Command  |                         Description                           |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   g/G    | Ask for an integer N >= 1,000,000, and generate a integer  N  |\n" )
.append("|          | array of N elements, and fill the array with N integers (int).|\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   c/C    | Display the contents of array, 10 integers per line,          |\n" )
.append("|          | and 20 lines per screen. After each screen, Q/q will stop     |\n" )
.append("|          | listing and RETURN without letter to contiune.                |\n" )
.append("|          | If it quits in the middle, display last 3 lines.              |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   s/S    |         Sort Array with multithreaded piped I/O algorithm     |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   f/F    |             Shuffle entire Array of Data                      |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("| e/E/q/Q  |                 Exit the project.                             |\n" )
.append("+----------+---------------------------------------------------------------+\n" )
.append("|   h/H/?  |                 Show this menu.                               |\n" )
.append("+----------+---------------------------------------------------------------+\n").toString();
}
