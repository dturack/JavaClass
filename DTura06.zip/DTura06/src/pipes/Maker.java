/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pipes;

import java.io.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */


public class Maker implements Runnable {
    char ch;
    int range;
    
    static Random rdn = new Random();
    StringBuffer buf = new StringBuffer(50);
    ObjectOutputStream oOut = null;
    ObjectInputStream oIn = null;
    
    public Maker (char st, int rng, PipedInputStream pIn, PipedOutputStream pOut){
        ch = st; range = rng;
        try{
            oIn = pIn != null ? new ObjectInputStream(pIn) : null;
            oOut = pOut != null ? new ObjectOutputStream( pOut ) : null;
        } catch (IOException e){}
    }
    
    @Override
    public void run() {
        while(true){
        int nOfC = rdn.nextInt(11)+20;
        for(int i=0; i<nOfC; i++){
            try {Thread.sleep(rdn.nextInt(501)+500);} 
            catch (InterruptedException ex) {}
            buf.append( (char) (ch + rdn.nextInt(range)));
        }
        Object obj = null;
        try{
        if (oIn != null)obj = oIn.readObject();
        buf.append('|').append(obj.toString());
        if(oOut != null) {
            oOut.writeObject(buf.toString());
            oOut.flush();
        } else System.out.printf("%s\n", buf.toString());
        } catch(Exception e) {e.printStackTrace();}
        }
    }
}
