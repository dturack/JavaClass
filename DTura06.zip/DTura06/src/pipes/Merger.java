package pipes;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dturack
 * @param <T>
 */
public class Merger <T extends Comparable> implements Runnable {
    
    PipedInputStream [] pIns = new PipedInputStream[2];
    PipedOutputStream pOut = null;
    T [] values = (T[]) new Integer[2];
    Integer [] b;
    
    public Merger (PipedInputStream p1, PipedInputStream p2, PipedOutputStream out, Integer[]a){
        pIns[0] = p1; pIns[1] = p2; pOut = out; b = a;
    }
    
    @Override
    public void run(){
        ObjectOutputStream out = null;
        ObjectInputStream oIn[] = new ObjectInputStream[2];
        int k = 0;

        try{
            if(pOut!=null){
                out = new ObjectOutputStream(pOut);
            }            
            oIn[0] = new ObjectInputStream(pIns[0]);
            oIn[1] = new ObjectInputStream(pIns[1]);
            values[0] = (T) oIn[0].readObject();
            values[1] = (T) oIn[1].readObject();           
        }catch(IOException e) {} catch (ClassNotFoundException ex) {
            Logger.getLogger(Merger.class.getName()).log(Level.SEVERE, null, ex);
        }
        int errorCount = 0;
        int t=0;
        while(true){
            try{
                if(values[0]!=null && values[1]!=null)
                    k = values[0].compareTo(values[1]) <= 0 ? 0 : 1;
                if(b!=null && t<b.length){
                    b[t] = (Integer) values[k];
                    t++;
                }
                else if(out!=null){
                    out.writeObject(values[k]);
                    out.flush();
                }
                values[k] = (T) oIn[k].readObject();
            }catch(IOException e) {
                k^=1;
                errorCount++;
                if(errorCount>=2)break;
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Merger.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }    
}
