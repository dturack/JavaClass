package pipes;

import java.io.*;

/**
 *
 * @author dturack
 * @param <T>
 */
public class Merger <T extends Comparable> implements Runnable {
    T [] src = null, dest = null;
    int start1, start2, size1, size2;
    Thread thr1 = null, thr2 = null;
    
    PipedInputStream [] pIns = new PipedInputStream[2];
    PipedOutputStream pOut = null;
    Integer [] values = new Integer[2];
    Integer [] b;
    
    public Merger (PipedInputStream p1, PipedInputStream p2, PipedOutputStream out, Integer[]a){
        pIns[0] = p1; pIns[1] = p2; pOut = out; b = a;
    }
    
    @Override
    public void run(){
        ObjectOutputStream out = null;
        ObjectInputStream oIn[] = new ObjectInputStream[2];
        int k = 0;
        try{
            out = new ObjectOutputStream(pOut);
            oIn[0] = new ObjectInputStream(pIns[0]);
            oIn[1] = new ObjectInputStream(pIns[1]);
            values[0] = oIn[0].readInt();
            values[1] = oIn[1].readInt();           
        }catch(IOException e) {}
        int errorCount = 0;
        boolean ck = false;
        int t=0;
        if(b!=null) ck = true;
        while(true){
            try{
            k = values[0].compareTo(values[1]) <= 0 ? 0 : 1;
            if(ck){
                b[t] = values[k];
                System.out.printf("Value: ", values[k]);
                t++;
            }
            else{
                out.writeObject(values[k]);
                out.flush();
            }
            values[k] = oIn[k].readInt();
            }catch(IOException e) {
                k = k+1%2;
                errorCount++;
                if(errorCount>2)break;
            }
        }
    }    
}
