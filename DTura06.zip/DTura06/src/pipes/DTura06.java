package pipes;

import java.io.*;
import static java.lang.Thread.sleep;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import static pipes.DTura06.pOuts;


/**
 *
 * @author student
 */
public class DTura06 {

    static Random rdn = new Random();
    static Scanner scan = new Scanner(System.in);
    static PipedOutputStream [] pOuts[] = new PipedOutputStream[6][];
    static PipedInputStream [] pIns[] = new PipedInputStream[6][];
    static Thread [] merger[] = new Thread[5][];
    static Thread sorter[] = new Thread[32];
    static Border bdrs[] = new Border[32];
    
    static Integer [] a, b;
    
    static int firstlevel = 5, lastlevel = 0, nSorters = 32, nInts = 32, pipeLevel = 6;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.printf("Enter H/h/? for help, or command : ");
        String selc = scan.next();
        
        while (!"E".equals(selc) && !"e".equals(selc) && !"Q".equals(selc) && !"q".equals(selc)){
            switch(selc){
                case "H": case "h": case "?":
                    System.out.printf("%s\n", PipeConst.menu); break;
                case "G": case "g":
                    askForSize(); fill(); break;
                case "S": case "s":
                    sortArray(); break;
                case "C": case "c":
                    show("Array", a); break;
                case "F": case "f":
                    shuffleData(); break;
                default:
                    System.out.printf("Error, please enter valid selection\n"); break;
            }
            System.out.printf("Enter H/h/? for help, or command : ");
            selc = scan.next();
        }
    }
    
    static void shuffleData(){
        if(a==null){
            System.out.printf("Error: Array not initialized\n");
            return;
        }
        Integer temp;
        int randm;
        for(int i=0; i<a.length; i++){
            randm = rdn.nextInt(a.length);
            temp = a[i];
            a[i] = a[randm];
            a[randm] = temp;
        }
    }
    
    static void sortArray(){
        if(a==null){
            System.out.printf("Error: Array not initialized\n");
            return;
        }
        setupPipes();
        createStartSorter();
        createStartMerger();
        try{merger[0][0].join();} catch(Exception e) {} 
    }
    
    static void fill(){
        a = new Integer[nInts];
        b = new Integer[nInts];
        int sz = nInts/nSorters;
        int strt = 0;
        for (int i=0; i<nSorters; i++){
            bdrs[i] = new Border(strt, sz);
            strt = strt+sz;
        }
        bdrs[nSorters-1].size = bdrs[nSorters-1].size + nInts%nSorters;
        for(int i=0; i<a.length; i++) a[i] = rdn.nextInt(nInts*25);
        System.out.printf("Array filled with %d integers\n", a.length);
    }
    
    static void setupPipes(){
        for(int i=firstlevel; i>=lastlevel; i--){
            pOuts[i] = new PipedOutputStream[(int)Math.pow(2,i)];
            pIns[i] = new PipedInputStream[(int) Math.pow(2,i)];
            for(int j=0; j<pOuts[i].length; j++){
                try{
                pOuts[i][j] = new PipedOutputStream();
                pIns[i][j] =  new PipedInputStream(pOuts[i][j]);
                } catch(IOException e) {}
            }
        }
    }
    
    static void askForSize(){
        int temp = 0;
        while(temp<32){
            System.out.printf("Please enter number of Integers >=32: ");
            temp = scan.nextInt();
        }
        nInts = temp;
    }
    
    static void createStartSorter(){
        for(int i=0; i<nSorters; i++){
            sorter[i] = new Thread (new MiniHeap<>(pOuts[pipeLevel-1][i], a, bdrs[i].start, bdrs[i].size));
            sorter[i].start();
        }
        System.out.printf("Sorters all started\n\n");
    }
    
    static void createStartMerger(){
        for(int lvl=firstlevel-1; lvl>=lastlevel; lvl--){
            merger[lvl] = new Thread[(int)Math.pow(2,lvl)];
            for(int col=0;col<merger[lvl].length;col++){
                if(lvl==lastlevel){
                    merger[lvl][col] = new Thread(new Merger(pIns[lvl+1][col*2],pIns[lvl+1][col*2+1], null, a));
                }
                else {
                    merger[lvl][col] = new Thread(new Merger(pIns[lvl+1][col*2],pIns[lvl+1][col*2+1], pOuts[lvl][col], null));
                }
                merger[lvl][col].start();
            }
        }
    }
    
    static void show( String title, Integer [] a ) {
        if(a==null){
            System.out.printf("Error: Array not initialized\n");
            return;
        }
        System.out.printf("\n\t\t====== %s ==========\n", title);
        int t=0, d=0;
        for ( int j = 0 ; j < a.length; j++ ){
            System.out.printf("%6d ", a[j]);
            t++;
            if(t==10){
                System.out.printf("\n");
                d++;
                t = 0;
            }

            if((d+1)%20==0){
               d++;
               System.out.printf("Enter q/Q to quit listing or RETURN to continue: ");
               String selc = scan.nextLine();
               if(selc.isEmpty())
                   continue;
               else if("q".equals(selc) || "Q".equals(selc))
                   break;
            }
        }
        System.out.printf("\n\n");	
    }    
    
}
