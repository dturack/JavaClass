package pipes;

import java.io.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import static pipes.DTura06.pOuts;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public class DTura06 {

    static Random rdn = new Random();
    static PipedOutputStream pOuts[] = new PipedOutputStream[3];
    static PipedInputStream pIns[] = new PipedInputStream[3];
    static Thread mkrs[] = new Thread[3];
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            
            pOuts[0] = new PipedOutputStream( );
            pOuts[1] = new PipedOutputStream( );
            pOuts[2] = null;
            pIns[0] = null;
            pIns[1] = new PipedInputStream();
            pIns[2] = new PipedInputStream();

            pOuts[0].connect(pIns[1]);
            pOuts[1].connect(pIns[2]);
            //pOuts[2] = null;
            
            //pIns[0] = null;
            
            mkrs[0] = new Thread( new Maker ('a', 26, null, pOuts[0] ));
            mkrs[1] = new Thread( new Maker ('0', 10, pIns[1], pOuts[1]));
            mkrs[2] = new Thread( new Maker ('B', 26, pIns[2], null ));
        } catch (IOException ex) {}
        
        for(int i=0; i<mkrs.length; i++){
            mkrs[i].start();
        }
    }
    
}
