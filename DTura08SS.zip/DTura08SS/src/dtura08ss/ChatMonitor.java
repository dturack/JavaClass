/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura08ss;

import java.io.ObjectOutputStream;
import java.util.Vector;

/**
 *
 * @author student
 */
class ChatMonitor {

    Vector<ObjectOutputStream> vecOuts = new Vector<ObjectOutputStream> ( );

    public void put( ObjectOutputStream out ) { vecOuts.add( out ); }
    public void broadcast( Object obj ) {
	try { 
	    for ( int i = 0; i < vecOuts.size(); i++ ) {
		vecOuts.get(i).writeObject( obj );
	    }
	} catch ( Exception e ) {}
    }

    public void remove ( ObjectOutputStream out ) { vecOuts.remove ( out ) ; }
}
