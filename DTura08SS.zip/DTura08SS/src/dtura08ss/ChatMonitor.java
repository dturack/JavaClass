package dtura08ss;

import java.io.ObjectOutputStream;
import java.util.Vector;

/**
 *
 * @author dturack
 */
class ChatMonitor {
    
    String [] usernames = new String[20];
    int [] userids = new int[20];
    int count = 0;

    Vector<ObjectOutputStream> vecOuts = new Vector<ObjectOutputStream> ( );

    public void put( ObjectOutputStream out ) { vecOuts.add( out ); }
    public void broadcast( Object obj, int id) {
        String msg = (String) obj;
        if(msg.contains("///")){
            addUser(msg, id);
            return;
        }
        msg = usernames[id-1]+": "+msg;
	try { 
	    for ( int i = 0; i < vecOuts.size(); i++ ) {
		vecOuts.get(i).writeObject( msg );
	    }
	} catch ( Exception e ) {}
    }
    
    public void addUser(String str, int id){
        userids[count] = id;
        usernames[count] = str.substring(3);
        count++;
        String allusers = "////";
        for(int k=0; k<count; k++){
            allusers = allusers+usernames[k]+"-"+userids[k]+"//";
        }
        str = "Welcome to the Chatroom "+usernames[count-1];
        try { 
	    for ( int i = 0; i < vecOuts.size(); i++ ) {
		vecOuts.get(i).writeObject( str );
                vecOuts.get(i).writeObject(allusers);
	    }
	} catch ( Exception e ) {}
    }

    public void remove ( ObjectOutputStream out ) { vecOuts.remove ( out ) ; }
}
