package dtura08ss;

import java.io.ObjectOutputStream;
import java.util.Vector;

/**
 *
 * @author dturack
 */
class ChatMonitor {
    
    String [] usernames = new String[25];
    int [] userids = new int[25];
    int count = 0;
    int [] privateMsg = new int[25];

    Vector<ObjectOutputStream> vecOuts = new Vector<ObjectOutputStream> ( );

    public void put( ObjectOutputStream out ) { vecOuts.add( out ); }
    public void broadcast( Object obj, int id) {
        String msg = (String) obj;
        int [] arr = new int[25];
        if(msg.contains("///")){
            addUser(msg, id);
            return;
        }
        else if(!msg.contains("/:/all/:/")){
            msg = msg.substring(3);
            int idx = msg.indexOf("/:/");
            String users = msg.substring(0,idx);
            msg = msg.substring(idx+3);
            int i = 0;
            String names = "";
            for( ; users.contains(",");i++){
                idx = users.indexOf(",");
                arr[i] = Integer.parseInt(users.substring(0,idx));
                users = users.substring(idx+1);
                names = names+usernames[arr[i]-1]+", ";
            }
            msg = usernames[id-1]+": "+msg+"     Private for users: "+names;

            try { 
                for(int k=0; k<i; k++){
                    vecOuts.get(arr[k]-1).writeObject( msg );
                }
            } catch ( Exception e ) {}
        }
        else{
            msg = msg.substring(9);
            msg = usernames[id-1]+": "+msg;
            try { 
                for ( int i = 0; i < vecOuts.size(); i++ ) {
                    vecOuts.get(i).writeObject( msg );
                }
            } catch ( Exception e ) {}
        }
    }
    
    public void addUser(String str, int id){
        userids[count] = id;
        usernames[count] = str.substring(3)+"-"+id;
        count++;
        String allusers = "////";
        for(int k=0; k<count; k++){
            if(usernames[k]==null)
                continue;
            allusers = allusers+usernames[k]+"//";
        }
        str = "Welcome to the Chatroom "+usernames[count-1];
        try { 
	    for ( int i = 0; i < vecOuts.size(); i++ ) {
                vecOuts.get(i).writeObject(allusers);                
		vecOuts.get(i).writeObject( str );
	    }
	} catch ( Exception e ) {}
    }

    public void remove ( ObjectOutputStream out , int id) {
 
        try { 
            for ( int i = 0; i < vecOuts.size(); i++ ) {
                vecOuts.get(i).writeObject( "Goodbye "+usernames[id-1]+"/?/" );
            }
        } catch ( Exception e ) {}
        usernames[id-1] = null;
        vecOuts.remove ( out ) ;
    }
}
