package dtura08ss;

/**
 *
 * @author student
 */
import java.net.*;
import java.io.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DTura08SS {

    static int portNo = 9901;
    static int clientNO = 0;

    public static void main ( String args[] ) {
	ServerSocket ssk = null;
	Socket 	     sk  = null;
	try { ssk = new ServerSocket ( portNo);
	} catch (Exception e ) { e.printStackTrace() ; }

	ChatMonitor chatMtr = new ChatMonitor();

	Thread th = null;
	while ( true )  {
	    try {
		sk = ssk.accept();
		System.out.printf("\n\t\tClient %d is connected.", ++clientNO );
		th = new Thread ( new SAgent ( clientNO,  sk, chatMtr ) );
		th.start();

	    } catch ( Exception e) { e.printStackTrace(); return; }
            try {
                if(!sk.getInetAddress().isReachable(1000)){
                    System.out.printf("\n\t\tClient %d has disconnected.", clientNO);
                }
            } catch (IOException ex) {
                Logger.getLogger(DTura08SS.class.getName()).log(Level.SEVERE, null, ex);
            }
	}
    }
}   


