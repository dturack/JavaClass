package dtura08ss;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 *
 * @author dturack
 */
class SAgent implements Runnable {
    Socket sk = null;
    int    cID;
    ChatMonitor  mtr =  null;
    ObjectInputStream   in = null;
    ObjectOutputStream out = null;

    public SAgent (int clientID,  Socket sk, ChatMonitor mtr ) {
	cID = clientID; this.sk = sk; this.mtr = mtr;

	try {
	    out = new ObjectOutputStream( sk.getOutputStream() );
	    in  = new ObjectInputStream (sk.getInputStream( ) );
	    mtr.put( out );
	} catch ( IOException e ) { e.printStackTrace(); }

    }

    public void run() {
	Object obj = null;
	try {
	    while ( true ) {
		obj = in.readObject();
                if(obj == "/;/"){
                    mtr.remove(out, cID);
                    break;
                }
		mtr.broadcast ( obj, cID );
	    }
	} catch (Exception e) { mtr.remove( out , cID);}
        System.out.printf("\n\t\tClient %d has disconnected", cID);
    }
}
