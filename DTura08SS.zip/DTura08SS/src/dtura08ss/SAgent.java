/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dtura08ss;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 *
 * @author student
 */
class SAgent implements Runnable {
    Socket sk = null;
    int    cID;
    ChatMonitor  mtr =  null;
    ObjectInputStream   in = null;
    ObjectOutputStream out = null;

    public SAgent (int clientID,  Socket sk, ChatMonitor mtr ) {
	cID = clientID; this.sk = sk; this.mtr = mtr;

	try {
	    out = new ObjectOutputStream( sk.getOutputStream() );
	    in  = new ObjectInputStream (sk.getInputStream( ) );
	    mtr.put( out );
	} catch ( IOException e ) { e.printStackTrace(); }

    }

    public void run() {
	Object obj = null;
	try {
	    while ( true ) {
		obj = in.readObject();
		mtr.broadcast ( obj );
	    }
	} catch (Exception e) { mtr.remove( out );}
    }
}
