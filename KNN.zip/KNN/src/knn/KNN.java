package knn;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public class KNN {
    static Random rdn = new Random();
    static float dataArr[];
    static float testArr[];
    static float trainArr[];
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            File file = new File("src/knn/knn.txt");
            Scanner scan = new Scanner(file);
            dataArr = new float[96];
            int i = 0;
            byte t;
            while(scan.hasNextLine()){
                while(scan.hasNextInt() || scan.hasNextFloat()){
                    float nxt;
                    if(scan.hasNextInt())
                        nxt = (float)scan.nextInt();
                    else
                        nxt = scan.nextFloat();
                    dataArr[i] = nxt;
                    i++;
                }
                if(scan.hasNextByte())
                    t = scan.nextByte();
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(KNN.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.printf("testing: %f", dataArr[10*4]);
        testArr = new float[18*4];
        trainArr = new float[6*4];
        int locs[] = new int[6];
        for(int i=0; i<6; i++){
            int tmp;
            boolean found = false;
            do {
                tmp = rdn.nextInt(25);
                for(int k=0; k<6; k++){
                    if(locs[k]==tmp)
                        found = true; break;
                }
            }while(found);
            locs[i] = tmp;
        }
        int ts = 0;
        int tr = 0;
        for(int i=0; i<24; i++){
            boolean found = false;
            for(int k=0; k<6; k++){
                if(i==locs[k]){
                   trainArr[tr] = dataArr[i*4]; 
                }
            }
        }
        
    }
    
}
