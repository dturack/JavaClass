package dtura09;

//interface to initialize names of default visitors and groups
public interface Names {

   public static final String visitors [] = { "RSmith", "JDoe", "DRoss" };

   public static final String group [] = { "Java-App", "Math", "Physcis", "Biolog", "Chemstry" }; 
    
}
