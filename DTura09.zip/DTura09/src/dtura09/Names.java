package dtura09;

public interface Names {

   public static final String visitors [] = { "RSmith", "JDoe", "DRoss" };

   public static final String group [] = { "Java-App", "Math", "Physcis", "Biolog", "Chemstry" }; 
    
}
