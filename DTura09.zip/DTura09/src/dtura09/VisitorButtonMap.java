package dtura09;

import javax.swing.JCheckBox;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener; 
import java.awt.Font;
import java.util.HashMap;
import java.util.Set;

/** VisitorButtonMap class has two Hashmaps to provide easy access from RadioButton to Group
  and from Group ID to Radio button.
 */
//Class is used for formatting of Visitor Button section
class VisitorButtonMap {

   public int			  selected = 0;
   JCheckBox			  button = null;
   HashMap<JCheckBox, Visitor>    buttonMap = new HashMap< JCheckBox, Visitor>();
   HashMap<Visitor, JCheckBox>    visitorMap = new HashMap<Visitor, JCheckBox>();

   //default initializer
   public VisitorButtonMap () {} 

   //functi0on to clear all buttons from button map
   public void clear() {selected = 0; buttonMap.clear(); visitorMap.clear(); }

   //function to return all check boxes as object
   public Object [] getAllCheckBox() {
      Set<JCheckBox> set = buttonMap.keySet();
      return set.toArray();
   }

   //function to add a visitor with a checkbox to Map
   public void add( JCheckBox button, Visitor visitors){
      button.setFont(new Font("verdana", Font.PLAIN, 10));
      buttonMap.put( button, visitors );
      visitorMap.put ( visitors, button );
   }

   //function to remove a visitor from the Map
   public void remove( Visitor visitor ){
      button = visitorMap.get( visitor );
      if ( button.isSelected() ) selected -- ;
      buttonMap.remove( button );
      visitorMap.remove( visitor );
   }

   //function to get the visitor associated with a checkbox
   public Visitor get( JCheckBox chkBox ) { return buttonMap.get( chkBox ) ; }
   //function to get the check box associated with a visitor
   public JCheckBox get( Visitor visitor ) { return visitorMap.get( visitor ) ; }
   //function to control the status of the checkBoxes
   public void setStatus (JCheckBox button ) {
      buttonMap.get(button).checked = button.isSelected();
      selected += button.isSelected() ? 1 : -1;
   }


}
