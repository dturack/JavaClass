package dtura09;

import java.io.Serializable;
import java.util.Vector;
import java.util.StringTokenizer;

//class is used to create a vector of Groups
public class VGroup implements Serializable {
    //Vector is initialized with five default groups
    public Vector<Group> vgroup = new Vector<Group> ( 5 );

    //function adds a new group to the vector of groups
    public void add( Group grp ) 	{ vgroup.add( grp ); }
    //function removes a group from the vector of groups
    public void remove( Group grp )	{
	grp = find(grp.ID); grp.clear();
	vgroup.remove( grp );
    }

    //function removes a specific visitor from a group. If last visitor, remove group.
    public void remove( int gID, int vID ){
	Group grp = find(gID);
	if ( grp == null ) return;
	Visitor v = grp.find(vID) ;
	if ( v != null ) grp.remove( v );
	if ( grp.size() == 0 ) vgroup.remove( grp );
    }
    
    //function returns size of the group
    public int  size () 		{ return vgroup.size(); }

    //function iterates through vgroup clearing all visitors from each group
    public void clear ( )	{
	// move/clear all visitors in each group.  
	for ( int i = 0; i < vgroup.size(); i ++ ) vgroup.get(i).clear();
	vgroup.clear();  // remove all group from this v_group. 
    }

    //function searches through all groups and returns the group with the requested ID number
    public Group find( int gID ) {
	for ( int i = 0; i < vgroup.size(); i ++ )
	    if ( gID == vgroup.get(i).ID) return vgroup.get(i);
	return null;
    }

    //function gets the requested group basecd on the index number
    public Group get ( int k ) {
	if ( k < 0 || k >= vgroup.size() ) return null;
	return vgroup.get(k);
    }

    //function moves a visitor from one group to another
    public boolean changeGroup ( Visitor v, Group fromGroup, Group  toGroup) {
	if ( fromGroup == null || toGroup == null || ! fromGroup.vecVisitor.contains( v ) )  return false; 
	toGroup.add(v);
	fromGroup.remove ( v );
	return true;
    }

    // Make sure that the count is the same as size of visitors in each group.
    public void synchronize() {
       Group grp;
       for ( int i = 0; i < size() ; i ++ ) {
	  grp = get(i); grp.count = grp.size();
       }
    }
    
    //Override function to list vgroup in short-form.
    @Override
    public String toString() { 
	StringBuffer buf = new StringBuffer(); 
	int size = vgroup.size() - 1;
	for ( int i = 0; i <= size; i++ )
	    buf.append (vgroup.get(i).toString() + ( i == size ? "": "; " ));
	return buf.toString();
    }

    //function used to format ouput of group list
    public String groupList() { return this.toString(); } 

    //function used to add tokens to list of groups
    static public VGroup toVGroup( String groupList ) { 
	VGroup vg = new VGroup();
	StringTokenizer tzer = new StringTokenizer(groupList, ";");
	while ( tzer.hasMoreTokens() )  vg.add( Group.toGroup( tzer.nextToken()));
	return vg;
    }

    //function to add all groups into list of groups
    public void add(String grpList ) { 
	StringTokenizer tzer = new StringTokenizer(grpList, ";");
	while ( tzer.hasMoreTokens() )  vgroup.add( Group.toGroup( tzer.nextToken()));
	/*
	String gName;
	int    gID, i = 0;
	while ( tzer.hasMoreTokens() ) {
	    gName = new String( tzer.nextToken() );
	    gID  = Integer.parseInt( tzer.nextToken() );
	    tzer.nextToken();  // get the number of visitors
	    vgroup.add( new Group( gID, gName ));
	}
    */
    }


    //function to broadcast message regarding group either added or removed
    public void broadcast( Message addOrRmGrpMsg ) {
	int msgType = addOrRmGrpMsg.type;

	// if (msgType != Message.ADDGROUP && msgType != Message.REMOVEGROUP ) return;
	for ( int i = 0; i < vgroup.size() ; i++ )
	    vgroup.get(i).broadcast( addOrRmGrpMsg );	
    }

}
