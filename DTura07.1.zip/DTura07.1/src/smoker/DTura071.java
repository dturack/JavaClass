package smoker;
import javax.swing.*;
import java.awt.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */

public class DTura071 extends JFrame{

    static SAMonitor mtr = new SAMonitor();
    static Thread agent = null;
    static Thread smkr[] = new Thread[3];
    static JPanel p = new JPanel();
    static Graphics2D g;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        agent = new Thread( new Agent (mtr, g));
        agent.start();
        for(int i=0; i<3; i++){
            smkr[i] = new Thread(new Smoker(i, mtr));
            smkr[i].start();
        }
        

    }
    
}
