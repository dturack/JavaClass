package smoker;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author student
 */


public class Agent extends Thread implements Runnable {
    //int id;
    static SAMonitor smtr = null;
    static Graphics2D g;
    
    public Agent(SAMonitor sam, Graphics2D gr){
        smtr = sam; g = gr;
    }
    
    
    public void run(){
        int kind = -1;
        
        while(true){
            Shared.simulate("Making ingredient " + Shared.component(kind), 3, 4);
            kind = Shared.rnd.nextInt(3);
            Shared.simulate("Agent: Mode a " + Shared.component(kind), 1, 3);
            smtr.put(kind);
            Shared.simulate("Agent: Relax ... ", 1, 3);
        }
    }
}
